<?php
ob_start();
error_reporting(0);
//لورکس تیم//@LorexTeam//
$sudo = array([*[ADMIN]*],[*[ADMIN]*],[*[ADMIN]*]);//ایدی عددی ادمین ها//
define('API_KEY','[*[TOKEN]*]');//توکن را قرار دهید//
function mrbot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
$update = json_decode(file_get_contents('php://input'));
$inline = $update->inline_query->query;
$message = $update->message;
$from_id = $message->from->id;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->username;
$text = $message->text;
$newchatmemberid = $update->message->new_chat_member->id;
$firstname = $update->callback_query->from->first_name;
$usernames = $update->callback_query->from->username;
$chatid = $update->callback_query->message->chat->id;
$fromid = $update->callback_query->from->id;
$reply = $update->message->reply_to_message->forward_from->id;
$data = $update->callback_query->data;
$messageid = $update->callback_query->message->message_id;
$rpto = $update->message->reply_to_message->forward_from->id;
$gpname = $update->callback_query->message->chat->title;
$namegroup = $update->message->chat->title;
$bot = explode(':',API_KEY);
$botid = $bot[0];
$type = $update->message->chat->type;
$mr = json_decode(file_get_contents("mr.json"),true);
//---------
function Edit($chat_id,$message_id,$text,$parse_mode,$disable_web_page_preview,$keyboard){
	 mrbot('editMessagetext',[
    'chat_id'=>$chat_id,
	'message_id'=>$message_id,
    'text'=>$text,
    'parse_mode'=>$parse_mode,
	'disable_web_page_preview'=>$disable_web_page_preview,
    'reply_markup'=>$keyboard
	]);
	}
function Delete($chat_id,$message_id){
	mrbot('deleteMessage',[
	'chat_id'=>$chat_id,
	'message_id'=>$message_id
	]);
}
 function Send($chat_id, $text, $model , $msg_id , $webpage , $panel){
 mrbot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>$text,
 'parse_mode'=>$model  ,
 'reply_to_message_id'=>$msg_id ,
 'disable_web_page_preview'=>$webpage,
 'reply_markup'=>$panel
 ]);
 }
 function Fwd($BeKoja,$AzKoja,$KodomMSG){
mrbot('ForwardMessage',[
'chat_id'=>$BeKoja,
'from_chat_id'=>$AzKoja,
'message_id'=>$KodomMSG
]);
}
 function SaveJson($file,$date){
	$save=json_encode($date);
	file_put_contents($file,$save);
}
function AnswerQuery($queri_id,$text,$show){
	mrbot('answercallbackquery',[
	'callback_query_id'=>$queri_id ,
	'text'=>$text ,
	'show_alert'=>$show 
	]);
	}
	function LeaveChat($chat_id){
	mrbot('leaveChat',[
	'chat_id'=>$chat_id
	]);
}//@LorexTeam//

	function Panel($where){
	switch($where){
	case 'users';
	$key=json_encode([ 'inline_keyboard'=>[
	[['text'=>"سفارش ربات",'url'=>"https://t.me/[*[CHANNEL]*]"]],
	]]);
	return $key;
	case 'sudo';
	$key=json_encode([ 'inline_keyboard'=>[
	[['text'=>"افزودن ربات به گروه",'url'=>"https://t.me/[*[USERNAME]*]?startgroup=new"]],
	]]);
	return $key;
	}
	}//@LorexTeam//
//--------
if(preg_match('/^[\/]?([Ss][Tt][Aa][Rr][Tt])$/i',$text)){
if(!in_array($from_id,$sudo)){
$txt="⚠️ کاربر $first_name این ربات اختصاصی گروه *ادد بزن شارژ بگیر* میباشد و فقط ادمین ربات میتواند از آن استفاده کند\n\n✅ اگر شما هم میخواهید رباتی مثل این ربات داشته باشید از طریق دکمه زیر به سازنده مراجع کنید .";
$panel=Panel('users');
Send($chat_id,$txt,'markdown',$message_id,true,$panel);
}else{
$mr['sudo']["$from_id"]="no";
SaveJson('mr.json',$mr);
$txt="⭐️ سلام $first_name ادمین عزیز به ربات *ادد شمار* خوش اومدی\n\n✅ برای استفاده ، ربات را از طریق دکمه زیر به گروه خود اضافه کنید و پس از ادمین کردن دستور 'نصب' را ارسال کنید.\n\n✅ بعد از نصب شدن ربات در گروه در صورت نیاز دستور 'راهنما' را ارسال کنید\n\n";
$panel=Panel('sudo');
Send($chat_id,$txt,'markdown',$message_id,true,$panel);
}
}//@LorexTeam//
if($newchatmemberid==$botid){
	if(!in_array($from_id,$sudo)){
		$txt="⚠️ کاربر $first_name این ربات اختصاصی گروه *ادد بزن شارژ بگیر* میباشد و فقط ادمین ربات میتواند از آن استفاده کند\n\n✅ اگر شما هم میخواهید رباتی مثل این ربات داشته باشید از طریق دکمه زیر به سازنده مراجع کنید .";
$panel=Panel('users');
Send($chat_id,$txt,'markdown',$message_id,true,$panel);
LeaveChat($chat_id);
}else{
	$txt="✅ ربات با موفقیت در گروه *$namegroup* اضافه شد\n\n⚠️ ابتدا ربات را ادمین کرده سپس دستور 'نصب' را ارسال کنید";
Send($chat_id,$txt,'markdown',$message_id,true,null);
}
}
if($text=="نصب" or $text=="install"){
	if($type=='group' or $type=='supergroup'){
		if(in_array($from_id,$sudo)){
	if($mr['groups']["$chat_id"]['install']!="✅"){
		$mr['groups']["$chat_id"]['install']="✅";
	$mr['groups']["$chat_id"]['bot']="✅";
	SaveJson('mr.json',$mr);
		$txt="✅ ربات با موفقیت در گروه شما *نصب* شد\n\n⁉️ در صورت نیاز واژه ی 'راهنما' را ارسال کنید";
		Send($chat_id,$txt,'markdown',$message_id,true,null);
		}else{
			$txt="⚠️ ربات از قبل در گروه *$namegroup* نصب شده است !\n\nℹ️ برای دریافت راهنمایی کلمه ی 'راهنما' را ارسال کنید";
		Send($chat_id,$txt,'markdown',$message_id,true,null);
		}
		}//@LorexTeam//
		}
		}
		if($text=="ربات روشن" or $text=="ربات خاموش"){
			if($type=='group' or $type=='supergroup'){
				if(in_array($from_id,$sudo)){
			$ex=str_replace('ربات ',"",$text);
			$emo=str_replace(['روشن','خاموش'],['✅','❌'],$ex);
			if($mr['groups']["$chat_id"]['bot']!=$emo){
			$mr['groups']["$chat_id"]['bot']=$emo;
			SaveJson('mr.json',$mr);
			$txt="✅ ربات با موفقیت #$ex شد";
		Send($chat_id,$txt,'markdown',$message_id,true,null);
			}else{
				$txt="❌ ربات از قبل #$ex بود !";
		Send($chat_id,$txt,'markdown',$message_id,true,null);
		}
		}
	}
	}
		if($newchatmemberid==true && $mr['groups']["$chat_id"]['bot']=="✅" && $mr['groups']["$chat_id"]['install']=="✅"){
					$add=$mr['groups']["$chat_id"]['addlist']["$from_id"];
					$newadd=$add+1;
					$mr['groups']["$chat_id"]['addlist']["$from_id"]=$newadd;
					SaveJson('mr.json',$mr);
					Delete($chat_id,$message_id);
					if($newadd==75){
				$txt ="⭐️ کاربر $first_name | `$from_id` \nتعداد ادد های شما به *75* رسید 🎉\n\n✅ هم اکنون میتوانید با ورود به پیوی ادمین جایزه ی خود را دریافت کنید \n\n⚠️ توجه داشته باشید تعداد ادد های شما *صفر* شد !";
				$panel=json_encode([ 'inline_keyboard'=>[
				[['text'=>"پیوی ادمین",'url'=>"https://t.me/LorexTeam"]],
				[['text'=>"من چندتا ادد زدم ؟",'callback_data'=>"countadd"]]
				]]);
				Send($chat_id,$txt,'markdown',null,true,$panel);
					$mr['groups']["$chat_id"]['addlist']["$from_id"]=0;
					SaveJson('mr.json',$mr);
					}
							if($newadd==2){
				$txt ="👤 کاربر $first_name | `$from_id`\nشما تازه شروع به ادد زدن در گروه کرده اید \n\n✅ به ازای هر ادد مقدار *1,000 تومان* شارژ دریافت میکنید ، در صورت رسیدن تعداد ادد ها به *75* میتوانید شارژ خود را از ادمین تحویل بگیرید";
				$panel=json_encode([ 'inline_keyboard'=>[
				[['text'=>"من چندتا ادد زدم ؟",'callback_data'=>"countadd"]]
				]]);
				Send($chat_id,$txt,'markdown',null,true,$panel);
					}
				}
				//@LorexTeam//
					if($data=="countadd" && $mr['groups']["$chatid"]['bot']=="✅" && $mr['groups']["$chatid"]['install']=="✅"){
						if($mr['groups']["$chatid"]['addlist']["$fromid"]==null or $mr['groups']["$chatid"]['addlist']["$fromid"]==0){
							$txt="شما تاکنون کسی را به گروه ادد نکرده اید !";
							AnswerQuery($update->callback_query->id,$txt,true);
							}else{
								$ad=$mr['groups']["$chatid"]['addlist']["$fromid"];
								$txt="شما تا الان $ad نفر در گروه ادد کرده اید";
								AnswerQuery($update->callback_query->id,$txt,true);
								}
							}
								if(isset($update->message->left_chat_member)){
									Delete($chat_id,$message_id);
									}
					if($text=="راهنما" or $text=="help" ){
						if(in_array($from_id,$sudo)){
						$txt="ℹ️ راهنمای استفاده \n\n⁉️ نصب ربات در گروه :\n▫️`نصب`\n\n⁉️ روشن و خاموش کردن ربات :\n▫️`ربات روشن | خاموش`";
						$panel=json_encode([ 'inline_keyboard'=>[
						[['text'=>"سازنده ربات",'url'=>"https://t.me/[*[CHANNEL]*]"]]
						]]);//@LorexTeam//
		Send($chat_id,$txt,'markdown',$message_id,true,$panel);
		}
		}
		//لورکس تیم//@LorexTeam//
	?>