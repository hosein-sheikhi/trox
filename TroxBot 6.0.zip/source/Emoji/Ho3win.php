<?php

$telegram_ip_ranges = [
['lower' => '149.154.160.0', 'upper' => '149.154.175.255'], // literally 149.154.160.0/20
['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],    // literally 91.108.4.0/22
];
$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
$ok=false;
foreach ($telegram_ip_ranges as $telegram_ip_range) if (!$ok) {
    $lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
    $upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
    if ($ip_dec >= $lower_dec and $ip_dec <= $upper_dec) $ok=true;
}
if (!$ok) die("Are You Okay ?");
//------------------------------------------------------//
ob_start(); // از اصکی بدون منبع بپرهیز!
error_reporting(0);  // اولین اپن کننده LorexTeam 
date_default_timezone_set('Asia/Tehran');
// ارتقا و ادیت این سورس ازاد ولی به اسم خودتون نزنید،کدشو نفروشید و شاخ نشید.
//------------------------------------------------------//
define('API_KEY',"[*[TOKEN]*]"); // LorexTeam
//------------------------------------------------------//
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
// @LorexTeam
//------------------------------------------------------
$update = json_decode(file_get_contents('php://input'));
$tc = $update->message->chat->type;
$message = $update->message;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$from_id = $message->from->id;
$text = $message->text;
//------------------------------------------------------
if($text == "/start" && $tc == "private"){
bot('SendMessage',[ // @LorexTeam
'chat_id'=>$chat_id,
'text'=>"💯 به ربات بازی خوشومدی!

✅ تو این ربات میتونی دارت بازی کنی!
✅ تاس بندازی!
✅ پنالتی بزنی!
✅ بسکتبال بازی کنی!

👇 یکی از گزینه های زیر رو انتخاب کن :

@[*[CHANNEL]*]",
  'reply_to_message_id'=>$message_id,
 'reply_markup'=>json_encode([
           'keyboard'=>[
           [['text'=>"🎲 تاس بنداز"],['text'=>"⚽️ پنالتی بزن"]],
           [['text'=>"🏀 بسکتبال بازی کن"],['text'=>"🎯 دارت بازی کن"]],
	],
		"resize_keyboard"=>true,
	 ]) 
	 ]);
	 }
	 elseif($text == "🎯 دارت بازی کن"  && $tc == "private"){
$dice = bot('sendDice',[
'chat_id' => $chat_id,
'emoji'=> '🎯',
   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "♻️ در حال بازی ...", 'callback_data' => "none"]],                       
                    ]
                ]) 
]);
$value = $dice->result->dice->value;
$messageid = $dice->result->message_id;
sleep(2.5); // LorexTeam
if($value == 1 or $value == 2 or $value == 3){
$om = "❌ بازیو باختی،امتیاز نگرفتی";
}else{
$om = "🎊 امتیاز بازی : $value";
}
bot('editMessageReplyMarkup',[
    'chat_id'=> $chat_id,
    'message_id'=>$messageid,
	   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "$om", 'callback_data' => "none"]],                       
                    ]
                ])
    		]);// @LorexTeam
}
	 // LorexTeam// LorexTeam// LorexTeam
	 elseif($text == "🏀 بسکتبال بازی کن"  && $tc == "private"){
$dice = bot('sendDice',[
'chat_id' => $chat_id,
'emoji'=> '🏀',
   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "♻️ در حال بازی ...", 'callback_data' => "none"]],                       
                    ]
                ]) // @LorexTeam
]); // LorexTeam
$value = $dice->result->dice->value;
$messageid = $dice->result->message_id;
sleep(7); // LorexTeam
if($value == 1 or $value == 2 or $value == 3){
$om = "❌ بازیو باختی،امتیاز نگرفتی";
}else{
$om = "🎊 امتیاز بازی : $value";
}
bot('editMessageReplyMarkup',[
    'chat_id'=> $chat_id,
    'message_id'=>$messageid,
	   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "$om", 'callback_data' => "none"]],                       
                    ]
                ])
    		]);// LorexTeam
}
	 // LorexTeam// LorexTeam
	 elseif($text == "⚽️ پنالتی بزن"  && $tc == "private"){
$dice = bot('sendDice',[
'chat_id' => $chat_id,
'emoji'=> '⚽️',
   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "♻️ در حال پنالتی زدن ...", 'callback_data' => "none"]],                       
                    ]
                ]) // @LorexTeam
]); // LorexTeam
$value = $dice->result->dice->value;
$messageid = $dice->result->message_id;
sleep(7); // LorexTeam
if($value == 1 or $value == 2){
$om = "❌ پنالتی باختی،امتیازی نگرفتی";
}else{
$om = "🎊 امتیاز پنالتی : $value";
}
bot('editMessageReplyMarkup',[
    'chat_id'=> $chat_id,
    'message_id'=>$messageid,
	   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "$om", 'callback_data' => "none"]],                       
                    ]
                ])
    		]);// LorexTeam
}
	 // LorexTeam
	 elseif($text == "🎲 تاس بنداز"  && $tc == "private"){
$dice = bot('sendDice',[
'chat_id' => $chat_id,
'emoji'=> '🎲',
   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "♻️ در حال انداختن تاس ...", 'callback_data' => "none"]],                       
                    ]
                ]) // @LorexTeam
]); // LorexTeam
$value = $dice->result->dice->value;
$messageid = $dice->result->message_id;
sleep(4); // LorexTeam
bot('editMessageReplyMarkup',[
    'chat_id'=> $chat_id,
    'message_id'=>$messageid,
	   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "🎲 نتیجه تاس : $value", 'callback_data' => "none"]],                       
                    ]
                ])
    		]);// LorexTeam
}

/*
- DeveLoper : @LorexTeam
- Channel : @LorexTeam
سورس شیک و تمیز تاس!
با تشخیص مقدار تاس افتاده شده!


*/