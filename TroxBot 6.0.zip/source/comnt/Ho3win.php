<?php
/*
بسم الله الرحمن الرحیم

اپن شده توسط :@Mr_Ho3win

----------------------------
سورس های بیشتر در چنل لورکس تیم 
@LorexTeam 
-----------------------------

*/

ob_start();
$load = sys_getloadavg();
$telegram_ip_ranges = [
['lower' => '149.154.160.0', 'upper' => '149.154.175.255'], 
['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],    
];
$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
$ok=false;
foreach ($telegram_ip_ranges as $telegram_ip_range) if (!$ok) {
$lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
$upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
if($ip_dec >= $lower_dec and $ip_dec <= $upper_dec) $ok=true;
}
if(!$ok) die("fuck you hacker :) sik :)");

error_reporting(0);
$token = "[*[TOKEN]*]"; //توکن بذارید
define('API_KEY',$token);
include("jdf.php");
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
$update = json_decode(file_get_contents('php://input'));
if(isset($update->message)){
    $message = $update->message;
    $chat_id = $message->chat->id;
    $from_id = $message->from->id;
}
if ($from_id == 777000){
        bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"اشغال کامنت اول!👀",
            'reply_to_message_id'=>$update->message->message_id,
        ]);
        bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"اشغال کامنت دوم!🦾",
            'reply_to_message_id'=>$update->message->message_id,
        ]);
		bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"اشغال کامنت سوم!🦠",
            'reply_to_message_id'=>$update->message->message_id,
        ]);
		bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"کامنت شماره 4 نیز اشغال شد!🩸",
            'reply_to_message_id'=>$update->message->message_id,
        ]);
		bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"ناموس این پست با موفقیت امن شد!🙌",
            'reply_to_message_id'=>$update->message->message_id,
        ]);
		
}