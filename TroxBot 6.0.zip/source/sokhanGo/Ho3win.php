<?php

ob_start();
define('API_KEY','[*[TOKEN]*]');//توکن
$admin='[*[ADMIN]*]';//ایدی عددی ادمین                             
$channel= "[*[CHANNEL]*]";
function Bot($a,$b=[]){
$url="https://api.telegram.org/bot".API_KEY."/$a";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($b));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$result=curl_exec($ch);
curl_close ($ch);
return json_decode($result);
}
function Pass($length = 8) {
$vmsString = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
return substr(str_shuffle($vmsString),0,$length);
}
function Msg($chatid,$text,$keyboard,$parsmde,$disable_web_page_preview,$A){
    return bot('sendMessage',[
    'chat_id'=>$chatid,
	'text'=>$text,
	'parse_mode'=>$parsmde,
	 'reply_to_message_id'=>$A,
	'disable_web_page_preview'=>$disable_web_page_preview,
	'reply_markup'=>$keyboard
	]);
	}
function dlt($chat_id,$message_id){
	  return bot('deletemessage',[
	      'chat_id' =>$chat_id,
	      'message_id'=>$message_id]);
	}
function FWD($chatid,$from_chat,$message_id){
	return bot('ForwardMessage',[
	'chat_id'=>$chatid,
	'from_chat_id'=>$from_chat,
	'message_id'=>$message_id
	]);
}
function pic($chatid,$photo,$caption,$keyboard,$parsemode){
	return bot('SendPhoto',[
	'chat_id'=>$chatid,
	'photo'=>$photo,
	'caption'=>$caption,
	'reply_markup'=>$keyboard,
	'parse_mode'=>$parsemode
	]);
	}
function Aqi($a,$b,$c){
	return bot('answerCallbackQuery',[
	'callback_query_id'=>$a,
	'text'=>$b,
	'show_alert'=>$c
	]);
}
/* Tabee Send Audio */
function Aud($chatid,$audio,$caption,$keyboard,$sazande,$title){
	return bot('SendAudio',[
	'chat_id'=>$chatid,
	'audio'=>$audio,
	'caption'=>$caption,
	'performer'=>$sazande,
	'title'=>$title,
	'reply_markup'=>$keyboard
	]);
	}
	/* Tabee Send Document */
function Doc($chatid,$document,$caption,$keyboard){
	return bot('SendDocument',[
	'chat_id'=>$chatid,
	'document'=>$document,
	'caption'=>$caption,
	'reply_markup'=>$keyboard
	]);
	}
	/* Tabee Send Sticker */
function Stick($a,$b,$c){
	return bot('sendSticker',[
	'chat_id'=>$a,
	'sticker'=>$b,
	'reply_markup'=>$c
	]);
	}
	/* Tabee Send Video */
function Vid($chatid,$video,$caption,$keyboard,$duration){
	return bot('SendVideo',[
	'chat_id'=>$chatid,
	'video'=>$video,
        'caption'=>$caption,
	'duration'=>$duration,
	'reply_markup'=>$keyboard
	]);
	}
	/* Tabee Send Voice */
function Voi($chatid,$voice,$caption,$keyboard){
	return bot('SendVoice',[
	'chat_id'=>$chatid,
	'voice'=>$voice,
	'caption'=>$caption,
	'reply_markup'=>$keyboard
	]);
	}
	/* Tabee Send Contact */
function Cont($a,$b,$c){
	return bot('SendContact',[
	'chat_id'=>$a,
	'first_name'=>explode('[[+]]',$b)[1],
	'phone_number'=>explode('[[+]]',$b)[0],
	'reply_markup'=>$c
	]);
	}
	/* Tabee Send Chat Action */
function Action($chatid,$action){
	return bot('sendChatAction',[
	'chat_id'=>$chatid,
	'action'=>$action
	]);
	}
#[Date]##################################################################
function jdate($format,$timestamp='',$none='',$time_zone='Asia/Tehran',$tr_num='fa'){

 $T_sec=0;/* <= رفع خطاي زمان سرور ، با اعداد '+' و '-' بر حسب ثانيه */

 if($time_zone!='local')date_default_timezone_set(($time_zone==='')?'Asia/Tehran':$time_zone);
 $ts=$T_sec+(($timestamp==='')?time():tr_num($timestamp));
 $date=explode('_',date('H_i_j_n_O_P_s_w_Y',$ts));
 list($j_y,$j_m,$j_d)=gregorian_to_jalali($date[8],$date[3],$date[2]);
 $doy=($j_m<7)?(($j_m-1)*31)+$j_d-1:(($j_m-7)*30)+$j_d+185;
 $kab=(((($j_y%33)%4)-1)==((int)(($j_y%33)*0.05)))?1:0;
 $sl=strlen($format);
 $out='';
 for($i=0; $i<$sl; $i++){
  $sub=substr($format,$i,1);
  if($sub=='\\'){
	$out.=substr($format,++$i,1);
	continue;
  }
  switch($sub){

	case'E':case'R':case'x':case'X':
	$out.='http://jdf.scr.ir';
	break;

	case'B':case'e':case'g':
	case'G':case'h':case'I':
	case'T':case'u':case'Z':
	$out.=date($sub,$ts);
	break;

	case'a':
	$out.=($date[0]<12)?'ق.ظ':'ب.ظ';
	break;

	case'A':
	$out.=($date[0]<12)?'قبل از ظهر':'بعد از ظهر';
	break;

	case'b':
	$out.=(int)($j_m/3.1)+1;
	break;

	case'c':
	$out.=$j_y.'/'.$j_m.'/'.$j_d.' ،'.$date[0].':'.$date[1].':'.$date[6].' '.$date[5];
	break;

	case'C':
	$out.=(int)(($j_y+99)/100);
	break;

	case'd':
	$out.=($j_d<10)?'0'.$j_d:$j_d;
	break;

	case'D':
	$out.=jdate_words(array('kh'=>$date[7]),' ');
	break;

	case'f':
	$out.=jdate_words(array('ff'=>$j_m),' ');
	break;

	case'F':
	$out.=jdate_words(array('mm'=>$j_m),' ');
	break;

	case'H':
	$out.=$date[0];
	break;

	case'i':
	$out.=$date[1];
	break;

	case'j':
	$out.=$j_d;
	break;

	case'J':
	$out.=jdate_words(array('rr'=>$j_d),' ');
	break;

	case'k';
	$out.=tr_num(100-(int)($doy/($kab+365)*1000)/10,$tr_num);
	break;

	case'K':
	$out.=tr_num((int)($doy/($kab+365)*1000)/10,$tr_num);
	break;

	case'l':
	$out.=jdate_words(array('rh'=>$date[7]),' ');
	break;

	case'L':
	$out.=$kab;
	break;

	case'm':
	$out.=($j_m>9)?$j_m:'0'.$j_m;
	break;

	case'M':
	$out.=jdate_words(array('km'=>$j_m),' ');
	break;

	case'n':
	$out.=$j_m;
	break;

	case'N':
	$out.=$date[7]+1;
	break;

	case'o':
	$jdw=($date[7]==6)?0:$date[7]+1;
	$dny=364+$kab-$doy;
	$out.=($jdw>($doy+3) and $doy<3)?$j_y-1:(((3-$dny)>$jdw and $dny<3)?$j_y+1:$j_y);
	break;

	case'O':
	$out.=$date[4];
	break;

	case'p':
	$out.=jdate_words(array('mb'=>$j_m),' ');
	break;

	case'P':
	$out.=$date[5];
	break;

	case'q':
	$out.=jdate_words(array('sh'=>$j_y),' ');
	break;

	case'Q':
	$out.=$kab+364-$doy;
	break;

	case'r':
	$key=jdate_words(array('rh'=>$date[7],'mm'=>$j_m));
	$out.=$date[0].':'.$date[1].':'.$date[6].' '.$date[4].' '.$key['rh'].'، '.$j_d.' '.$key['mm'].' '.$j_y;
	break;

	case's':
	$out.=$date[6];
	break;

	case'S':
	$out.='ام';
	break;

	case't':
	$out.=($j_m!=12)?(31-(int)($j_m/6.5)):($kab+29);
	break;

	case'U':
	$out.=$ts;
	break;

	case'v':
	 $out.=jdate_words(array('ss'=>($j_y%100)),' ');
	break;

	case'V':
	$out.=jdate_words(array('ss'=>$j_y),' ');
	break;

	case'w':
	$out.=($date[7]==6)?0:$date[7]+1;
	break;

	case'W':
	$avs=(($date[7]==6)?0:$date[7]+1)-($doy%7);
	if($avs<0)$avs+=7;
	$num=(int)(($doy+$avs)/7);
	if($avs<4){
	 $num++;
	}elseif($num<1){
	 $num=($avs==4 or $avs==((((($j_y%33)%4)-2)==((int)(($j_y%33)*0.05)))?5:4))?53:52;
	}
	$aks=$avs+$kab;
	if($aks==7)$aks=0;
	$out.=(($kab+363-$doy)<$aks and $aks<3)?'01':(($num<10)?'0'.$num:$num);
	break;

	case'y':
	$out.=substr($j_y,2,2);
	break;

	case'Y':
	$out.=$j_y;
	break;

	case'z':
	$out.=$doy;
	break;

	default:$out.=$sub;
  }
 }
 return($tr_num!='en')?tr_num($out,'fa','.'):$out;
}

/*	F	*/
function jstrftime($format,$timestamp='',$none='',$time_zone='Asia/Tehran',$tr_num='fa'){

 $T_sec=0;/* <= رفع خطاي زمان سرور ، با اعداد '+' و '-' بر حسب ثانيه */

 if($time_zone!='local')date_default_timezone_set(($time_zone==='')?'Asia/Tehran':$time_zone);
 $ts=$T_sec+(($timestamp==='')?time():tr_num($timestamp));
 $date=explode('_',date('h_H_i_j_n_s_w_Y',$ts));
 list($j_y,$j_m,$j_d)=gregorian_to_jalali($date[7],$date[4],$date[3]);
 $doy=($j_m<7)?(($j_m-1)*31)+$j_d-1:(($j_m-7)*30)+$j_d+185;
 $kab=(((($j_y%33)%4)-1)==((int)(($j_y%33)*0.05)))?1:0;
 $sl=strlen($format);
 $out='';
 for($i=0; $i<$sl; $i++){
  $sub=substr($format,$i,1);
  if($sub=='%'){
	$sub=substr($format,++$i,1);
  }else{
	$out.=$sub;
	continue;
  }
  switch($sub){

	/* Day */
	case'a':
	$out.=jdate_words(array('kh'=>$date[6]),' ');
	break;

	case'A':
	$out.=jdate_words(array('rh'=>$date[6]),' ');
	break;

	case'd':
	$out.=($j_d<10)?'0'.$j_d:$j_d;
	break;

	case'e':
	$out.=($j_d<10)?' '.$j_d:$j_d;
	break;

	case'j':
	$out.=str_pad($doy+1,3,0,STR_PAD_LEFT);
	break;

	case'u':
	$out.=$date[6]+1;
	break;

	case'w':
	$out.=($date[6]==6)?0:$date[6]+1;
	break;

	/* Week */
	case'U':
	$avs=(($date[6]<5)?$date[6]+2:$date[6]-5)-($doy%7);
	if($avs<0)$avs+=7;
	$num=(int)(($doy+$avs)/7)+1;
	if($avs>3 or $avs==1)$num--;
	$out.=($num<10)?'0'.$num:$num;
	break;

	case'V':
	$avs=(($date[6]==6)?0:$date[6]+1)-($doy%7);
	if($avs<0)$avs+=7;
	$num=(int)(($doy+$avs)/7);
	if($avs<4){
	 $num++;
	}elseif($num<1){
	 $num=($avs==4 or $avs==((((($j_y%33)%4)-2)==((int)(($j_y%33)*0.05)))?5:4))?53:52;
	}
	$aks=$avs+$kab;
	if($aks==7)$aks=0;
	$out.=(($kab+363-$doy)<$aks and $aks<3)?'01':(($num<10)?'0'.$num:$num);
	break;

	case'W':
	$avs=(($date[6]==6)?0:$date[6]+1)-($doy%7);
	if($avs<0)$avs+=7;
	$num=(int)(($doy+$avs)/7)+1;
	if($avs>3)$num--;
	$out.=($num<10)?'0'.$num:$num;
	break;

	/* Month */
	case'b':
	case'h':
	$out.=jdate_words(array('km'=>$j_m),' ');
	break;

	case'B':
	$out.=jdate_words(array('mm'=>$j_m),' ');
	break;

	case'm':
	$out.=($j_m>9)?$j_m:'0'.$j_m;
	break;

	/* Year */
	case'C':
	$tmp=(int)($j_y/100);
	$out.=($tmp>9)?$tmp:'0'.$tmp;
	break;

	case'g':
	$jdw=($date[6]==6)?0:$date[6]+1;
	$dny=364+$kab-$doy;
	$out.=substr(($jdw>($doy+3) and $doy<3)?$j_y-1:(((3-$dny)>$jdw and $dny<3)?$j_y+1:$j_y),2,2);
	break;

	case'G':
	$jdw=($date[6]==6)?0:$date[6]+1;
	$dny=364+$kab-$doy;
	$out.=($jdw>($doy+3) and $doy<3)?$j_y-1:(((3-$dny)>$jdw and $dny<3)?$j_y+1:$j_y);
	break;

	case'y':
	$out.=substr($j_y,2,2);
	break;

	case'Y':
	$out.=$j_y;
	break;

	/* Time */
	case'H':
	$out.=$date[1];
	break;

	case'I':
	$out.=$date[0];
	break;

	case'l':
	$out.=($date[0]>9)?$date[0]:' '.(int)$date[0];
	break;

	case'M':
	$out.=$date[2];
	break;

	case'p':
	$out.=($date[1]<12)?'قبل از ظهر':'بعد از ظهر';
	break;

	case'P':
	$out.=($date[1]<12)?'ق.ظ':'ب.ظ';
	break;

	case'r':
	$out.=$date[0].':'.$date[2].':'.$date[5].' '.(($date[1]<12)?'قبل از ظهر':'بعد از ظهر');
	break;

	case'R':
	$out.=$date[1].':'.$date[2];
	break;

	case'S':
	$out.=$date[5];
	break;

	case'T':
	$out.=$date[1].':'.$date[2].':'.$date[5];
	break;

	case'X':
	$out.=$date[0].':'.$date[2].':'.$date[5];
	break;

	case'z':
	$out.=date('O',$ts);
	break;

	case'Z':
	$out.=date('T',$ts);
	break;

	/* Time and Date Stamps */
	case'c':
	$key=jdate_words(array('rh'=>$date[6],'mm'=>$j_m));
	$out.=$date[1].':'.$date[2].':'.$date[5].' '.date('P',$ts).' '.$key['rh'].'، '.$j_d.' '.$key['mm'].' '.$j_y;
	break;

	case'D':
	$out.=substr($j_y,2,2).'/'.(($j_m>9)?$j_m:'0'.$j_m).'/'.(($j_d<10)?'0'.$j_d:$j_d);
	break;

	case'F':
	$out.=$j_y.'-'.(($j_m>9)?$j_m:'0'.$j_m).'-'.(($j_d<10)?'0'.$j_d:$j_d);
	break;

	case's':
	$out.=$ts;
	break;

	case'x':
	$out.=substr($j_y,2,2).'/'.(($j_m>9)?$j_m:'0'.$j_m).'/'.(($j_d<10)?'0'.$j_d:$j_d);
	break;

	/* Miscellaneous */
	case'n':
	$out.="\n";
	break;

	case't':
	$out.="\t";
	break;

	case'%':
	$out.='%';
	break;

	default:$out.=$sub;
  }
 }
 return($tr_num!='en')?tr_num($out,'fa','.'):$out;
}

/*	F	*/
function jmktime($h='',$m='',$s='',$jm='',$jd='',$jy='',$none='',$timezone='Asia/Tehran'){
 if($timezone!='local')date_default_timezone_set($timezone);
 if($h===''){
  return time();
 }else{
    list($h,$m,$s,$jm,$jd,$jy)=explode('_',tr_num($h.'_'.$m.'_'.$s.'_'.$jm.'_'.$jd.'_'.$jy));
  if($m===''){
   return mktime($h);
  }else{
   if($s===''){
    return mktime($h,$m);
   }else{
    if($jm===''){
     return mktime($h,$m,$s);
    }else{
     $jdate=explode('_',jdate('Y_j','','',$timezone,'en'));
     if($jd===''){
      list($gy,$gm,$gd)=jalali_to_gregorian($jdate[0],$jm,$jdate[1]);
      return mktime($h,$m,$s,$gm);
     }else{
      if($jy===''){
       list($gy,$gm,$gd)=jalali_to_gregorian($jdate[0],$jm,$jd);
       return mktime($h,$m,$s,$gm,$gd);
      }else{
       list($gy,$gm,$gd)=jalali_to_gregorian($jy,$jm,$jd);
       return mktime($h,$m,$s,$gm,$gd,$gy);
      }
     }
    }
   }
  }
 }
}

/*	F	*/
function jgetdate($timestamp='',$none='',$timezone='Asia/Tehran',$tn='en'){
 $ts=($timestamp==='')?time():tr_num($timestamp);
 $jdate=explode('_',jdate('F_G_i_j_l_n_s_w_Y_z',$ts,'',$timezone,$tn));
 return array(
	'seconds'=>tr_num((int)tr_num($jdate[6]),$tn),
	'minutes'=>tr_num((int)tr_num($jdate[2]),$tn),
	'hours'=>$jdate[1],
	'mday'=>$jdate[3],
	'wday'=>$jdate[7],
	'mon'=>$jdate[5],
	'year'=>$jdate[8],
	'yday'=>$jdate[9],
	'weekday'=>$jdate[4],
	'month'=>$jdate[0],
	0=>tr_num($ts,$tn)
 );
}

/*	F	*/
function jcheckdate($jm,$jd,$jy){
 list($jm,$jd,$jy)=explode('_',tr_num($jm.'_'.$jd.'_'.$jy));
 $l_d=($jm==12)?((((($jy%33)%4)-1)==((int)(($jy%33)*0.05)))?30:29):31-(int)($jm/6.5);
 return($jm>12 or $jd>$l_d or $jm<1 or $jd<1 or $jy<1)?false:true;
}

/*	F	*/
function tr_num($str,$mod='en',$mf='٫'){
 $num_a=array('0','1','2','3','4','5','6','7','8','9','.');
 $key_a=array('۰','۱','۲','۳','۴','۵','۶','۷','۸','۹',$mf);
 return($mod=='fa')?str_replace($num_a,$key_a,$str):str_replace($key_a,$num_a,$str);
}

/*	F	*/
function jdate_words($array,$mod=''){
 foreach($array as $type=>$num){
  $num=(int)tr_num($num);
  switch($type){

	case'ss':
	$sl=strlen($num);
	$xy3=substr($num,2-$sl,1);
	$h3=$h34=$h4='';
	if($xy3==1){
	 $p34='';
	 $k34=array('ده','یازده','دوازده','سیزده','چهارده','پانزده','شانزده','هفده','هجده','نوزده');
	 $h34=$k34[substr($num,2-$sl,2)-10];
	}else{
	 $xy4=substr($num,3-$sl,1);
	 $p34=($xy3==0 or $xy4==0)?'':' و ';
	 $k3=array('','','بیست','سی','چهل','پنجاه','شصت','هفتاد','هشتاد','نود');
	 $h3=$k3[$xy3];
	 $k4=array('','یک','دو','سه','چهار','پنج','شش','هفت','هشت','نه');
	 $h4=$k4[$xy4];
	}
	$array[$type]=(($num>99)?str_replace(array('12','13','14','19','20')
 ,array('هزار و دویست','هزار و سیصد','هزار و چهارصد','هزار و نهصد','دوهزار')
 ,substr($num,0,2)).((substr($num,2,2)=='00')?'':' و '):'').$h3.$p34.$h34.$h4;
	break;

	case'mm':
	$key=array('فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند');
	$array[$type]=$key[$num-1];
	break;

	case'rr':
	$key=array('یک','دو','سه','چهار','پنج','شش','هفت','هشت','نه','ده','یازده','دوازده','سیزده'
 ,'چهارده','پانزده','شانزده','هفده','هجده','نوزده','بیست','بیست و یک','بیست و دو','بیست و سه'
 ,'بیست و چهار','بیست و پنج','بیست و شش','بیست و هفت','بیست و هشت','بیست و نه','سی','سی و یک');
	$array[$type]=$key[$num-1];
	break;

	case'rh':
	$key=array('یکشنبه','دوشنبه','سه شنبه','چهارشنبه','پنجشنبه','جمعه','شنبه');
	$array[$type]=$key[$num];
	break;

	case'sh':
	$key=array('مار','اسب','گوسفند','میمون','مرغ','سگ','خوک','موش','گاو','پلنگ','خرگوش','نهنگ');
	$array[$type]=$key[$num%12];
	break;

	case'mb':
	$key=array('حمل','ثور','جوزا','سرطان','اسد','سنبله','میزان','عقرب','قوس','جدی','دلو','حوت');
	$array[$type]=$key[$num-1];
	break;

	case'ff':
	$key=array('بهار','تابستان','پاییز','زمستان');
	$array[$type]=$key[(int)($num/3.1)];
	break;

	case'km':
	$key=array('فر','ار','خر','تی‍','مر','شه‍','مه‍','آب‍','آذ','دی','به‍','اس‍');
	$array[$type]=$key[$num-1];
	break;

	case'kh':
	$key=array('ی','د','س','چ','پ','ج','ش');
	$array[$type]=$key[$num];
	break;

	default:$array[$type]=$num;
  }
 }
 return($mod==='')?$array:implode($mod,$array);
}
/*	F	*/
function gregorian_to_jalali($gy,$gm,$gd,$mod=''){
	list($gy,$gm,$gd)=explode('_',tr_num($gy.'_'.$gm.'_'.$gd));/* <= Extra :اين سطر ، جزء تابع اصلي نيست */
 $g_d_m=array(0,31,59,90,120,151,181,212,243,273,304,334);
 if($gy > 1600){
  $jy=979;
  $gy-=1600;
 }else{
  $jy=0;
  $gy-=621;
 }
 $gy2=($gm > 2)?($gy+1):$gy;
 $days=(365*$gy) +((int)(($gy2+3)/4)) -((int)(($gy2+99)/100)) +((int)(($gy2+399)/400)) -80 +$gd +$g_d_m[$gm-1];
 $jy+=33*((int)($days/12053));
 $days%=12053;
 $jy+=4*((int)($days/1461));
 $days%=1461;
 $jy+=(int)(($days-1)/365);
 if($days > 365)$days=($days-1)%365;
 if($days < 186){
  $jm=1+(int)($days/31);
  $jd=1+($days%31);
 }else{
  $jm=7+(int)(($days-186)/30);
  $jd=1+(($days-186)%30);
 }
 return($mod==='')?array($jy,$jm,$jd):$jy .$mod .$jm .$mod .$jd;
}

/*	F	*/
function jalali_to_gregorian($jy,$jm,$jd,$mod=''){
	list($jy,$jm,$jd)=explode('_',tr_num($jy.'_'.$jm.'_'.$jd));/* <= Extra :اين سطر ، جزء تابع اصلي نيست */
 if($jy > 979){
  $gy=1600;
  $jy-=979;
 }else{
  $gy=621;
 }
 $days=(365*$jy) +(((int)($jy/33))*8) +((int)((($jy%33)+3)/4)) +78 +$jd +(($jm<7)?($jm-1)*31:(($jm-7)*30)+186);
 $gy+=400*((int)($days/146097));
 $days%=146097;
 if($days > 36524){
  $gy+=100*((int)(--$days/36524));
  $days%=36524;
  if($days >= 365)$days++;
 }
 $gy+=4*((int)(($days)/1461));
 $days%=1461;
 $gy+=(int)(($days-1)/365);
 if($days > 365)$days=($days-1)%365;
 $gd=$days+1;
 foreach(array(0,31,((($gy%4==0) and ($gy%100!=0)) or ($gy%400==0))?29:28 ,31,30,31,30,31,31,30,31,30,31) as $gm=>$v){
  if($gd <= $v)break;
  $gd-=$v;
 }
 return($mod==='')?array($gy,$gm,$gd):$gy .$mod .$gm .$mod .$gd;
}
//##############################################################################
$input=file_get_contents('php://input');
$ip=$_SERVER['REMOTE_ADDR'];
//msg($admin,json_encode($_SERVER));
$update=json_decode($input);
$message=$update->message;
$callback_query=$update->callback_query;
$fd=$message->from->id.$callback_query->from->id;
$cd=$message->chat->id.$callback_query->message->chat->id;
$getchat=Bot('getChatMember',['chat_id'=>"$cd",'user_id'=>$fd])->result->status;
 if($getchant != 'administrator' and $fd != $admin and $cd < 1 ){exit;}
if($getchant != 'administrator' and $fd != $admin){exit;}
if(!$fd){exit;}
//======#
$data =$callback_query->data;
$text = $message->text;
$messageid = $callback_query->message->message_id;
$data_id = $callback_query->id;
$txt = $callback_query->message->text;
$type = $callback_query->message->chat->type;
$username = $message->from->username;
$first_name = $message->from->first_name;
$username = $message->from->username;
$last_name = $message->from->last_name;
$forward_id = $message->forward_from->id;
$forward_chat = $message->forward_from_chat;
$forward_chat_username = $message->forward_from_chat->username;
$forward_chat_msg_id = $message->forward_from_message_id;
$message_id = $message->message_id;
$contact = $message->contact;
$p_num = $contact->phone_number;
$p_name = $contact->first_name;
$p_id = $contact->user_id;
if($p_num){$con = $p_num.'[[+]]'.$p_name;}
$stick = $message->sticker->file_id;
$vid = $message->video->file_id;
$vidn = $message->video_note->file_id;
$voi = $message->voice->file_id;
$doc = $message->document->file_id;
$photo = $message->photo;
$pic = $photo[count($photo) - 1]->file_id;
$aud = $message->audio->file_id;
$caption = $message->caption;
if($caption) $text = $caption;
file_put_contents("up.txt",$input);
$md=$message_id.$messageid;
$Arr1=["[NAME]","[LAST]","[ID]","[USERNAME]","[SAL]","[YEAR]","[MAH]","[MONTH]","[MAAH]","[MOONTH]","[ROZ]","[DAY]","[ROOZ]","[DAAY]","[HOUR]","[MIN]","[SEC]","[HEIVAN_SAL]","[BASTAN_SAL]","[FASL]","[SAL2]"];
$Arr2=["$first_name","$last_name",$fd,$username,jdate('Y'),date('Y'),jdate('m'),date('n'),jdate('F'),date('M'),jdate('d'),date('d'),jdate('l'),date('l'),date('H'),date('i'),date('s'),jdate('q'),jdate('p'),jdate('f'),jdate('y')];
//======#

//======#
$lock=file_get_contents("lock.txt");
$start_text=file_get_contents("start.text");
$gp_stats=file_get_contents("gp_stats.txt");
$stats=file_get_contents("stats.txt");
$rdata=json_decode(file_get_contents("rdata.json"),true);
$SEND=json_decode(file_get_contents('send.json'),true);
$com=file_get_contents("$fd.txt");
//======#SEN
if($SEND["send"]["type"]){
        $TP=$SEND["send"]["type"];
        $view=$SEND["send"]["view"];
    if($fd and $cd == $fd and strpos($view,$fd) === false and ($TP =='PV-TXT' or $TP=='PV-FWD')){
        if($TP=='PV-TXT'){ //===TXT-PV
                $ok=msg($cd,str_replace($Arr1,$Arr2,$SEND['send']['text']
                ),'MarkdownV2')->result->message_id;
                if(!$ok) $ok2=msg($cd,str_replace($Arr1,$Arr2,$SEND['send']['text']),'Markdown')->result->message_id;
                if(!$ok2 and !$ok) msg($cd,str_replace($Arr1,$Arr2,$SEND['send']['text']));
               }elseif($TP=='PV-FWD'){
                fwd($cd,$SEND['send']['cd'],$SEND['send']['fd']);
            }
            $SEND["send"]["view"]=$view."-$fd";
            file_put_contents('send.json',json_encode($SEND));
            exit;
        }elseif($cd and $fd != $cd and strpos($view,$cd) === false and ($TP =='GP-TXT' or $TP=='GP-FWD')){
               if($TP=='GP-TXT'){
                $ok=msg($cd,$SEND['send']['text'],'MarkdownV2')->result->message_id;
               if(!$ok) $ok2=msg($cd,$SEND['send']['text'],'Markdown')->result->message_id;
               if(!$ok2 and !$ok) msg($cd,$SEND['send']['text']);
               }elseif($TP=='GP-FWD'){
                fwd($cd,$SEND['send']['cd'],$SEND['send']['fd']);
            }
            $SEND["send"]["view"]=$view."$cd";
            file_put_contents('send.json',json_encode($SEND));
            exit;
        }
    
}
//======#
if(strpos($stats,$fd) === false and $fd and $cd) file_put_contents('stats.txt',"$fd\n$stats");
if(strpos($gp_stats,$cd) === false and $cd != $fd and $cd and $fd) file_put_contents('gp_stats.txt',"$cd\n$gp_stats");
//======#
$baddr='افزودن پاسخ';
$bremr='حذف پاسخ';
$bstat='آمار';
$bstxt='متن شروع';
$baddc='ثبت کانال';
$block='قفل کانال';
$blastr='آخرین پیام های افزوده شده';
$bsend='پیام همگانی';
$bsends='آخرین پیام';
//======#DEFAULT
if(!$start_text) $start_text = 'سلام ! من بات سخنگو ام
اگه میخوایی تو گروهت فعالیت کنم دکمه افزودن رو بزن و بعدش ادمینم کن تا بتونم پیام اعضای گپ رو مدیریت کنم و به برخی از پیام ها شون پاسخ بدم';
$a_key=json_encode(['keyboard'=>[
    ["$baddr","$bremr"],
        ["$bstat","$baddc"],
            ["$block","$bstxt"],
    ["$blastr"],
    ["$bsend","$bsends"],
    ]]);
    $send_key=json_encode(['keyboard'=>[
               ["ارسال متن در گروه","ارسال فروارد در گروه"],
["ارسال متن به کاربران","ارسال فروارد به کاربران"],
                ["برگشت به منوی اصلی"]
                ]]);
    $c_key=json_encode(['keyboard'=>[
    ["برگشت به منوی اصلی"],
    
    ],'resize_keyboard'=>true]);
$start_key=json_encode(['inline_keyboard'=>[
    [['text'=>"➕ افزودن ".Bot('getme')->result->first_name." به گروه ➕","url"=>"https://telegram.me/".Bot('getMe',[])->result->username."?startgroup=1"]],
    [['text'=>"📢 کانال اطلاع رسانی📣","url"=>"http://t.me/$channel"]],
    ]]);
//=====#
//msg($admin,$input);
$JOIN=Bot('getChatMember',['chat_id'=>"@$channel",'user_id'=>$fd])->result->status;
if($text) $REPLY=$rdata["$text"]["type"];
if($REPLY and $cd != $fd){
    $type=$rdata["$text"]["type"];
    $reply=$rdata["$text"]["data"];
    $tdd=count($reply)-1;
    $R=rand(0,$tdd);
if($type=='رندوم'){
        $ok=msg($cd,str_replace($Arr1,$Arr2,$reply[$R]),'','MarkdownV2','',$md)->result->message_id;
        if(!$ok) msg($cd,str_replace($Arr1,$Arr2,$reply[$R]),'',' ','',$md);
    }
elseif($type=='ترتیبی'){
        for($i=0;$i<=$tdd;$i++){
             if($reply[$i]) $ok=msg($cd,str_replace($Arr1,$Arr2,$reply[$i]),'','MarkdownV2','',$md)->result->message_id;
             if(!$ok)msg($cd,str_replace($Arr1,$Arr2,$reply[$i]),'',' ','',$md);
        }
        }
else{
        $ok=msg($cd,str_replace($Arr1,$Arr2,$rdata["$text"]["data"]),'','MarkdownV2','',$md)->result->message_id;
        if(!$ok)msg($cd,str_replace($Arr1,$Arr2,$rdata["$text"]["data"]),'','','',$md);
    }
}elseif($cd == $fd and $channel and $lock== 'on' and (!$JOIN or $JOIN=='kicked' or $JOIN=='left')){
    if($data) dlt($cd,$md);
    msg($cd,"🔰 برای حمایت از اسپانسر ربات لطفا در کانال زیر عضو شوید و دکمه عضو شدم را بزنید.
    $JOIN
@$channel",json_encode(['inline_keyboard'=>[
      [['text'=>"JOIN | عضویت",'url'=>"https://t.me/$channel"]],
       [['text'=>"برسی عضویت",'callback_data'=>"/start"]]  
]]));
}elseif($rdata["$data"]["type"] and $cd == $admin){
    $get=$data;
    msg($cd,"💬".$rdata["$get"]["backup"]);
    }elseif(preg_match('/\/([Ss][Tt][Aa][Rr][Tt])/',$text) or $data=='/start'){
    $bot_id=bot('getme')->result->id;
    if($data) dlt($cd,$md);
    $rank=bot("getchatmember",['chat_id'=>$cd,'user_id'=>$bot_id])->result->status;
if($cd==$fd){
      msg($cd,$start_text,$start_key);
msg($cd,'به ربات خودتان خوش اومدید !
/panel ====> مدیریت');
       }elseif($cd != $fd and $rank == 'member'){
       msg($cd,$start_text);
   }elseif($cd==$fd){ msg($cd,$start_text,$start_key);
   }else{
       exit;
   }
}
#################
elseif($cd != $fd){
    exit;
}
#################
elseif( $cd == $admin and $text=='راهنما و کد ها' or $text == '/help'){
    msg($cd,'
    💠 کد های مارک کردن متن :
*bold \*text* 
*درشت*
_italic \_ text_
_ خمیده_
[inline URL](http://www.example.com/)
[متن لینک](لینک)
[inline mention of a user](tg://user?id=123456789)
[نام کاربر](tg://user?id=ایدی کاربر)
`CODE`
`کد`
🔷 کد های نمایش تاریخ میلادی در متن
[YEAR]    —————> سال
[MONTH]  —————>  ماه
[DAY]  —————>  روز
[MOONTH]  —————>  نام ماه
[DAAY]  —————>  نام روز
[HOUR] —————> ساعت
[MIN] —————> دقیقه
[SEC] —————> ثانیه
🔶کد های نمایش تاریخ شمسی در متن
[SAL]  —————>  سال 
[SAL2] —————> سال 2 رقمی
[MAH]  —————>  ماه
[ROZ]  —————>  روز
[MAAH]  —————>  نام ماه
[ROOZ]  —————>  نام روز 
[FASL] —————> نام فصل
[HEIVAN_SAL] —————> نام حیوان سال
[BASTAN_SAL] —————> نام باستانی سال
🔰کد های نمایش مشخصات :
[NAME]  —————>  نام کاربر
[LAST]  —————>  نام خانوادگی کاربر
[ID]  —————>  آیدی عددی کاربر
[USERNAME]  —————>  آیدی بدون @ کاربر
');
msg($cd,"
📄 ایجاد قالب  پیام تک جواب :
=======================
پیام کاربر
پاسخ پیام
=======================
👇🏻مثال
");
msg($cd,"سلام
درود !
حالت چطوره ؟
چه خبر ؟"
);
msg($cd,"پیام و پاسخ تصادفی به این صورت ارسال کنید (با , جدا کنید📄 ایجاد قالب  پیام تصادفی (رندوم)  :
💱 علامت جدا کننده :  ,    (نام : کاما : comma)
=======================
پیام کاربر
پاسخ تصادفی 1
,
پاسخ تصادفی 2
,
پاسخ تصادفی 3
========================
👇🏻مثال ");
msg($cd,"
چه رنگی دوست داری ؟
قرمز
,
زرد
,
آبی
,
نارنجی
");
msg($cd,"
📄 ایجاد قالب  پیام ترتیبی :
💱 علامت جدا کننده :  ~    (نام : مدک : tilde)
=======================
پیام کاربر
پاسخ شماره 1
~
پاسخ شماره 2
~
پاسخ شماره 3
========================
👇🏻مثال
");

msg($cd,"بخند
ههههه
~
خخخخ
~
قار قار قار
");}
#################
elseif(($text == '/cancel' or $text =='برگشت به منوی اصلی' or $text=='/panel' or $text=='مدیریت') and $cd == $admin){
msg($cd,'پنل مدیریت ربات برای شما باز شد !',$a_key);
if($fd==$admin) file_put_contents("$fd.txt",'none');
}elseif($text == '/CANCEL_SEND' and $cd == $admin){
msg($cd,'ارسال پیام متوقف شد !',$a_key);
file_put_contents("$fd.txt",'none');
file_put_contents("send.json",'');
}elseif($com=='stxt' and $fd == $admin){
    if($text){
        msg($cd,'✅ متن جدید استارت ثبت شد 
/start',$a_key);
        file_put_contents('start.text',$text);
        file_put_contents($fd.'.txt','none');
    }else{
        msg($cd,'باید در قالب متن ارسال کنید !',$c_key);
    }
    }elseif($com=='addC' and $fd == $admin){
    $str=str_replace('@','',$text);
    $Join=Bot('getChatMember',['chat_id'=>'@'.$str,'user_id'=>$fd])->result->status;
    if($Join){
   msg($cd,"✅ کانال جدید ثبت شد",$a_key);
    file_put_contents('channel.txt',$str);
     file_put_contents($fd.'.txt','none');
    }else{
        msg($cd,"🛑 خطایی رخ داد 
آیدی کانال را برسی کرده و سپس مطمئن شوید ربات در کانال ادمین بوده و شما نیز در کانال عضو میباشید
",$c_key);
    }
    }elseif($com=='send' and $fd == $admin){
    if($text=='ارسال متن در گروه'){
        $TP='GP-TXT';
        msg($cd,'متن مورد نظر خود را ارسال کنید',$c_key);
    }elseif($text=='ارسال فروارد در گروه'){
            $TP='GP-FWD';
        msg($cd,'پیام مورد نظر خود را فروارد کنید',$c_key);
}elseif($text=='ارسال متن به کاربران'){
           $TP='PV-TXT';
        msg($cd,'متن مورد نظر خود را ارسال کنید',$c_key);
           
 }elseif($text=='ارسال فروارد به کاربران'){
            $TP='PV-FWD';
        msg($cd,'پیام مورد نظر خود را فروارد کنید',$c_key);
}else{
    msg($cd,'از کیبورد انتخاب کنید !',$send_key);
    exit;
}
    $SEND["temp"]["type"]=$TP;
    file_put_contents("send.json",json_encode($SEND));
    file_put_contents("$fd.txt",'send2');
    }elseif($com=='send2' and $fd == $admin){
    $TP=$SEND["temp"]["type"];
    if($text and !$caption and  ($TP=='GP-TXT' or $TP == 'PV-TXT')){
        $SEND["send"]["text"]=$text;
    }elseif($md and $cd and $message->forward_from->id and ($TP=='GP-FWD' or $TP == 'PV-FWD')){
        $SEND["send"]["cd"]=$cd;
        $SEND["send"]["fd"]=$md;
    }else{
        msg($cd,"لطفا محتوا را به درستی ارسال کنید !",$c_key);
        exit;
    }
    $SEND['send']['type']=$TP;
    unset($SEND['temp']);
    unset($SEND['send']['view']);
    
    msg($cd,'✅ پیام در صف قرار گرفت '.
    "\n/CANCEL_SEND - لغو ارسال",$a_key);
    file_put_contents("send.json",json_encode($SEND));
    file_put_contents("$fd.txt",'none');
    }elseif($com=='remReply' and $fd == $admin){
    $BUP=$rdata["$text"]["backup"];
    if($BUP){
msg($cd,$BUP);
msg($cd,"👆حذف شد",$a_key);
unset($rdata["$text"]);
file_put_contents('rdata.json',json_encode($rdata));
file_put_contents("$fd.txt",'none');
    }else{
        msg($cd,'همچین پیامی یافت نشد !
دوباره تلاش کنید',$c_key);
    }
    }elseif($com=='addReply' and $fd == $admin){
$PM=explode("\n",$text)[0];

$str=str_replace(["~\n~",",\n,"],["~",","],$text);
$E=explode("$PM\n",$text)[1];
$Rep=$E.explode("$PM\n$E",$text)[1];
$REXP=explode("\n,\n",$Rep);
$TEXP=explode("\n~\n",$Rep);
$TR=count($REXP);
$TT=count($TEXP);
if(!$Rep){
    msg($cd,'پاسخ بصورت صحیح ارسال نشده !
برسی کنید پیام دارای مشکلی نمیباشد
به راهنما دقت کنید !
',$c_key);
exit;
}elseif($TT>10){
    msg($cd,'
    🛑 از تعیین بیش از 10 پیام ترتیبی خوداری کنید !!
⚠️پیام ترتیبی بیشتر موجب کندی و فشار بر روی هاست و از طرفی دیگر تلگرام ربات را اسپمر شناسایی و مسدود میکند !
',$c_key);
    exit;
    }elseif(strlen($PM>60)){
        msg($cd,"⚠️ حجم پیام خیلی زیاد است ! جهت جلوگیری از بروز اختلال در ربات پیام را کمتر از 30 حرف  ارسال کنید!",$c_key);
     exit;
        }elseif($rdata["$PM"]){
    msg($cd,'این پیام قبلا ثبت شده است !',$c_key);
    exit;
    }elseif($TR > 1){
    $rdata["$PM"]["data"]=$REXP;
    $TYPE='رندوم';
    $rdata["$PM"]["type"]=$TYPE;

}elseif($TT > 1){
     $rdata["$PM"]["data"]=$TEXP;
    $TYPE='ترتیبی';
  $rdata["$PM"]["type"]=$TYPE;
}elseif($Rep){
     $rdata["$PM"]["data"]=$Rep;
    $TYPE='تنها';
  $rdata["$PM"]["type"]=$TYPE;
}
$rdata["$PM"]["backup"]=$text;
msg($admin,$Rep);
msg($cd,"
پیام : $PM
نوع پاسخ دهی : $TYPE
 پاسخ ثبت شد میتوانید به ارسال پیایم و پاسخ جدید ادامه دهید و یا با /cancel منصرف شید",$c_key);
 file_put_contents('rdata.json',json_encode($rdata));
    }elseif($fd == $admin and $text==$bremr){
        msg($cd,"🗣 پیامی که میخواهید حذف شود را ارسال کنید ",$c_key);
        file_put_contents("$fd.txt",'remReply');
        }elseif($fd == $admin and $text==$bsends){
            $TP=$SEND["send"]["type"];
            $view=$SEND["send"]["view"];

            $v=count(explode('-',$view))-1;
            $str=str_replace(["-","GP","PV","TXT","FWD"],["⟺","گروه","کاربر","متن","فروارد"],$TP);
            $T=explode('⟺',$str);
            $TO=$T[0];
            $DATATO=$T[1];
            $TEXT="👆 این پیام در صف ارسال قرار دارد .

🔰 ارسال میشود به : $TO ها

📄محتوای ارسالی : $DATATO

👁‍🗨 تعداد $TO بازدید کننده : $v
\n/CANCEL_SEND - لغو ارسال";


            if($TP=='PV-TXT' or $TP=='GP-TXT'){
                $MSGID=msg($cd,$SEND['send']['text'])->result->message_id;
            }else{
                $MSGID=fwd($cd,$SEND['send']['cd'],$SEND['send']['fd'])->result->message_id;
            }
            if (!$TP) $TEXT='❗️ پیامی در صف ارسال نیست !';
        msg($cd,"$TEXT",'','','',$MSGID);
        }
elseif($fd == $admin and $text==$block){
    if(!$channel){
        msg($cd,'⚠️ هنوز کانالی ثبت نکردید');
        }elseif($lock=='on'){
           msg($cd,"🔓 قفل عضویت در کانال غیر فعال شد",$c_key);
        file_put_contents("lock.txt",'0');
    }else{
           msg($cd,"🔐 قفل عضویت در کانال  فعال شد",$c_key);
     file_put_contents("lock.txt",'on');  
    }}elseif($fd == $admin and $text==$baddc){
        msg($cd,"🛑 مطمئن شوید ربات در کانال ادمین میباشد
🔰 آیدی کانال را با @ یا بدون @ ارسال کنید :",$c_key);
        file_put_contents("$fd.txt",'addC');
        }elseif($fd == $admin and $text==$bsend){
            msg($cd,'⚠️توجه: با ارسال پیام جدید پیام قبلی از لیست حذف میشود !
🔰خب ، چه محتوایی و در کجا میخواهید ارسال کنید ؟',$send_key);
             file_put_contents("$fd.txt",'send');  
}elseif($fd == $admin and $text==$bstxt){
        msg($cd,"
متن جدید دکمه استارت را ارسال کنید
توجه داشته باشید متن دارای معرفی نامه 
راهنما باشد

مثال :
👋🏻 سلام رفیق من بات سخنگو هستم
اگه میخوایی تو گروهت فعالیت داشته باشم دکمه افزودن در گروه رو بزن بعدش ادمینم کن تا بتونم پیام اعضا رو مدیریت کنم و به برخی از پیام ها شون پاسخ بدم👌🏻
",$c_key);
        file_put_contents("$fd.txt",'stxt');
        }elseif($fd == $admin and $text==$baddr){
        msg($cd,"قالب پیام و پاسخ را ارسال کنید :
توجه : اگر نحوه ارسال قالب را بلد نیستید از /help کمک بگیرید.",$c_key);
file_put_contents("$admin.txt",'addReply');
    }elseif($fd == $admin and $text==$bstat){
        $MD=msg($cd,'♻️ در حال پردازش مشخصات ....',json_encode(['remove_keyboard'=>true]))->result->message_id;
        $SP=explode("\n",$stats);
        $GP=explode("\n",$gp_stats);
        $tdds=count($SP)-1;
        $tddg=count($GP)-1;
        for($i=0;$i<=10;$i++){
            $ID=$SP[$i];
            $GC=Bot("getchat",['chat_id'=>$ID])->result;
            $un=$GC->first_name;
            $uu=$GC->username;
            if($ID)$X.="\n[$un | @$uu](tg://user?id=$ID)";
        }
        for($i=0;$i<=10;$i++){
            $ID=$GP[$i];
            $GC=Bot("getchat",['chat_id'=>$ID])->result;
            $un=$GC->title;
            $uu=$GC->type;
            if($ID)$Z.="\n[$un <<$uu>>](tg://user?id=$ID)";
        }
        dlt($cd,$MD);
        $ok = msg($cd,"👤 تعداد کاربران ربات :$tdds
👥 تعداد گروه ها : $tddg

➕تعداد 10 کاربر جدید :$X
➕تعداد 10 گروه جدید :$Z"
,$a_key,'MarkdownV2')->result->message_id;
if(!$ok) $ok2 = msg($cd,"👤 تعداد کاربران ربات :$tdds
👥 تعداد گروه ها : $tddg

➕تعداد 10 کاربر جدید :$X
➕تعداد 10 گروه جدید :$Z"
,$a_key,'Markdown')->result->message_id;
if(!$ok2 and !$ok)msg($cd,"👤 تعداد کاربران ربات :$tdds
👥 تعداد گروه ها : $tddg

➕تعداد 10 کاربر جدید :$X
➕تعداد 10 گروه جدید :$Z"
,$a_key);
    file_put_contents($fd.'.txt','none');
}elseif($fd == $admin and $text==$blastr){
    $tdd=count($rdata);
    $AK=array_keys($rdata);
    $tdd=count($AK);
    $min=0;
    if($tdd>30) $min=$tedd-30;
    $ubot=bot('getme')->result->username;
    $keyboard=array();
    for($i=($tdd);$i>=$min;$i--){
        $key=$AK[$i];
        if($rdata[$key]["type"] ){
            $a=round($a);
        $keyboard[$a][0]['text']=$key;
        $keyboard[$a][0]['callback_data']=$key;
  $X=':'; $a++; }
    }
    if(!$X) $X="\nپیامی اضافه نکردید !";
    msg($admin,"📊 لیست پیام جدید[🗣: پیام کاربر    |🤖 : پیام ربات ]$X"
,json_encode(['inline_keyboard'=>$keyboard]));
}/*elseif($fd == $admin and $text==0){
    
}elseif($fd == $admin and $text==0){
    
}elseif($fd == $admin and $text==0){
    
}elseif($fd == $admin and $text==0){
    
}*/
elseif($text==$bstat){
$EXP=explode("\n",$gp_stats)[10];
$EXP2=explode("\n",$stats)[10];
    
}elseif($REPLY){
    $type=$REPLY;
    $reply=$rdata["$text"]["data"];
    $tdd=count($reply)-1;
    $R=rand(0,$tdd);
    if($type=='رندوم'){
        $ok=msg($cd,str_replace($Arr1,$Arr2,$reply[$R]),'','MarkdownV2','',$md)->result->message_id;
        if(!$ok) msg($cd,str_replace($Arr1,$Arr2,$reply[$R]),'',' ','',$md);
    }elseif($type=='ترتیبی'){
        for($i=0;$i<=$tdd;$i++){
             if($reply[$i]) $ok=msg($cd,str_replace($Arr1,$Arr2,$reply[$i]),'','MarkdownV2','',$md)->result->message_id;
             if(!$ok)msg($cd,str_replace($Arr1,$Arr2,$reply[$i]),'',' ','',$md);
        }
        }else{
        $ok=msg($cd,str_replace($Arr1,$Arr2,$rdata["$text"]["data"]),'','MarkdownV2','',$md)->result->message_id;
        if(!$ok)msg($cd,str_replace($Arr1,$Arr2,$rdata["$text"]["data"]),'','','',$md);
    }
}elseif($cd==$fd){
    $ok=msg($cd,str_replace($Arr1,$Arr2,$text),'','MarkdownV2','',$md)->result->message_id;
        if(!$ok)$ok2=msg($cd,str_replace($Arr1,$Arr2,$text),'','Markdown','',$md);
        if(!$ok and !$ok2)msg($cd,str_replace($Arr1,$Arr2,$text),'','','',$md);
    
}



 clearstatcache();
unlink("error_log");
?>