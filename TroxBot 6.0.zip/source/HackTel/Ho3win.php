<?php
include 'jdf.php';
ob_start();
$telegram_ip_ranges = [
['lower' => '149.154.160.0', 'upper' => '149.154.175.255'], 
['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],    
];
$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
$ok=false;
foreach ($telegram_ip_ranges as $telegram_ip_range) if (!$ok) {
$lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
$upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
if($ip_dec >= $lower_dec and $ip_dec <= $upper_dec) $ok=true;
}
if(!$ok) die("Sik :)");
define('API_KEY','[*[TOKEN]*]');
function bot($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
 $res = curl_exec($ch);
 if(curl_error($ch)){
var_dump(curl_error($ch));
}else{
return json_decode($res);
}
}
$admin = "[*[ADMIN]*]"; 
$bot_id ="[*[USERNAME]*]";
$channel = "[*[CHANNEL]*]";
$channel1 = "[*[CHANNEL]*]";

function SendMessage($chat_id, $text, $key){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>$text,
'reply_markup'=> $key,
]);
}
function sendphoto($chat_id, $photo, $caption){
bot('sendphoto',[
'chat_id'=>$chat_id,
'photo'=>$photo,
'caption'=>$caption,
 ]);
 }
 function Forward($chat_id,$from_id,$massege_id){
    bot('ForwardMessage',[
    'chat_id'=>$chat_id,
    'from_chat_id'=>$from_id,
    'message_id'=>$massege_id
    ]);
}

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$text = $message->text;
$chat_id = $message->chat->id;
$from_id = $message->from->id;
$first_name = $message->from->first_name;
$message_id2 = $update->callback_query->message->message_id;
$chatid = $update->callback_query->message->chat->id;
$data = $update->callback_query->data;
$message_id = $update->message->message_id;
$zir = file_get_contents('data/'.$from_id.'/zir.txt');
$members = file_get_contents('members.txt');
$memlist = explode("\n", $members);
$truechannel = json_decode(file_get_contents('https://api.telegram.org/bot'.API_KEY."/getChatMember?chat_id=@$channel&user_id=".$chat_id));
$tch = $truechannel->result->status;
$truechannel1 = json_decode(file_get_contents('https://api.telegram.org/bot'.API_KEY."/getChatMember?chat_id=@$channel1&user_id=".$chat_id));
$tch1 = $truechannel1->result->status;
$sh = '2'; $sh1 = '4'; $sh2 = '3'; $sh3 = '6'; $sh4 = '1'; $sh5 = '7'; $sh6 = '5'; $date = date('w');
$az = array("0","1","2","3","4","5","6");
$be = array($sh,$sh1,$sh2,$sh3,$sh4,$sh5,$sh6);
$nafar = str_replace($az,$be,$date);
$nafar2 = $nafar + 1;

$button_official = json_encode(['keyboard'=>[[['text' => '💭 دریافت عکس و تعداد متن ارسالی اکانت هدف'],['text' => '📲 دریافت نام مخاطبین درحال چت با اکانت هدف']],[['text' => '👥چند نفر رو عضو کردم'],['text' => '📑بنر دعوت']]],'resize_keyboard'=>true]);
$button_start = json_encode(['inline_keyboard'=>[[['text' => 'شروع','callback_data' => 'start']]]]);
$button_baner = json_encode(['inline_keyboard'=>[[['text' => 'بنر دعوت','callback_data' => 'baner']]]]);
$button_admin = json_encode(['keyboard' =>[[['text' => 'امار ربات']],[['text' => 'پیام همگانی'],['text' => 'فروارد همگانی']],[['text' => 'فرستادن پیام همگانی پیام سیستم']]],'resize_keyboard'=>true]);
$button_back_admin = json_encode(['keyboard' =>[[['text' => 'برگشت']]],'resize_keyboard'=>true]);

if($text == '/start'){
	if($tch != 'member' && $tch != 'creator' && $tch != 'administrator' or $tch1 != 'member' && $tch1 != 'creator' && $tch1 != 'administrator' or $tch1 != 'member' && $tch1 != 'creator' && $tch1 != 'administrator'){
		SendMessage($chat_id,"سلام ‌ ‍$first_name عزیز 🌹\n
💢 برای فعال شدت ربات 

باید در کانال زیر عضو شوید 👇
👉 @$channel1 @$channel
👉 @$channel1 @$channel",json_encode(['inline_keyboard'=>[[['text'=>'عضو شدم!','callback_data'=>'join']]]]));
	}else{
	SendMessage($chat_id,"سلام ‌ $first_name عزیز 🌹\n
به ربات هَک تلگرام (غیر قانونی)
خوش اومدی🌹

💯 مهم : لطفا با دقت دستورات رو بخونید تا کامل متوجه بشید.

برای شروع روی دکمه شروع کلیک کن 👇",$button_start);
	}
if(!in_array($from_id,$memlist)){
	mkdir("data/$from_id");
	$newmem = file_get_contents('members.txt');
	$newmem .= $from_id . "\n";
	file_put_contents('members.txt',$newmem);
	file_put_contents('data/'.$from_id.'/zir.txt','0');
}}
elseif(strpos($text, '/start') !== false ){
	$newid = str_replace("/start ", "", $text);
	if($from_id == $newid){
		if($tch != 'member' && $tch != 'creator' && $tch != 'administrator' or $tch1 != 'member' && $tch1 != 'creator' && $tch1 != 'administrator'){
		SendMessage($chat_id,"سلام ‌ ‍$first_name عزیز 🌹\n
💢 برای فعال شدت ربات 

باید در کانال زیر عضو شوید 👇
👉 @$channel1 @$channel
👉 @$channel1 @$channel",json_encode(['inline_keyboard'=>[[['text'=>'Joined!','callback_data'=>'join']]]]));
	}else{
		SendMessage($chat_id,"سلام ‌ $first_name عزیز 🌹\n
به ربات هَک تلگرام (غیر قانونی)
خوش اومدی🌹

💯 مهم : لطفا با دقت دستورات رو بخونید تا کامل متوجه بشید.

برای شروع روی دکمه شروع کلیک کن 👇",$button_start);
	}}
	elseif(strpos($members, "$from_id") !== false){
		if($tch != 'member' && $tch != 'creator' && $tch != 'administrator' or $tch1 != 'member' && $tch1 != 'creator' && $tch1 != 'administrator'){
		SendMessage($chat_id,"سلام ‌ ‍$first_name عزیز 🌹\n
💢 برای فعال شدت ربات 

باید در کانال زیر عضو شوید 👇
👉 @$channel1 @$channel
👉 @$channel1 @$channel",json_encode(['inline_keyboard'=>[[['text'=>'Joined!','callback_data'=>'join']]]]));
	}else{
		SendMessage($chat_id,"سلام ‌ $first_name عزیز 🌹\n
به ربات هَک تلگرام (غیر قانونی)
خوش اومدی🌹

💯 مهم : لطفا با دقت دستورات رو بخونید تا کامل متوجه بشید.

برای شروع روی دکمه شروع کلیک کن 👇",$button_start);
	}}
	else{
		if($tch != 'member' && $tch != 'creator' && $tch != 'administrator' or $tch1 != 'member' && $tch1 != 'creator' && $tch1 != 'administrator'){
		SendMessage($chat_id,"سلام ‌ ‍$first_name عزیز 🌹\n
💢 برای فعال شدت ربات 

باید در کانال زیر عضو شوید 👇
👉 @$channel1 @$channel
👉 @$channel1 @$channel",json_encode(['inline_keyboard'=>[[['text'=>'Joined!','callback_data'=>'join']]]]));
	}else{
		SendMessage($chat_id,"سلام ‌ $first_name عزیز 🌹\n
به ربات هَک تلگرام (غیر قانونی)
خوش اومدی🌹

💯 مهم : لطفا با دقت دستورات رو بخونید تا کامل متوجه بشید.

برای شروع روی دکمه شروع کلیک کن 👇",$button_start);
	}
if(!in_array($from_id,$memlist)){
	mkdir("data/$from_id");
	$newmem = file_get_contents('members.txt');
	$newmem .= $from_id . "\n";
	file_put_contents('members.txt',$newmem);
	file_put_contents('data/'.$from_id.'/zir.txt','0');
	file_put_contents('data/'.$newid.'/zir.txt',file_get_contents('data/'.$newid.'/zir.txt') + 1);
	SendMessage($newid,"یک نفر با لینک شما وارد ربات شد");
}}}
elseif($data == 'start'){
	$zir = file_get_contents('data/'.$chatid.'/zir.txt');
	$baghi = 7 - $zir;
	 bot('deletemessage',['chat_id' => $chatid,'message_id' => $message_id2,]);
	SendMessage($chatid,"📱به ربات هک تلگرام (غیر قانونی)خوش اومدین🌹

💯با دقت مطالعه کنید💯

⚒ کارایی های ربات : 

1⃣ توانایی تشخیص نام مخاطبینی که در حال چت در اکانت هک شده هستند.  

❗️این ربات توانایی تشخیص متن پیام ها را (ندارد).

2⃣ توانایی ذخیره عکس های ارسالی در اکانت هک شده.

❗️عکس هایی با حجم کمتر از (280kb) را میتواند ذخیره و به شما ارسال کند.

❗️در روز ربات قادر به ارسال (۲) عکس به شما میباشد ما بقی فقط اطلاع داده میشود.

3⃣ توانایی تشخیص تعداد پیام های ارسالی اکانت هک شده در طول یک روز.

❗️ربات فقط تعداد پیام ها در روز را اطلاع میدهد.

✅ نحوه کار : 

🌐ابتدا ربات به شما رباتی را معرفی میکند.
یک ربات مانند ربات استیکر ساز و ... بخاطر شک نکردن مخاطب شما ... ربات فقط جهت دریافت اطلاعات(ربات دزد اطلاعات) میباشد. 
به طوری که اکانت هدف(شخصی که قصد هک کردنش رو دارید اکانت هدف نام دارد) شک نکند.

تنها کار شما این است که اکانت هدف () رو وارد آن ربات(دزد اطلاعات) کنید.

به همین راحتی 😉 ادامه کار با ربات ماست. 


⭕️ توجه داشته باشید این ربات تست شده است.

🔴🔴🔴 به دلیل هزینه سنگین ربات شما باید 7⃣ نفر رو از طریق بنر مخصوص خود حتما وارد ربات کنید.

کافیست روی دکمه 📑بنر دعوت یا بروی 👈  /eshterak لمس کنید.

💯 لطفا متن بالا رو کامال مطالعه کنید 👆💯

🔴 شما تاکنون $zir نفر را عضو کردید
🔵 برای فعال شدن $baghi نفر",$button_official);
}
elseif($data == 'baner'){
	SendPhoto($chatid,'https://eps.piko-host.ir/BotsazLorex8304/media/HackTel.jpg',"🔴ربات غیر قانونی هک تلگرام رسید.

💯 اخطار : ربات هیچ مسعولیتی در قبال استفاده کاربران ندارد.

کامل مطالعه کنید 👇
لینک ربات قدرتمند هک تلگرام 👇
https://t.me/$bot_id?start=$chatid");
}	
elseif($data == 'join'){
$truechannel2 = json_decode(file_get_contents('https://api.telegram.org/bot'.API_KEY."/getChatMember?chat_id=@$channel&user_id=".$chatid));
$tch2 = $truechannel2->result->status;
	if($tch2 != 'member' && $tch2 != 'creator' && $tch2 != 'administrator'){
	    bot('answercallbackquery', ['callback_query_id' =>$update->callback_query->id,'text' =>"شما هنوز عضو کانال @$channel نشده اید" ,'show_alert' =>true,]);
	}else{
	     bot('deletemessage',['chat_id' => $chatid,'message_id' => $message_id2,]);
	$zir = file_get_contents('data/'.$chatid.'/zir.txt');
	$baghi = 7 - $zir;
	 bot('deletemessage',['chat_id' => $chatid,'message_id' => $message_id2,]);
	SendMessage($chatid,"📱به ربات هک تلگرام (غیر قانونی)خوش اومدین🌹

💯با دقت مطالعه کنید💯

⚒ کارایی های ربات : 

1⃣ توانایی تشخیص نام مخاطبینی که در حال چت در اکانت هک شده هستند.  

❗️این ربات توانایی تشخیص متن پیام ها را (ندارد).

2⃣ توانایی ذخیره عکس های ارسالی در اکانت هک شده.

❗️عکس هایی با حجم کمتر از (280kb) را میتواند ذخیره و به شما ارسال کند.

❗️در روز ربات قادر به ارسال (۲) عکس به شما میباشد ما بقی فقط اطلاع داده میشود.

3⃣ توانایی تشخیص تعداد پیام های ارسالی اکانت هک شده در طول یک روز.

❗️ربات فقط تعداد پیام ها در روز را اطلاع میدهد.

✅ نحوه کار : 

🌐ابتدا ربات به شما رباتی را معرفی میکند.
یک ربات مانند ربات استیکر ساز و ... بخاطر شک نکردن مخاطب شما ... ربات فقط جهت دریافت اطلاعات(ربات دزد اطلاعات) میباشد. 
به طوری که اکانت هدف(شخصی که قصد هک کردنش رو دارید اکانت هدف نام دارد) شک نکند.

تنها کار شما این است که اکانت هدف () رو وارد آن ربات(دزد اطلاعات) کنید.

به همین راحتی 😉 ادامه کار با ربات ماست. 


⭕️ توجه داشته باشید این ربات تست شده است.

🔴🔴🔴 به دلیل هزینه سنگین ربات شما باید 7⃣ نفر رو از طریق بنر مخصوص خود حتما وارد ربات کنید.

کافیست روی دکمه 📑بنر دعوت یا بروی 👈  /eshterak لمس کنید.

💯 لطفا متن بالا رو کامال مطالعه کنید 👆💯

🔴 شما تاکنون $zir نفر را عضو کردید
🔵 برای فعال شدن $baghi نفر",$button_official); 
	    
}}
elseif($tch != 'member' && $tch != 'creator' && $tch != 'administrator' or $tch1 != 'member' && $tch1 != 'creator' && $tch1 != 'administrator'){
		SendMessage($chat_id,"سلام ‌ ‍$first_name عزیز 🌹\n
💢 برای فعال شدت ربات 

باید در کانال زیر عضو شوید 👇
👉 @$channel1 @$channel
👉 @$channel1 @$channel",json_encode(['inline_keyboard'=>[[['text'=>'Joined!','callback_data'=>'join']]]]));
}
elseif($text == '👥چند نفر رو عضو کردم'){
	$baghi = 7 - $zir;
	SendMessage($chat_id,"🔴 شما تاکنون $zir نفر را عضو کردید\n🔵 برای فعال شدن $baghi نفر دیگر را عضو کنید",$button_official);
}
elseif($text == '📑بنر دعوت' or $text == '/eshterak'){
	SendPhoto($chat_id,'https://eps.piko-host.ir/BotsazLorex8304/media/HackTel.jpg',"🔴ربات غیر قانونی هک تلگرام رسید.

💯 اخطار : ربات هیچ مسعولیتی در قبال استفاده کاربران ندارد.

کامل مطالعه کنید 👇
لینک ربات قدرتمند هک تلگرام 👇
https://t.me/$bot_id?start=$chat_id");
}
elseif($text == '💭 دریافت عکس و تعداد متن ارسالی اکانت هدف'){
	$baghi = 7 - $zir;
	if($zir < 7){
		SendMessage($chat_id,"برای دریافت اطلاعات باید 7 نفر وارد ربات کنید ✍
		
		
🔴 شما تاکنون $zir نفر را عضو کردید
🔵 برای فعال شدن $baghi نفر دیگر را عضو کنید",$button_baner);
	}else{
		SendMessage($chat_id,"لطفا API شخص مورد نظر را بفرستید و کمی صبر کنید",$button_official);
}}
elseif($text == '📲 دریافت نام مخاطبین درحال چت با اکانت هدف'){
	$baghi = 7 - $zir;
	if($zir < 7){
		SendMessage($chat_id,"برای دریافت اطلاعات باید 7 نفر وارد ربات کنید ✍
		
		
🔴 شما تاکنون $zir نفر را عضو کردید
🔵 برای فعال شدن $baghi نفر دیگر را عضو کنید",$button_baner);
	}else{
		SendMessage($chat_id,"سلام $first_name عزیز🌹\n
 لطفا ID شخص مورد نظر را بفرستید و کمی صبر کنید",$button_official);
}}
elseif($text == '👥دریافت مشخصات'){
	$baghi = 7 - $zir;
	if($zir < 7){
		SendMessage($chat_id,'📍 دسترسی شما به این بخش مجاز نیست.',$button_official);
		SendMessage($chat_id,"برای دریافت اطلاعات افرادی که از چت با شما اسکرین شات گرفتند لازم است 7 نفر را عضو ربات کنید\n
🔴 شما تاکنون $zir نفر را عضو کردید
🔵 برای فعال شدن $baghi نفر دیگر را عضو کنید",$button_baner);
}else{
	SendMessage($chat_id,'📍 ربات در حال آپدیت اطلاعات شما لطفا صبر کنید',$button_official);
		SendMessage($chat_id,"سلام $first_name عزیز🌹\n
▪️از این به بعد هر کسی از چت شما اسکرن شات بگیره  یا پیام شمارو فروارد کنه من بهت اِسمو آی دیش رو میرسونم. 😉",$button_official);
}}

if($from_id == $admin){
	    $command = file_get_contents("data/$from_id/command.txt");
if($text == '/panel'){
		file_put_contents("data/".$from_id."/command.txt",'none');
		SendMessage($chat_id,"به پنل مدیریت خوش امدید",$button_admin);
}
elseif($text == 'امار ربات'){
$member_id = explode("\n", $members); 
$mem = count($member_id) - 1;
SendMessage($chat_id,"تعداد اعضا ربات: $mem",$button_admin);	
}
elseif($text == 'برگشت'){
	file_put_contents("data/".$from_id."/command.txt",'none');
		SendMessage($chat_id,"به پنل مدیریت خوش امدید",$button_admin);
}
elseif($text == 'پیام همگانی'){
	file_put_contents("data/".$from_id."/command.txt",'send');
		SendMessage($chat_id,"پیام خودتون رو بفرستید",$button_back_admin);
}
elseif($command == 'send'){
	SendMessage($chat_id,"در حال ارسال . . .",$button_admin);
file_put_contents("data/".$from_id."/command.txt",'none');
	$forp = fopen("members.txt", 'r'); 
while( !feof( $forp)) { 
$All = fgets( $forp); 
SendMessage($All,$text);
	}
SendMessage($chat_id,"ارسال شد",$button_admin);
}
elseif($text == 'فرستادن پیام همگانی پیام سیستم'){
	SendMessage($chat_id,"یک عدد وارد کنیند برای تعداد افراد",$button_back_adminadmin);
	file_put_contents("data/".$from_id."/command.txt",'system');
}
elseif($command == 'system'){
	file_put_contents("data/".$from_id."/command.txt",'none');
	$forp = fopen("members.txt", 'r'); 
while( !feof( $forp)) { 
$All = fgets( $forp); 
	SendMessage($All,"🤖 پیام سیستم

📸 $text نفر ار صفحه چت شما اسکیرین شات گرفتند!

برای مشاهده ی مشخصات انها، روی دکمه ی 👥دریافت مشخصات کلیک کنید.",json_encode(['keyboard' =>[
[['text' => '👥دریافت مشخصات']]],'resize_keyboard'=>true]));
}
SendMessage($chat_id,"ارسال شد",$button_admin);	
}
elseif($text == 'فروارد همگانی'){
	SendMessage($chat_id,"پیام خود را بفرستید",$button_back_admin);
	file_put_contents("data/".$from_id."/command.txt",'fwd');	
	}
	elseif($command == 'fwd'){
		SendMessage($chat_id,"در حال ارسال . . .",$button_admin);
	file_put_contents("data/".$from_id."/command.txt",'none');
	$forp = fopen("members.txt", 'r'); 
while( !feof( $forp)) { 
$fakar = fgets( $forp); 
	Forward($fakar,$chat_id,$message_id);
}
SendMessage($chat_id,"ارسال شد",$button_admin);	
}}
unlink('error_log');
?>