<?php
ob_start();
error_reporting(0);
//===functions=========//
$telegram_ip_ranges = [
['lower' => '149.154.160.0', 'upper' => '149.154.175.255'], 
['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],    
];
$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
$ok=false;
foreach ($telegram_ip_ranges as $telegram_ip_range) if (!$ok) {
$lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
$upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
if($ip_dec >= $lower_dec and $ip_dec <= $upper_dec) $ok=true;
}
if(!$ok) die("fuck :)");
define('API_KEY','[*[TOKEN]*]');
function bot($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
 $res = curl_exec($ch);
 if(curl_error($ch)){
var_dump(curl_error($ch));
}else{
return json_decode($res);
}
}
function SendMessage($chat_id, $text){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>$text,
'parse_mode'=>'html'
]);
}
function SendDocument($chatid,$document,$keyboard,$caption){
bot('SendDocument',[
'chat_id'=>$chat_id,
'document'=>$document,
'caption'=>$caption,
'reply_markup'=>$keyboard
]);
}
function EditMessageText($chat_id,$message_id,$text,$parse_mode,$disable_web_page_preview,$keyboard){
bot('editMessagetext',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>$text,
'parse_mode'=>$parse_mode,
'disable_web_page_preview'=>$disable_web_page_preview,
'reply_markup'=>$keyboard
]);
}
function SendPhoto($chat_id, $photo, $caption = null){
bot('SendPhoto',[
'chat_id'=>$chat_id,
'photo'=>$photo,
'caption'=>$caption
]);
}
function AnswerCallbackQuery($callback_query_id,$text,$show_alert){
bot('answerCallbackQuery',[
'callback_query_id'=>$callback_query_id,
'text'=>$text,
'show_alert'=>$show_alert,
]);
}
function sendaction($chat_id, $action){
bot('sendchataction', [
'chat_id' => $chat_id,
'action' => $action
]);
}
//------------------------
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$from_id = $message->from->id;
mkdir("data/$from_id");
$message_id = $update->message->message_id;
$text = $update->message->text;
$query = $update->callback_query;
$data = $query->data;
$messageid = $query->message->message_id;
$chatid = $query->message->chat->id;
$fromid = $query->message->from->id;
$callback_query_id = $query->id;
$gif_id = $update->message->document->file_id;
$photo = $update->message->photo;
$photo_id = $update->message->photo->file_id;
$admin = "[*[ADMIN]*]";//ایدی عددی ادمین//
$channel= "[*[CHANEL]*]";//ایدی کانال بدون@//
$inch = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@$channel&user_id=".$from_id);
$tch = $forchaneel->result->status;
$memlist = explode("\n", $members);
$step = file_get_contents("data/$from_id/step.txt");
$Members = file_get_contents("data/Member.txt");
$member = file_get_contents("data/$from_id/member.txt");
$ads = file_get_contents("data/ads.txt");
$botid = bot('GetMe',[]) -> result -> username;
$first_bot = bot('GetMe',[]) -> result -> first_name;
$id_bot = bot('GetMe',[]) -> result -> id;
//===============//
if(strpos($inch , '"status":"left"') == true ){ 
bot('sendMessage',[ 
'message_id' => $message_id,
'chat_id'=>$chat_id, 
'text'=>"با سلام و عرض خسته نباشید خدمت شما کاربر عزیز 🌹

به دلیل رایگان بودن ربات باید عضو چنل ( کانال ) ما شویـــــــــــــــــــــــــد🎗

🧩  @$channel
🧩  @$channel

سپس به ربات برگشته و دستور ( /start ) رو ارسال کنید🏆",
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[['text'=>"🔱کانال |  channel🔱",'url'=>"https://telegram.me/$channel"]] 
] 
]) 
]);
}
elseif($text == "/start"){
$user = file_get_contents('data/users.txt');
$members = explode("\n", $user);
if(!in_array($from_id, $members)){
$add_user = file_get_contents('data/users.txt');
$add_user .= $from_id . "\n";
file_put_contents("data/$chat_id/membrs.txt", "0");
file_put_contents('data/users.txt', $add_user);
}
file_put_contents("data/$from_id/step.txt","no");
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"با سلام به ربات دریافت تم تلگرام خوش آمدید 🔆

با این ربات میتونید بهترین و متفاوت ترین تم هایه تلگرام رو دریافت کنید 🎩

👑کانال ما :
@$channel",
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تم پسرونه 💁🏻‍♂', 'callback_data'=>"pesr"],['text'=>'تم  دخترونه 💁🏻‍♀','callback_data'=>"dokht"]],
[['text'=>'تم روشن 🧞‍♂','callback_data'=>"rosh"],['text'=>'تم تاریک 🧞','callback_data'=>"tarik"]],
[['text'=>'تم فانتزی 👨🏻‍🎤','callback_data'=>"fantzi"],['text'=>'تم هنری 👩🏻‍🎨','callback_data'=>"honar"]],
[['text'=>'عکس پشت زمینه 🌇','callback_data'=>"aks"],['text'=>'تم ویندوز 👨‍💻','callback_data'=>"desk"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($text == "/panel" or $text=="1" or $text=="برگشت 🏠"){
if($from_id == $admin){
bot('sendmessage', [
'chat_id' =>$chat_id,
'text' =>"مدیر عزیز به پنل مدیریت خوش آمدید 🌹",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"آمار 👑"],['text'=>"پیام همگانی 🚦"]],
[['text'=>"افزودن تم پسرونه 👨🏻‍🎤"],['text'=>"افزودن تم دخترونه 🧑🏼‍🎤"]],
[['text'=>"افزودن تم روشن 🧞‍♀"],['text'=>"افزودن تم تاریک🧞"]],
[['text'=>"افزودن تم فانتزی 🧚🏻‍♀"],['text'=>"افزودن تم هنری 👩🏻‍🎨"]],
[['text'=>"افزودن Wallpaper🥝"],['text'=>"افزودن تم desktop 🖥"]],
[['text'=>"/start"],['text'=>"تنظیم تبلیغ تم ها🧶"]],
],
'resize_keyboard'=>true
])
]);
}else{
SendMessage($chat_id,"شما مدیر نیستی!!","HTML");
}
}
elseif($text == "آمار 👑" && $chat_id == $admin){
$user = file_get_contents("data/users.txt");
$member_id = explode("\n",$user);
$member_count = count($member_id) -1;
sendmessage($chat_id , "
  $member_count
" , "html");
}
elseif($text == "پیام همگانی 🚦" && $chat_id == $admin){
file_put_contents("data/$from_id/step.txt","pmh");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🌿 پیام خود را ارسال کنید !",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"برگشت 🏠"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($step == "pmh" && $text !="برگشت 🏠" ){
file_put_contents("data/$from_id/step.txt","no");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"پیام شما فرستاده شد 💫",
]);
$all_member = fopen( "data/users.txt", "r");
while( !feof( $all_member)){
$user = fgets( $all_member);
SendMessage($user,$text,"html");
}
}
elseif($text == "تنظیم تبلیغ تم ها🧶" && $chat_id == $admin){
file_put_contents("data/$from_id/step.txt","ads");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"متن خود را وارد کنید.",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"برگشت 🏠"]],
]
])
]);
}
elseif($step == "ads" && $text !="برگشت 🏠"){
file_put_contents("data/ads.txt",$text);
file_put_contents("data/$from_id/step.txt","no");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"متن تبلیغات تنظیم شد ✅",
]);
}
elseif($data == "back"){
file_put_contents("data/$from_id/step.txt","no");
bot('sendmessage',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'text'=>"با سلام به ربات دریافت تم تلگرام خوش آمدید 🔆

با این ربات میتونید بهترین و متفاوت ترین تم هایه تلگرام رو دریافت کنید 🎩

👑کانال ما :
@$channel",
'parse_mode'=>"html",  
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تم پسرونه 💁🏻‍♂', 'callback_data'=>"pesr"],['text'=>'تم  دخترونه 💁🏻‍♀','callback_data'=>"dokht"]],
[['text'=>'تم روشن 🧞‍♂','callback_data'=>"rosh"],['text'=>'تم تاریک 🧞','callback_data'=>"tarik"]],
[['text'=>'تم فانتزی 👨🏻‍🎤','callback_data'=>"fantzi"],['text'=>'تم هنری 👩🏻‍🎨','callback_data'=>"honar"]],
[['text'=>'عکس پشت زمینه 🌇','callback_data'=>"aks"],['text'=>'تم ویندوز 👨‍💻','callback_data'=>"desk"]],
],
'resize_keyboard'=>true,
])
]);
}
//==================//
elseif($text == "افزودن Wallpaper🥝" && $chat_id == $admin){
file_put_contents("data/$from_id/step.txt","no");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"♻️ تنظیمات تم desktop ♻️",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
 [['text'=>"Add wallpaper"]],
 [['text'=>"dellete all wallpaper"],['text'=>"dellete wallpaper"]],
 [['text'=>"برگشت 🏠"]]
 ],
"resize_keyboard"=>true,
])
]);
}
elseif($text == "افزودن تم desktop 🖥" && $chat_id == $admin){
file_put_contents("data/$from_id/step.txt","no");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"♻️ تنظیمات تم desktop ♻️",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
 [['text'=>"Add Desktop"]],
 [['text'=>"dellete all desktop"],['text'=>"dellete desktop"]],
 [['text'=>"برگشت 🏠"]]
 ],
"resize_keyboard"=>true,
])
]);
}
elseif($text == "افزودن تم پسرونه 👨🏻‍🎤" && $chat_id == $admin){
file_put_contents("data/$from_id/step.txt","no");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"♻️ تنظیمات تم پسرونه ♻️",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
 [['text'=>"افزودن  🔧"]],
 [['text'=>"حذف همه 🚫"],['text'=>"حذف تم ❎"]],
 [['text'=>"برگشت 🏠"]]
 ],
"resize_keyboard"=>true,
])
]);
}
elseif($text == "افزودن تم دخترونه 🧑🏼‍🎤" && $chat_id == $admin){
 file_put_contents("data/$from_id/step.txt","no");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"♻️ تنظیمات تم دخترونه ♻️",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
 [['text'=>"Add girl"]],
 [['text'=>"dellete all girl"],['text'=>"dellete girl"]],
 [['text'=>"برگشت 🏠"]]
 ],
"resize_keyboard"=>true,
])
]);
}
elseif($text == "افزودن تم تاریک🧞" && $chat_id == $admin){
 file_put_contents("data/$from_id/step.txt","no");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"♻️ تنظیمات تم تاریک ♻️",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
 [['text'=>"Add Dark"]],
 [['text'=>"dellete all dark"],['text'=>"dellete dark"]],
 [['text'=>"برگشت 🏠"]]
 ],
"resize_keyboard"=>true,
])
]);
}
elseif($text == "افزودن تم روشن 🧞‍♀" && $chat_id == $admin){
 file_put_contents("data/$from_id/step.txt","no");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"♻️ تنظیمات تم روشن ♻️",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
 [['text'=>"Add light"]],
 [['text'=>"dellete all light"],['text'=>"dellete light"]],
 [['text'=>"برگشت 🏠"]]
 ],
"resize_keyboard"=>true,
])
]);
}
elseif($text == "افزودن تم فانتزی 🧚🏻‍♀" && $chat_id == $admin){
 file_put_contents("data/$from_id/step.txt","no");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"♻️ تنظیمات تم فانتزی ♻️",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
 [['text'=>"Add Fantzi"]],
 [['text'=>"dellete all Fantzi"],['text'=>"dellete Fantzi"]],
 [['text'=>"برگشت 🏠"]]
 ],
"resize_keyboard"=>true,
])
]);
}
elseif($text == "افزودن تم هنری 👩🏻‍🎨" && $chat_id == $admin){
 file_put_contents("data/$from_id/step.txt","no");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"♻️ تنظیمات تم هنری ♻️",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
 [['text'=>"Add art"]],
 [['text'=>"dellete all Art"],['text'=>"dellete art"]],
 [['text'=>"برگشت 🏠"]]
 ],
"resize_keyboard"=>true,
])
]);
}
//=================//
elseif($text == "افزودن  🔧" && $chat_id == $admin){
file_put_contents("data/$from_id/step.txt","adtmps");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"فایل های تم را فروارد کنید یا بفرستید 🌿",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
 [['text'=>"برگشت 🏠"]]
 ],
"resize_keyboard"=>true,
])
]);
} 
elseif($step == "adtmps" && $text !="برگشت 🏠" ){
if(isset($gif_id)){
$mps = file_get_contents('data/tmps.txt');
$mpss = explode(",",$mps);
if(!in_array($gif_id,$mpss)){
$add_mps = file_get_contents('data/tmps.txt');
$add_mps .= $gif_id.",";
file_put_contents('data/tmps.txt',$add_mps);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ثبت شد ✅",
'reply_to_message_id'=>$message_id,
'parse_mode'=>"MarkDown",
]);
}
} 
elseif($text == "Add Desktop" && $chat_id == $admin){
file_put_contents("data/$from_id/step.txt","adtmdesk");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"فایل های تم را فروارد کنید یا بفرستید 🌿",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
 [['text'=>"برگشت 🏠"]]
 ],
"resize_keyboard"=>true,
])
]);
} 
elseif($step == "adtmdesk" && $text !="برگشت 🏠" ){
if(isset($gif_id)){
$mps = file_get_contents('data/tmdesk.txt');
$mpss = explode(",",$mps);
if(!in_array($gif_id,$mpss)){
$add_mps = file_get_contents('data/tmdesk.txt');
$add_mps .= $gif_id.",";
file_put_contents('data/tmdesk.txt',$add_mps);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ثبت شد ✅",
'reply_to_message_id'=>$message_id,
'parse_mode'=>"MarkDown",
]);
}
} 
elseif($text == "Add girl" && $chat_id == $admin){
file_put_contents("data/$from_id/step.txt","adtmgr");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"فایل های تم را فروارد کنید یا بفرستید 🌿",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
 [['text'=>"برگشت 🏠"]]
 ],
"resize_keyboard"=>true,
])
]);
} 
elseif($step == "adtmgr" && $text !="برگشت 🏠" ){
if(isset($gif_id)){
$mps = file_get_contents('data/tmgr.txt');
$mpss = explode(",",$mps);
if(!in_array($gif_id,$mpss)){
$add_mps = file_get_contents('data/tmgr.txt');
$add_mps .= $gif_id.",";
file_put_contents('data/tmgr.txt',$add_mps);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ثبت شد ✅",
'reply_to_message_id'=>$message_id,
'parse_mode'=>"MarkDown",
]);
}
} 
elseif($text == "Add Dark" && $chat_id == $admin){
file_put_contents("data/$from_id/step.txt","adtmdark");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"فایل های تم را فروارد کنید یا بفرستید 🌿",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
 [['text'=>"برگشت 🏠"]]
 ],
"resize_keyboard"=>true,
])
]);
} 
elseif($step == "adtmdark" && $text !="برگشت 🏠" ){
if(isset($gif_id)){
$mps = file_get_contents('data/tmdark.txt');
$mpss = explode(",",$mps);
if(!in_array($gif_id,$mpss)){
$add_mps = file_get_contents('data/tmdark.txt');
$add_mps .= $gif_id.",";
file_put_contents('data/tmdark.txt',$add_mps);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ثبت شد ✅",
'reply_to_message_id'=>$message_id,
'parse_mode'=>"MarkDown",
]);
}
} 
elseif($text == "Add light" && $chat_id == $admin){
file_put_contents("data/$from_id/step.txt","adtmlight");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"فایل های تم را فروارد کنید یا بفرستید 🌿",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
 [['text'=>"برگشت 🏠"]]
 ],
"resize_keyboard"=>true,
])
]);
} 
elseif($step == "adtmlight" && $text !="برگشت 🏠" ){
if(isset($gif_id)){
$mps = file_get_contents('data/tmlight.txt');
$mpss = explode(",",$mps);
if(!in_array($gif_id,$mpss)){
$add_mps = file_get_contents('data/tmlight.txt');
$add_mps .= $gif_id.",";
file_put_contents('data/tmlight.txt',$add_mps);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ثبت شد ✅",
'reply_to_message_id'=>$message_id,
'parse_mode'=>"MarkDown",
]);
}
} 
elseif($text == "Add Fantzi" && $chat_id == $admin){
file_put_contents("data/$from_id/step.txt","adtmfan");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"فایل های تم را فروارد کنید یا بفرستید 🌿",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
 [['text'=>"برگشت 🏠"]]
 ],
"resize_keyboard"=>true,
])
]);
} 
elseif($step == "adtmfan" && $text !="برگشت 🏠" ){
if(isset($gif_id)){
$mps = file_get_contents('data/tmfan.txt');
$mpss = explode(",",$mps);
if(!in_array($gif_id,$mpss)){
$add_mps = file_get_contents('data/tmfan.txt');
$add_mps .= $gif_id.",";
file_put_contents('data/tmfan.txt',$add_mps);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ثبت شد ✅",
'reply_to_message_id'=>$message_id,
'parse_mode'=>"MarkDown",
]);
}
} 
elseif($text == "Add art" && $chat_id == $admin){
file_put_contents("data/$from_id/step.txt","adtmart");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"فایل های تم را فروارد کنید یا بفرستید 🌿",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
 [['text'=>"برگشت 🏠"]]
 ],
"resize_keyboard"=>true,
])
]);
} 
elseif($step == "adtmart" && $text !="برگشت 🏠" ){
if(isset($gif_id)){
$mps = file_get_contents('data/tmart.txt');
$mpss = explode(",",$mps);
if(!in_array($gif_id,$mpss)){
$add_mps = file_get_contents('data/tmart.txt');
$add_mps .= $gif_id.",";
file_put_contents('data/tmart.txt',$add_mps);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ثبت شد ✅",
'reply_to_message_id'=>$message_id,
'parse_mode'=>"MarkDown",
]);
}
} 
elseif($text == "Add wallpaper" && $chat_id == $admin){
file_put_contents("data/$from_id/step.txt","adaks");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"فایل های عکس را بفرستید یا فورارد کنید",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
 [['text'=>"برگشت 🏠"]]
 ],
"resize_keyboard"=>true,
])
]);
} 
elseif($step == "adaks" && $text !="برگشت 🏠" ){
if(is_array($photo)){
$count = count($photo) - 1;
$photo_id = $photo[$count]->file_id;
$pics = file_get_contents('data/aks.txt');
$picss = explode(",",$pics);
if(!in_array($photo_id,$picss)){
$add_pic = file_get_contents('data/aks.txt');
$add_pic .= $photo_id.",";
file_put_contents('data/aks.txt',$add_pic);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ثبت شد ✅",
'reply_to_message_id'=>$message_id,
'parse_mode'=>"MarkDown",
]);
}
} 
//=========
elseif($data == "aks" ){
bot('editMessagetext',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'text'=>"
به بخش عکس زمینه خوش آمدید 👻
",
'parse_mode'=>"html",  
]);
$mp = file_get_contents('data/aks.txt');
$mpp = explode(",",$mp);
$count = count($mpp) -1;
$rand = rand (1,$count)-1;
$m_id = $mpp[$rand];
bot('sendphoto',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'photo'=>$m_id,
'caption'=>"$ads",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'بعدی 🍣','callback_data'=>"nextaks"]],
[['text'=>'برگشت 🏠','callback_data'=>"back"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($data == "nextaks" ){
$mp = file_get_contents('data/aks.txt');
$mpp = explode(",",$mp);
$count = count($mpp) -1;
$rand = rand (1,$count)-1;
$m_id = $mpp[$rand];
bot('sendphoto',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'photo'=>$m_id,
'caption'=>"$ads",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'بعدی 🍣','callback_data'=>"nextaks"]],
[['text'=>'برگشت 🏠','callback_data'=>"back"]],
],
'resize_keyboard'=>true,
])
]);
}
//=====//
elseif($data == "pesr" ){
bot('editMessagetext',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'text'=>"
به بخش تم پسرونه خوش آمدید 👻
",
'parse_mode'=>"html",  
]);
$mp = file_get_contents('data/tmps.txt');
$mpp = explode(",",$mp);
$count = count($mpp) -1;
$rand = rand (1,$count)-1;
$m_id = $mpp[$rand];
bot('SendDocument',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'document'=>$m_id,
'caption'=>"$ads",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'بعدی 🍣','callback_data'=>"nextpsr"]],
[['text'=>'برگشت 🏠','callback_data'=>"back"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($data == "nextpsr" ){
$mp = file_get_contents('data/tmps.txt');
$mpp = explode(",",$mp);
$count = count($mpp) -1;
$rand = rand (1,$count)-1;
$m_id = $mpp[$rand];
bot('SendDocument',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'document'=>$m_id,
'caption'=>"$ads",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'بعدی 🍣','callback_data'=>"nextpsr"]],
[['text'=>'برگشت 🏠','callback_data'=>"back"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($data == "dokht" ){
bot('editMessagetext',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'text'=>"
به بخش تم دخترونه خوش آمدید 👻
",
'parse_mode'=>"html",  
]);
$mp = file_get_contents('data/tmgr.txt');
$mpp = explode(",",$mp);
$count = count($mpp) -1;
$rand = rand (1,$count)-1;
$m_id = $mpp[$rand];
bot('SendDocument',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'document'=>$m_id,
'caption'=>"$ads",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'بعدی 🍣','callback_data'=>"nextgr"]],
[['text'=>'برگشت 🏠','callback_data'=>"back"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($data == "nextgr" ){
$mp = file_get_contents('data/tmgr.txt');
$mpp = explode(",",$mp);
$count = count($mpp) -1;
$rand = rand (1,$count)-1;
$m_id = $mpp[$rand];
bot('SendDocument',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'document'=>$m_id,
'caption'=>"$ads",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'بعدی 🍣','callback_data'=>"nextgr"]],
[['text'=>'برگشت 🏠','callback_data'=>"back"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($data == "rosh" ){
bot('editMessagetext',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'text'=>"
به بخش تم روشن خوش آمدید 👻
",
'parse_mode'=>"html",  
]);
$mp = file_get_contents('data/tmlight.txt');
$mpp = explode(",",$mp);
$count = count($mpp) -1;
$rand = rand (1,$count)-1;
$m_id = $mpp[$rand];
bot('SendDocument',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'document'=>$m_id,
'caption'=>"$ads",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'بعدی 🍣','callback_data'=>"nextlight"]],
[['text'=>'برگشت 🏠','callback_data'=>"back"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($data == "nextlight" ){
$mp = file_get_contents('data/tmlight.txt');
$mpp = explode(",",$mp);
$count = count($mpp) -1;
$rand = rand (1,$count)-1;
$m_id = $mpp[$rand];
bot('SendDocument',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'document'=>$m_id,
'caption'=>"$ads",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'بعدی 🍣','callback_data'=>"nextlight"]],
[['text'=>'برگشت 🏠','callback_data'=>"back"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($data == "tarik" ){
bot('editMessagetext',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'text'=>"
به بخش تم تاریک خوش آمدید 👻
",
'parse_mode'=>"html",  
]);
$mp = file_get_contents('data/tmdark.txt');
$mpp = explode(",",$mp);
$count = count($mpp) -1;
$rand = rand (1,$count)-1;
$m_id = $mpp[$rand];
bot('SendDocument',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'document'=>$m_id,
'caption'=>"$ads",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'بعدی 🍣','callback_data'=>"nextdark"]],
[['text'=>'برگشت 🏠','callback_data'=>"back"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($data == "nextdark" ){
$mp = file_get_contents('data/tmdark.txt');
$mpp = explode(",",$mp);
$count = count($mpp) -1;
$rand = rand (1,$count)-1;
$m_id = $mpp[$rand];
bot('SendDocument',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'document'=>$m_id,
'caption'=>"$ads",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'بعدی 🍣','callback_data'=>"nextdark"]],
[['text'=>'برگشت 🏠','callback_data'=>"back"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($data == "fantzi" ){
bot('editMessagetext',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'text'=>"
به بخش تم فانتزی خوش آمدید 👻
",
'parse_mode'=>"html",  
]);
$mp = file_get_contents('data/tmfan.txt');
$mpp = explode(",",$mp);
$count = count($mpp) -1;
$rand = rand (1,$count)-1;
$m_id = $mpp[$rand];
bot('SendDocument',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'document'=>$m_id,
'caption'=>"$ads",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'بعدی 🍣','callback_data'=>"nextfan"]],
[['text'=>'برگشت 🏠','callback_data'=>"back"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($data == "nextfan" ){
$mp = file_get_contents('data/tmfan.txt');
$mpp = explode(",",$mp);
$count = count($mpp) -1;
$rand = rand (1,$count)-1;
$m_id = $mpp[$rand];
bot('SendDocument',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'document'=>$m_id,
'caption'=>"$ads",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'بعدی 🍣','callback_data'=>"nextfan"]],
[['text'=>'برگشت 🏠','callback_data'=>"back"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($data == "honar" ){
bot('editMessagetext',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'text'=>"
به بخش تم هنری خوش آمدید 👻
",
'parse_mode'=>"html",  
]);
$mp = file_get_contents('data/tmart.txt');
$mpp = explode(",",$mp);
$count = count($mpp) -1;
$rand = rand (1,$count)-1;
$m_id = $mpp[$rand];
bot('SendDocument',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'document'=>$m_id,
'caption'=>"$ads",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'بعدی 🍣','callback_data'=>"nextart"]],
[['text'=>'برگشت 🏠','callback_data'=>"back"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($data == "nextart" ){
$mp = file_get_contents('data/tmart.txt');
$mpp = explode(",",$mp);
$count = count($mpp) -1;
$rand = rand (1,$count)-1;
$m_id = $mpp[$rand];
bot('SendDocument',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'document'=>$m_id,
'caption'=>"$ads",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'بعدی 🍣','callback_data'=>"nextart"]],
[['text'=>'برگشت 🏠','callback_data'=>"back"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($data == "desk" ){
bot('editMessagetext',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'text'=>"
به بخش تم دسکتاپ خوش آمدید 👻
",
'parse_mode'=>"html",  
]);
$mp = file_get_contents('data/tmdesk.txt');
$mpp = explode(",",$mp);
$count = count($mpp) -1;
$rand = rand (1,$count)-1;
$m_id = $mpp[$rand];
bot('SendDocument',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'document'=>$m_id,
'caption'=>"$ads",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'بعدی 🍣','callback_data'=>"nextdesk"]],
[['text'=>'برگشت 🏠','callback_data'=>"back"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($data == "nextdesk" ){
$mp = file_get_contents('data/tmdesk.txt');
$mpp = explode(",",$mp);
$count = count($mpp) -1;
$rand = rand (1,$count)-1;
$m_id = $mpp[$rand];
bot('SendDocument',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'document'=>$m_id,
'caption'=>"$ads",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'بعدی 🍣','callback_data'=>"nextdesk"]],
[['text'=>'برگشت 🏠','callback_data'=>"back"]],
],
'resize_keyboard'=>true,
])
]);
}
//====
elseif($text == "حذف همه 🚫" && $chat_id == $admin){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "⭕️آیا مطمئن هستید که میخواهید همه تم ها را حذف کنید ⁉️",
'parse_mode' => "MarkDown",
'reply_markup' => json_encode([
'inline_keyboard' =>[
[['text' => "بله ✅", 'callback_data' => "Yestmps"],['text' => "برگشت 🏠", 'callback_data' => "back"]],
]
])
]);
} 
elseif($data == "Yestmps"){
file_put_contents('data/tmps.txt','');
bot('editMessagetext',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'text'=>"تمامی تم ها حذف شدند ❕",
'parse_mode'=>"MarkDown",
]);
}
elseif($text == "حذف تم ❎" && $chat_id == $admin){
file_put_contents("data/$from_id/step.txt","deltmps");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
⭕️ تم یا تم هایی که میخواهید حذف کنید را فوروارد کنید یا بفرستید !!
⚠️ در آخر (برگشت 🏠) بزنید.
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"برگشت 🏠"]]
],
'resize_keyboard'=>true,
])
]);
} 
elseif($step == "deltmps" && $text !="برگشت 🏠" ){
if(isset($gif_id)){
$mps = file_get_contents('data/tmps.txt');
$mpss = explode(",",$mps);
if(in_array($gif_id,$mpss)){
$del_mps = file_get_contents('data/tmps.txt');
$del_mpss = str_replace ($gif_id.',','',$del_mps);
file_put_contents('data/tmps.txt',$del_mpss);}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"حذف شد ✅",
'reply_to_message_id'=>$message_id,
'parse_mode'=>"MarkDown",
]);
}
}
//==========//
elseif($text == "dellete all girl" && $chat_id == $admin){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "⭕️آیا مطمئن هستید که میخواهید همه تم ها را حذف کنید ⁉️",
'parse_mode' => "MarkDown",
'reply_markup' => json_encode([
'inline_keyboard' =>[
[['text' => "بله ✅", 'callback_data' => "Yestmgr"],['text' => "برگشت 🏠", 'callback_data' => "back"]],
]
])
]);
} 
elseif($data == "Yestmgr"){
file_put_contents('data/tmgr.txt','');
bot('editMessagetext',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'text'=>"تمامی تم ها حذف شدند ❕",
'parse_mode'=>"MarkDown",
]);
}
elseif($text == "dellete girl" && $chat_id == $admin){
file_put_contents("data/$from_id/step.txt","deltmgr");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
⭕️ تم یا تم هایی که میخواهید حذف کنید را فوروارد کنید یا بفرستید !!
⚠️ در آخر (برگشت 🏠) بزنید.
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"برگشت 🏠"]]
],
'resize_keyboard'=>true,
])
]);
} 
elseif($step == "deltmgr" && $text !="برگشت 🏠" ){
if(isset($gif_id)){
$mps = file_get_contents('data/tmgr.txt');
$mpss = explode(",",$mps);
if(in_array($gif_id,$mpss)){
$del_mps = file_get_contents('data/tmgr.txt');
$del_mpss = str_replace ($gif_id.',','',$del_mps);
file_put_contents('data/tmgr.txt',$del_mpss);}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"حذف شد ✅",
'reply_to_message_id'=>$message_id,
'parse_mode'=>"MarkDown",
]);
}
}
//=============//
elseif($text == "dellete all light" && $chat_id == $admin){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "⭕️آیا مطمئن هستید که میخواهید همه تم ها را حذف کنید ⁉️",
'parse_mode' => "MarkDown",
'reply_markup' => json_encode([
'inline_keyboard' =>[
[['text' => "بله ✅", 'callback_data' => "Yestmlight"],['text' => "برگشت 🏠", 'callback_data' => "back"]],
]
])
]);
} 
elseif($data == "Yestmlight"){
file_put_contents('data/tmlight.txt','');
bot('editMessagetext',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'text'=>"تمامی تم ها حذف شدند ❕",
'parse_mode'=>"MarkDown",
]);
}
elseif($text == "dellete light" && $chat_id == $admin){
file_put_contents("data/$from_id/step.txt","deltmlight");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
⭕️ تم یا تم هایی که میخواهید حذف کنید را فوروارد کنید یا بفرستید !!
⚠️ در آخر (برگشت 🏠) بزنید.
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"برگشت 🏠"]]
],
'resize_keyboard'=>true,
])
]);
} 
elseif($step == "deltmlight" && $text !="برگشت 🏠" ){
if(isset($gif_id)){
$mps = file_get_contents('data/tmlight.txt');
$mpss = explode(",",$mps);
if(in_array($gif_id,$mpss)){
$del_mps = file_get_contents('data/tmlight.txt');
$del_mpss = str_replace ($gif_id.',','',$del_mps);
file_put_contents('data/tmlight.txt',$del_mpss);}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"حذف شد ✅",
'reply_to_message_id'=>$message_id,
'parse_mode'=>"MarkDown",
]);
}
}
//================//
elseif($text == "dellete all dark" && $chat_id == $admin){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "⭕️آیا مطمئن هستید که میخواهید همه تم ها را حذف کنید ⁉️",
'parse_mode' => "MarkDown",
'reply_markup' => json_encode([
'inline_keyboard' =>[
[['text' => "بله ✅", 'callback_data' => "Yestmdark"],['text' => "برگشت 🏠", 'callback_data' => "back"]],
]
])
]);
} 
elseif($data == "Yestmdark"){
file_put_contents('data/tmdark.txt','');
bot('editMessagetext',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'text'=>"تمامی تم ها حذف شدند ❕",
'parse_mode'=>"MarkDown",
]);
}
elseif($text == "dellete dark" && $chat_id == $admin){
file_put_contents("data/$from_id/step.txt","deltmdark");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
⭕️ تم یا تم هایی که میخواهید حذف کنید را فوروارد کنید یا بفرستید !!
⚠️ در آخر (برگشت 🏠) بزنید.
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"برگشت 🏠"]]
],
'resize_keyboard'=>true,
])
]);
} 
elseif($step == "deltmdark" && $text !="برگشت 🏠" ){
if(isset($gif_id)){
$mps = file_get_contents('data/tmdark.txt');
$mpss = explode(",",$mps);
if(in_array($gif_id,$mpss)){
$del_mps = file_get_contents('data/tmdark.txt');
$del_mpss = str_replace ($gif_id.',','',$del_mps);
file_put_contents('data/tmdark.txt',$del_mpss);}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"حذف شد ✅",
'reply_to_message_id'=>$message_id,
'parse_mode'=>"MarkDown",
]);
}
}
//==============//
elseif($text == "dellete all Fantzi" && $chat_id == $admin){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "⭕️آیا مطمئن هستید که میخواهید همه تم ها را حذف کنید ⁉️",
'parse_mode' => "MarkDown",
'reply_markup' => json_encode([
'inline_keyboard' =>[
[['text' => "بله ✅", 'callback_data' => "Yestmfan"],['text' => "برگشت 🏠", 'callback_data' => "back"]],
]
])
]);
} 
elseif($data == "Yestmfan"){
file_put_contents('data/tmfan.txt','');
bot('editMessagetext',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'text'=>"تمامی تم ها حذف شدند ❕",
'parse_mode'=>"MarkDown",
]);
}
elseif($text == "dellete Fantzi" && $chat_id == $admin){
file_put_contents("data/$from_id/step.txt","deltmfan");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
⭕️ تم یا تم هایی که میخواهید حذف کنید را فوروارد کنید یا بفرستید !!
⚠️ در آخر (برگشت 🏠) بزنید.
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"برگشت 🏠"]]
],
'resize_keyboard'=>true,
])
]);
} 
elseif($step == "deltmfan" && $text !="برگشت 🏠" ){
if(isset($gif_id)){
$mps = file_get_contents('data/tmfan.txt');
$mpss = explode(",",$mps);
if(in_array($gif_id,$mpss)){
$del_mps = file_get_contents('data/tmfan.txt');
$del_mpss = str_replace ($gif_id.',','',$del_mps);
file_put_contents('data/tmfan.txt',$del_mpss);}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"حذف شد ✅",
'reply_to_message_id'=>$message_id,
'parse_mode'=>"MarkDown",
]);
}
}
//===============//
elseif($text == "dellete all Art" && $chat_id == $admin){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "⭕️آیا مطمئن هستید که میخواهید همه تم ها را حذف کنید ⁉️",
'parse_mode' => "MarkDown",
'reply_markup' => json_encode([
'inline_keyboard' =>[
[['text' => "بله ✅", 'callback_data' => "Yestmart"],['text' => "برگشت 🏠", 'callback_data' => "back"]],
]
])
]);
} 
elseif($data == "Yestmart"){
file_put_contents('data/tmart.txt','');
bot('editMessagetext',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'text'=>"تمامی تم ها حذف شدند ❕",
'parse_mode'=>"MarkDown",
]);
}
elseif($text == "dellete art" && $chat_id == $admin){
file_put_contents("data/$from_id/step.txt","deltmart");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
⭕️ تم یا تم هایی که میخواهید حذف کنید را فوروارد کنید یا بفرستید !!
⚠️ در آخر (برگشت 🏠) بزنید.
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"برگشت 🏠"]]
],
'resize_keyboard'=>true,
])
]);
} 
elseif($step == "deltmart" && $text !="برگشت 🏠" ){
if(isset($gif_id)){
$mps = file_get_contents('data/tmart.txt');
$mpss = explode(",",$mps);
if(in_array($gif_id,$mpss)){
$del_mps = file_get_contents('data/tmart.txt');
$del_mpss = str_replace ($gif_id.',','',$del_mps);
file_put_contents('data/tmart.txt',$del_mpss);}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"حذف شد ✅",
'reply_to_message_id'=>$message_id,
'parse_mode'=>"MarkDown",
]);
}
}
//===========//
elseif($text == "dellete all desktop" && $chat_id == $admin){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "⭕️آیا مطمئن هستید که میخواهید همه تم ها را حذف کنید ⁉️",
'parse_mode' => "MarkDown",
'reply_markup' => json_encode([
'inline_keyboard' =>[
[['text' => "بله ✅", 'callback_data' => "Yestmdesk"],['text' => "برگشت 🏠", 'callback_data' => "back"]],
]
])
]);
} 
elseif($data == "Yestmdesk"){
file_put_contents('data/tmdesk.txt','');
bot('editMessagetext',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'text'=>"تمامی تم ها حذف شدند ❕",
'parse_mode'=>"MarkDown",
]);
}
elseif($text == "dellete desktop" && $chat_id == $admin){
file_put_contents("data/$from_id/step.txt","deltmdesk");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
⭕️ تم یا تم هایی که میخواهید حذف کنید را فوروارد کنید یا بفرستید !!
⚠️ در آخر (برگشت 🏠) بزنید.
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"برگشت 🏠"]]
],
'resize_keyboard'=>true,
])
]);
} 
elseif($step == "deltmdesk" && $text !="برگشت 🏠" ){
if(isset($gif_id)){
$mps = file_get_contents('data/tmdesk.txt');
$mpss = explode(",",$mps);
if(in_array($gif_id,$mpss)){
$del_mps = file_get_contents('data/tmdesk.txt');
$del_mpss = str_replace ($gif_id.',','',$del_mps);
file_put_contents('data/tmdesk.txt',$del_mpss);}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"حذف شد ✅",
'reply_to_message_id'=>$message_id,
'parse_mode'=>"MarkDown",
]);
}
}
//============//
elseif($text == "dellete all wallpaper" && $chat_id == $admin){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "⭕️آیا مطمئن هستید که میخواهید همه عکس ها را حذف کنید ⁉️",
'parse_mode' => "MarkDown",
'reply_markup' => json_encode([
'inline_keyboard' =>[
[['text' => "بله ✅", 'callback_data' => "Yesaks"],['text' => "برگشت 🏠", 'callback_data' => "back"]],
]
])
]);
} 
elseif($data == "Yesaks"){
file_put_contents('data/aks.txt','');
bot('editMessagetext',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'text'=>"تمامی عکس ها حذف شدند ❕",
'parse_mode'=>"MarkDown",
]);
}
elseif($text == "dellete wallpaper" && $chat_id == $admin){
file_put_contents("data/$from_id/step.txt","delaks");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
⭕️ عکس یا عکس هایی که میخواهید حذف کنید را فوروارد کنید یا بفرستید !!
⚠️ در آخر (برگشت 🏠) بزنید.
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"برگشت 🏠"]]
],
'resize_keyboard'=>true,
])
]);
} 
elseif($step == "delaks" && $text !="برگشت 🏠" ){
if(isset($photo)){
$mps = file_get_contents('data/aks.txt');
$mpss = explode(",",$mps);
if(in_array($photo_id,$mpss)){
$del_mps = file_get_contents('data/aks.txt');
$del_mpss = str_replace ($photo_id.',','',$del_mps);
file_put_contents('data/aks.txt',$del_mpss);}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"حذف شد ✅",
'reply_to_message_id'=>$message_id,
'parse_mode'=>"MarkDown",
]);
}
}
?>