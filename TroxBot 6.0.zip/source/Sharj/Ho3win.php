<?php
ob_start("ob_gzhandler");
error_reporting(0);
//====================
$telegram_ip_ranges = [
['lower' => '149.154.160.0', 'upper' => '149.154.175.255'], 
['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],    
];
$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
$ok=false;
foreach ($telegram_ip_ranges as $telegram_ip_range) if (!$ok) {
$lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
$upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
if($ip_dec >= $lower_dec and $ip_dec <= $upper_dec) $ok=true;
}
if(!$ok) die("Sik :)");
define('API_KEY','[*[TOKEN]*]');
function bot($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
 $res = curl_exec($ch);
 if(curl_error($ch)){
var_dump(curl_error($ch));
}else{
return json_decode($res);
}
}
//=================================================================================================
function SM($chatID)
{
	$tab = json_decode(file_get_contents("../../lib/Jsons/tab.json"),true);
	if($tab['type'] == 'photo')
	{
		Bot('sendphoto',['chat_id'=>$chatID,'photo'=>$tab["msgid"],'caption'=>$tab["text"],'reply_markup'=>$tab['reply_markup']]);
	}
	else if($tab['type'] == 'file')
	{
		Bot('sendDocument',['chat_id'=>$chatID,'document'=>$tab["msgid"],'caption'=>$tab["text"],'reply_markup'=>$tab['reply_markup']]);
	}
	else if($tab['type'] == 'video')
	{
		Bot('SendVideo',['chat_id'=>$chatID,'video'=>$tab["msgid"],'caption'=>$tab["text"],'reply_markup'=>$tab['reply_markup']]);
	}
	else if($tab['type'] == 'music')
	{
		Bot('SendAudio',['chat_id'=>$chatID,'audio'=>$tab["msgid"],'caption'=>$tab["text"],'reply_markup'=>$tab['reply_markup']]);
	}
	else if($tab['type'] == 'sticker')
	{
		Bot('SendSticker',['chat_id'=>$chatID,'sticker'=>$tab["msgid"],'caption'=>$tab["text"],'reply_markup'=>$tab['reply_markup']]);
	}
	else if($tab['type'] == 'voice')
	{
		Bot('SendVoice',['chat_id'=>$chatID,'voice'=>$tab["msgid"],'caption'=>$tab["text"],'reply_markup'=>$tab['reply_markup']]);
	}
	else
	{
		if($tab['reply_markup'] != null)
		{
			Bot('SendMessage',['chat_id'=>$chatID,'text'=>$tab['text'],'reply_markup'=>$tab['reply_markup']]);
		}
		else
		{
			Bot('SendMessage',['chat_id'=>$chatID,'text'=>$tab['text']]);
		}
	}
}
//-----------------------
$botsorce = $update->message->reply_to_message->forward_from->id; 
//============
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$from_id = $message->from->id;
mkdir("data/$from_id");
$message_id = $message->message_id;
$text1 = $message->text;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$forward_chat_username = $update->message->forward_from_chat->username;
$forward_chat_msg_id = $update->message->forward_from_message_id;
$username = $message->from->username;
$contact = $message->contact;
$contactnum = $contact->phone_number;
$admin = [*[ADMIN]*];//ایدی عددی ادمین اول//
$ir5 = file_get_contents("ir5.txt");

$token = "[*[TOKEN]*]";//توکن رباتتون بزارید
$ir2 = file_get_contents("ir2.txt");
$channel = "@[*[CHANNEL]*]";//اینجا ایدی چنل اولت بدون@
$channel2 = "$chtan";//اینجا ایدی چنل دوم بدون@
$channel1= "$ir2";
$ch1sh= "$ir2";
$photozir = "https://t.me/iraniDomin/44";
 $chtan = file_get_contents("chtan.txt");

$zaman = IranTime();

$time_in = $db['time_in'];
$data = $update->callback_query->data;
$reply = $update->message->reply_to_message;
$step = file_get_contents("data/$chat_id/step.txt");
$type = file_get_contents("data/$chat_id/type.txt");
$coin = file_get_contents("data/$chat_id/coin.txt");
$create = file_get_contents("data/$chat_id/create.txt");
$frosh = file_get_contents("data/frosh.txt");
$sharzh_h1000 = file_get_contents("data/ham.txt");
$sharzh_ir300 = file_get_contents("data/iran.txt");
$type = file_get_contents("data/$chat_id/type.txt");
$number = file_get_contents("data/$chat_id/number.txt");
$code_taiid = file_get_contents("data/$chat_id/code taiid.txt");
$shoklat = file_get_contents("data/$chat_id/shoklat.txt");
$membrs = file_get_contents("data/$chat_id/membrs.txt");
$maroof =  file_get_contents("data/$from_id/maroof.txt");
$shoklt = file_get_contents("data/$chat_id/shoklat.txt");
$ban = file_get_contents("data/ban.txt");
$dt = "http://api.mostafa-am.ir/date-time/";
$jd_dt = json_decode(file_get_contents($dt),true);
$time=$jd_dt['time_en'];  
$dt = "http://api.mostafa-am.ir/date-time/";
$jd_dt = json_decode(file_get_contents($dt),true);
$date=$jd_dt['date_fa_num_en'];
#----------------------------------------------
	$tab = json_decode(file_get_contents("../../lib/Jsons/tab.json"));

#----------------------------------------------

$datee = file_get_contents("http://robot.teleagent.ir/date/");
//-----------------------------------------
$ham20 = file_get_contents("ham20.txt");
$ir10 = file_get_contents("ir10.txt");
$ir20 = file_get_contents("ir20.txt");
$ir30 = file_get_contents("ir30.txt");
#============همراه اول==========
@$sof2 = file_get_contents("data/sofs2.txt");
@$sof5= file_get_contents("data/sofs5.txt");
@$sof10 = file_get_contents("data/sofs10.txt");
@$sof20 = file_get_contents("data/sofs20.txt");
#------------------ایرانسل-----------------------
@$som2 = file_get_contents("data/soms2.txt");
@$som5 = file_get_contents("data/soms5.txt");
@$som10 = file_get_contents("data/soms10.txt");
@$som20 = file_get_contents("data/soms20.txt");
#===========iran===اضافه شارژ=========
@$adcod2 = file_get_contents("data/adscod2.txt");
@$adcod5 = file_get_contents("data/adscod5.txt");
@$adcod10 = file_get_contents("data/adscod10.txt");
@$adcod20 = file_get_contents("data/adscod20.txt");
#===============mci=========اضافه شارژ======================
@$adds2 = file_get_contents("data/mci2.txt");
@$adds5 = file_get_contents("data/mci5.txt");
@$adds10 = file_get_contents("data/mci10.txt");
@$adds20 = file_get_contents("data/mci20.txt");


$forchaneel = json_decode(file_get_contents("https://api.telegram.org/bot[*[TOKEN]*]/getChatMember?chat_id=@[*[CHANNEL]*]&user_id=".$from_id));
$tch = $forchaneel->result->status;

//=====

function IranTime(){
        date_default_timezone_set("Asia/Tehran");
        return date('H:i:s');
    }
//------------------------
function save($filename,$TXTdata)
  {
  $myfile = fopen($filename, "w") or die("Unable to open file!");
  fwrite($myfile, "$TXTdata");
  fclose($myfile);
  } 
function SendMessage($chat_id, $text){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>$text,
'parse_mode'=>'MarkDown']);
}


function EditMessageText($chat_id,$message_id,$text,$parse_mode,$disable_web_page_preview,$keyboard){
  bot('editMessagetext',[
    'chat_id'=>$chat_id,
 'message_id'=>$message_id,
    'text'=>$text,
    'parse_mode'=>$parse_mode,
 'disable_web_page_preview'=>$disable_web_page_preview,
    'reply_markup'=>$keyboard
 ]);
 }
 function SendPhoto($chat_id, $photo, $caption = null){
	bot('SendPhoto',[
	'chat_id'=>$chat_id,
	'photo'=>$photo,
	'caption'=>$caption
	]);
	}
	
	function objectToArrays($object){
        if (!is_object($object) && !is_array($object)) {
            return $object; }
        if (is_object($object)) {
            $object = get_object_vars($object);}
        return array_map("objectToArrays", $object);}
        
//------------------
$timing = date("Y-m-d-h-i-sa");
$timing = str_replace("am","",$timing);
$timing = str_replace("pm","",$timing);

$off_on = file_get_contents("bot.txt");

$metti_khan = file_get_contents("check/$timing-$from_id.txt");
$timing_spam = $metti_khan+1;
file_put_contents("check/$timing-$from_id.txt","$timing_spam");
//-------
if(strpos($off_on,"false") !== false && $chat_id != $admin){
 SendMessage($chat_id,"ربات خاموش میباشد 😴
چند دقیقه بعد دوباره امتحان ڪنید ⏰", null, $message_id, $remove);   
 return false;


}
if($text1=="/start"){
$user = file_get_contents('users.txt');
$members = explode("\n", $user);
if(!in_array($from_id, $members)){
$add_user = file_get_contents('users.txt');
$add_user .= $from_id . "\n";
file_put_contents("data/$chat_id/membrs.txt", "0");
file_put_contents("data/$chat_id/coin.txt", "1");
file_get_contents("data/$chat_id/invited.txt","0");

file_put_contents("data/$chat_id/type.txt", "Free");
file_put_contents('users.txt', $add_user);
}
file_put_contents("data/$chat_id/arsam.txt", "no");
 $ham2 = file_get_contents("ham2.txt"); 
 bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✔️ ساخته شده توسط :
🏵 @RozCreateBot
❌ ربات پیشرفته بساز ❌
",
]);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"< $ham2 >",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"دریافت شارژ🛍"]],
[['text'=>"حساب کاربری👮‍♂️"],['text'=>"زیرمجموعه گیری👥"]],
[['text'=>"افزایش موجودی🛒"],['text'=>"راهنما📜"]],
[['text'=>"تراکنش های اخیر📲"],['text'=>"پشتیبانی☎️"],['text'=>"استعلام شارژ💸"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif (strpos($text1, '/start') !== false) {
$newid = str_replace("/start ", "", $text1);
if($from_id == $newid) {
bot('sendMessage', [
'chat_id' => $chat_id,
'text' =>"متاسفانه شما نمیتوانید با لینک خودتان وارد ربات شوید 🤞",
]);
} 
elseif (strpos($list, "$from_id") !== false){
bot('sendMessage', [
'chat_id' => $chat_id,
'text' => "شما قبلا عضو این ربات بوده اید دیگر نمیتوانید زیر مجموعه کسی باشید 🤞",
]);
}else{
@$sho = file_get_contents("data/$newid/coin.txt");
$getsho = $sho + 1;
file_put_contents("data/$newid/coin.txt", $getsho);
@$sea = file_get_contents("data/$newid/membrs.txt");
$getsea = $sea + 1;
file_put_contents("data/$newid/membrs.txt", $getsea);
$user = file_get_contents('users.txt');
$members = explode("\n", $user);
if(!in_array($from_id, $members)){
$add_user = file_get_contents('users.txt');
$add_user .= $from_id . "\n";
@$sea = file_get_contents("data/$from_id/membrs.txt");
file_put_contents("data/$chat_id/membrs.txt", "0");
file_put_contents("data/$chat_id/coin.txt", "0");
file_put_contents("data/$chat_id/type.txt", "Free");
file_put_contents('users.txt', $add_user);
}
file_put_contents("data/$chat_id/arsam.txt", "No");
sendmessage($chat_id, "
شما با دعوت [کاربر](tg://user?id=$newid)عضو ربات ما شدید.⭐️
","Markdown","true");
 bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"",
]);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"< $ham2 >",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"دریافت شارژ🛍"]],
[['text'=>"حساب کاربری👮‍♂️"],['text'=>"زیرمجموعه گیری👥"]],
[['text'=>"افزایش موجودی🛒"],['text'=>"راهنما📜"]],
[['text'=>"تراکنش های اخیر📲"],['text'=>"پشتیبانی☎️"],['text'=>"استعلام شارژ💸"]],
],
'resize_keyboard'=>true,
])
]);
SendMessage($newid, "
یک نفر با لینک شما وارد ربات شده است 🌹

","Markdown","true");
}
}
elseif(strpos($blocklist, "$from_id") !== false  ) {
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"شما قادر به استفاده از سرویس ربات  $ham21 نیستید📍️",
'reply_markup'=>json_encode([
'remove_keyboard'=>true,
])
]);
}
#//////////////قفل ربات\\\\\\\\\\\\\\\\\\\\\

 #\\\\\\\\\\\\\\\\\\\\\\\////////////////////////////
}
elseif($text1=="┄┅| بازگشت |┅┄"){
    bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>"😍 به منوی اصلی برگشتید!",
        'parse_mode' => "MarkDown",
'reply_markup'=>json_encode([
    'keyboard'=>[
[['text'=>"دریافت شارژ🛍"]],
[['text'=>"حساب کاربری👮‍♂️"],['text'=>"زیرمجموعه گیری👥"]],
[['text'=>"افزایش موجودی🛒"],['text'=>"راهنما📜"]],
[['text'=>"تراکنش های اخیر📲"],['text'=>"پشتیبانی☎️"],['text'=>"استعلام شارژ💸"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($text1 =="دریافت شارژ🛍"){
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"
➰ اوپراتور مورد نظرتان را انتخاب نمایید :
",
 'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
'reply_markup'=>json_encode([
  'keyboard'=>[
      [['text'=>"📲رایتل"]],
[['text'=>"📲ایرانسل"],
['text'=>"📲همراه اول"]],

],
"resize_keyboard"=>true,
])
]);  
}
if($text1 == "📲همراه اول"){
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
🔹 مقدار شارژ مورد نظرتان را انتخاب نمایید :",
'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text' => "2,000 تومانی همراه اول"]],
[['text' => "5,000 تومانی همراه اول"]],
[['text' => "10,000 تومانی همراه اول"]],
[['text' => "20,000 تومانی همراه اول"]],
[['text' => "┄┅| بازگشت |┅┄"]]
]
])
]);
}
elseif($data == "boy221" or $data == ""){
bot('answercallbackquery',[
            'callback_query_id' => $update->callback_query->id,
            'text' => "⌛️ کمی صبر کنید...",
            'show_alert' => false
]); 
}
if($text1 =="📲ایرانسل"){
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
🔹 مقدار شارژ مورد نظرتان را انتخاب نمایید :",
'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text' => "2,000 تومانی ایرانسل"]],
[['text' => "5,000 تومانی ایرانسل"]],
[['text' => "10,000 تومانی ایرانسل"]],
[['text' => "20,000 تومانی ایرانسل"]],
[['text' => "┄┅| بازگشت |┅┄"]]
],
"resize_keyboard"=>true,
])
]);
}
if ($text1 == "زیرمجموعه گیری👥") {
 $ham10 = file_get_contents("ham10.txt");
		bot('sendPhoto',[
        'chat_id'=>$update->message->chat->id,
        'photo'=>"https://t.me/perti_land/31",
        'caption'=>"$ham10
t.me/[*[USERNAME]*]?start=$chat_id",
        ]);
	bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "📍 بنر بالا حاوی لینک دعوت شماست ان را برای دوستانتان ارسال کنید و با دعوت هر یک نفر زیر مجموعه های خود را افزایش دهید",
'reply_to_message_id'=>$message_id,
]); 
#-------------------------------------------------------------------------------
}
elseif($text1 =="2,000 تومانی ایرانسل"){
	if ($coin > $ham20){
	file_put_contents("data/frosh.txt",$frosh+1);
	file_put_contents("data/$chat_id/coin.txt",$coin-$ham20);
$sharzh = file_get_contents("sh_ir_2.txt");
$newsof = $soms2 + 1;
    file_put_contents("data/soms2.txt",$newsof);
    $newsof = $adcod2 - 1;
    file_put_contents("data/adcod2.txt",$newsof);
       	bot('sendPhoto',[
        'chat_id'=>$update->message->chat->id,
        'photo'=>"https://t.me/perti_land/40",
        'caption'=>" #خرید #موفق
      کد شارژ: $sharzh
      مقدار شارژ : 2000$
        $datee-$zaman
🛍 اطلاعات خریدار",
            'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"👉🏻ایدی خریدار👤","callback_data"=>"status"],['text'=>"$chat_id","callback_data"=>"profile"]],
[['text'=>"👉🏻اپراتور🌀","callback_data"=>"start-text"],['text'=>"️🌐ایرانسل🎁","callback_data"=>"send-text"]],
[['text'=>"کد شارژ🛍","callback_data"=>"send-all"],['text'=>"📲 : $sharzh","callback_data"=>"block-user"]],
 [['text' => "تراکنشات🍉", 'url' => "http://t.me/$ch1sh"]
        ],
],
])
]);
 bot('sendmessage', [
            'chat_id' => $admin,
            'text' => "کد شارژ ایرانسل 2000استفاده شد ! از پنل مدیریت کد جدید وارد کنید",
                ]);
 bot('sendPhoto',[
        'chat_id'=>$channel,
        'photo'=>"https://t.me/perti_land/32",
        'caption'=>"گزارش #خرید #موفق
              $datee-$zaman
🛍 اطلاعات خرید",
            'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"👉🏻ایدی خریدار👤","callback_data"=>"status"],['text'=>"$chat_id","callback_data"=>"profile"]],
[['text'=>"👉🏻اپراتور🌀","callback_data"=>"start-text"],['text'=>"️🌐ایرانسل🎁","callback_data"=>"send-text"]],
[['text'=>"👉🏻 نوع شارژ👤","callback_data"=>"send-all"],['text'=>"2000","callback_data"=>"block-user"]],
 [['text' => "📲شارژدهی📲", 'url' => "http://t.me/[*[USERNAME]*]"]
        ],
],
])
]);


    }else{
		bot('sendmessage', [
            'chat_id' => $chat_id,
 'text' => "⛔️موجودی شما کافی نمیباشد 
             موجودی شما : $coin
             الماس مورد نیاز برای دریافت شارژ : 10
             مقدار شارژ : 2000$",
            'reply_markup'=>json_encode([
'keyboard'=>[
[['text' => "┄┅| بازگشت |┅┄"]]
],
"resize_keyboard"=>true,
])
        ]);
        #///////////////////////////////////////////////////////////////////////
    }
}
elseif($text1 =="5,000 تومانی ایرانسل"){
 if ($coin > $ir20){
 file_put_contents("data/frosh.txt",$frosh+1);
 file_put_contents("data/$chat_id/$coincoin.txt",$coin-$ir20);
$sharzh = file_get_contents("sh_ir_5.txt");
$newsof = $soms5 + 1;
    file_put_contents("data/soms5.txt",$newsof);
     $newsof = $adcod5 - 1;
    file_put_contents("data/adcod5.txt",$newsof);
       	bot('sendPhoto',[
        'chat_id'=>$update->message->chat->id,
        'photo'=>"https://t.me/perti_land/40",
        'caption'=>" #خرید #موفق
      کد شارژ: $sharzh
      مقدار شارژ : 5000$
        $datee-$zaman
🛍 اطلاعات خریدار",
            'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"👉🏻ایدی خریدار👤","callback_data"=>"status"],['text'=>"$chat_id","callback_data"=>"profile"]],
[['text'=>"👉🏻اپراتور🌀","callback_data"=>"start-text"],['text'=>"️🌐ایرانسل🎁","callback_data"=>"send-text"]],
[['text'=>"کد شارژ🛍","callback_data"=>"send-all"],['text'=>"📲 : $sharzh","callback_data"=>"block-user"]],
 [['text' => "تراکنشات🍉", 'url' => "http://t.me/$ch1sh"]
        ],
],
])
]);
 bot('sendmessage', [
            'chat_id' => $admin,
            'text' => "کد شارژ ایرانسل 5000استفاده شد ! از پنل مدیریت کد جدید وارد کنید",
                ]);
 bot('sendPhoto',[
        'chat_id'=>$channel,
        'photo'=>"https://t.me/perti_land/32",
        'caption'=>"✅ گزارش #خرید #موفق
              $datee-$zaman
🛍 اطلاعات خرید",
            'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"👉🏻ایدی خریدار👤","callback_data"=>"status"],['text'=>"$chat_id","callback_data"=>"profile"]],
[['text'=>"👉🏻اپراتور🌀","callback_data"=>"start-text"],['text'=>"️🌐ایرانسل🎁","callback_data"=>"send-text"]],
[['text'=>"👉🏻 نوع شارژ👤","callback_data"=>"send-all"],['text'=>"5000","callback_data"=>"block-user"]],
 [['text' => "📲شارژدهی📲", 'url' => "http://t.me/[*[USERNAME]*]"]
        ],
],
])
]);


    }else{
  bot('sendmessage', [
            'chat_id' => $chat_id,
 'text' => "⛔️موجودی شما کافی نمیباشد 
             موجودی شما : $shoklt
             الماس مورد نیاز برای دریافت شارژ : $ir20
             مقدار شارژ : 5000$",
            'reply_markup'=>json_encode([
'keyboard'=>[
[['text' => "┄┅| بازگشت |┅┄"]]
],
"resize_keyboard"=>true,
])
        ]);
        #///////////////////////////////////////////////////////////////////////
    }
}
elseif($text1 =="10,000 تومانی ایرانسل"){
 if ($coin > $ir10){
 file_put_contents("data/frosh.txt",$frosh+1);
 file_put_contents("data/$chat_id/coin.txt",$coin-$ir10);
$sharzh = file_get_contents("sh_ir_10.txt");
$newsof = $soms10 + 1;
    file_put_contents("data/soms10.txt",$newsof);
     $newsof = $adcod10 - 1;
    file_put_contents("data/adcod10.txt",$newsof);
        	bot('sendPhoto',[
        'chat_id'=>$update->message->chat->id,
        'photo'=>"https://t.me/perti_land/40",
        'caption'=>" #خرید #موفق
      کد شارژ: $sharzh
      مقدار شارژ : 10.000$
        $datee-$zaman
🛍 اطلاعات خریدار",
            'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"👉🏻ایدی خریدار👤","callback_data"=>"status"],['text'=>"$chat_id","callback_data"=>"profile"]],
[['text'=>"👉🏻اپراتور🌀","callback_data"=>"start-text"],['text'=>"️🌐ایرانسل🎁","callback_data"=>"send-text"]],
[['text'=>"کد شارژ🛍","callback_data"=>"send-all"],['text'=>"📲 : $sharzh","callback_data"=>"block-user"]],
 [['text' => "تراکنشات🍉", 'url' => "http://t.me/$ch1sh"]
        ],
],
])
]);
 bot('sendmessage', [
            'chat_id' => $admin,
            'text' => "کد شارژ ایرانسل 10.000استفاده شد ! از پنل مدیریت کد جدید وارد کنید",
                ]);
bot('sendPhoto',[
        'chat_id'=>$channel,
        'photo'=>"https://t.me/perti_land/32",
        'caption'=>"✅ گزارش #خرید #موفق
              $datee-$zaman
🛍 اطلاعات خرید",
            'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"👉🏻ایدی خریدار👤","callback_data"=>"status"],['text'=>"$chat_id","callback_data"=>"profile"]],
[['text'=>"👉🏻اپراتور🌀","callback_data"=>"start-text"],['text'=>"️🌐ایرانسل🎁","callback_data"=>"send-text"]],
[['text'=>"👉🏻 نوع شارژ👤","callback_data"=>"send-all"],['text'=>"10.000","callback_data"=>"block-user"]],
 [['text' => "📲شارژدهی📲", 'url' => "http://t.me/[*[USERNAME]*]"]
        ],
],
])
]);


    }else{
  bot('sendmessage', [
            'chat_id' => $chat_id,
 'text' => "⛔️موجودی شما کافی نمیباشد 
             موجودی شما : $shoklt
             الماس مورد نیاز برای دریافت شارژ : $ir10
             مقدار شارژ : 10.000$",
            'reply_markup'=>json_encode([
'keyboard'=>[
[['text' => "┄┅| بازگشت |┅┄"]]
],
"resize_keyboard"=>true,
])
        ]);
        #///////////////////////////////////////////////////////////////////////
    }
}
elseif($text1 =="20,000 تومانی ایرانسل"){
 if ($coin > $ir30){
 file_put_contents("data/frosh.txt",$frosh+1);
 file_put_contents("data/$chat_id/coin.txt",$coin-$ir30);
$sharzh = file_get_contents("sh_ir_20.txt");
$newsof = $soms20 + 1;
    file_put_contents("data/soms20.txt",$newsof);
     $newsof = $adcod20 - 1;
    file_put_contents("data/adcod20.txt",$newsof);
        	bot('sendPhoto',[
        'chat_id'=>$update->message->chat->id,
        'photo'=>"https://t.me/perti_land/40",
        'caption'=>" #خرید #موفق
      کد شارژ: $sharzh
      مقدار شارژ : 20.000$
        $datee-$zaman
🛍 اطلاعات خریدار",
            'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"👉🏻ایدی خریدار👤","callback_data"=>"status"],['text'=>"$chat_id","callback_data"=>"profile"]],
[['text'=>"👉🏻اپراتور🌀","callback_data"=>"start-text"],['text'=>"️🌐ایرانسل🎁","callback_data"=>"send-text"]],
[['text'=>"کد شارژ🛍","callback_data"=>"send-all"],['text'=>"📲 : $sharzh","callback_data"=>"block-user"]],
 [['text' => "تراکنشات🍉", 'url' => "http://t.me/$ch1sh"]
        ],
],
])
]);
 bot('sendmessage', [
            'chat_id' => $admin,
            'text' => "کد شارژ ایرانسل 20.000استفاده شد ! از پنل مدیریت کد جدید وارد کنید",
                ]);
bot('sendPhoto',[
        'chat_id'=>$channel,
        'photo'=>"https://t.me/perti_land/32",
        'caption'=>"✅ گزارش #خرید #موفق
              $datee-$zaman
🛍 اطلاعات خرید",
            'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"👉🏻ایدی خریدار👤","callback_data"=>"status"],['text'=>"$chat_id","callback_data"=>"profile"]],
[['text'=>"👉🏻اپراتور🌀","callback_data"=>"start-text"],['text'=>"️🌐ایرانسل🎁","callback_data"=>"send-text"]],
[['text'=>"👉🏻 نوع شارژ👤","callback_data"=>"send-all"],['text'=>"20.000","callback_data"=>"block-user"]],
 [['text' => "📲شارژدهی📲", 'url' => "http://t.me/[*[USERNAME]*]"]
        ],
],
])
]);


    }else{
  bot('sendmessage', [
            'chat_id' => $chat_id,
 'text' => "⛔️موجودی شما کافی نمیباشد 
             موجودی شما : $shoklt
             الماس مورد نیاز برای دریافت شارژ : $ir30
             مقدار شارژ : 20.000$",
            'reply_markup'=>json_encode([
'keyboard'=>[
[['text' => "┄┅| بازگشت |┅┄"]]
],
"resize_keyboard"=>true,
])
        ]);
        #///////////////////////////////////////////////////////////////////////
    }
}

elseif($text1 =="2,000 تومانی همراه اول"){
	if ($coin > $ham20){
	file_put_contents("data/frosh.txt",$frosh+1);
	file_put_contents("data/$chat_id/coin.txt",$coin-$ham20);
$sharzh = file_get_contents("sh_hm.txt");   
$newsof = $sof2 + 1;
    file_put_contents("data/sofs2.txt",$newsof);
    $newsof = $adds2 - 1;
    file_put_contents("data/adds2.txt",$newsof);
        bot('sendPhoto',[
        'chat_id'=>$update->message->chat->id,
        'photo'=>"https://t.me/perti_land/39",
        'caption'=>" #خرید #موفق
      کد شارژ: $sharzh
      مقدار شارژ : 2000
        $datee-$zaman
🛍 اطلاعات خریدار",
            'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"👉🏻ایدی خریدار👤","callback_data"=>"status"],['text'=>"$chat_id","callback_data"=>"profile"]],
[['text'=>"👉🏻اپراتور🌀","callback_data"=>"start-text"],['text'=>"️🌐همراه اول🎁","callback_data"=>"send-text"]],
[['text'=>"کد شارژ🛍","callback_data"=>"send-all"],['text'=>"📲 : $sharzh","callback_data"=>"block-user"]],
 [['text' => "تراکنشات🍉", 'url' => "http://t.me/$ch1sh"]
        ],
],
])
]);
         bot('sendmessage', [
            'chat_id' => $admin,
            'text' => "کد شارژ همراه اول استفاده شد ! از پنل مدیریت کد جدید وارد کنید",
                ]);
                
        bot('sendPhoto',[
        'chat_id'=>$channel,
        'photo'=>"https://t.me/perti_land/34",
        'caption'=>"✅ گزارش #خرید #موفق
         $datee-$zaman
🛍 اطلاعات خرید",
            'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"👉🏻ایدی خریدار👤","callback_data"=>"status"],['text'=>"$chat_id","callback_data"=>"profile"]],
[['text'=>"👉🏻اپراتور🌀","callback_data"=>"start-text"],['text'=>"️🌐همراه اول🎁","callback_data"=>"send-text"]],
[['text'=>"👉🏻مقدار شارژ👤","callback_data"=>"send-all"],['text'=>"2000","callback_data"=>"block-user"]],
 [['text' => "📲شارژدهی📲", 'url' => "http://t.me/[*[USERNAME]*]"]
        ],
],
])
]);
    }else{
		bot('sendmessage', [
            'chat_id' => $chat_id,
 'text' => "⛔️موجودی شما کافی نمیباشد 
             موجودی شما : $shoklt
             الماس مورد نیاز برای دریافت شارژ : 10",
            'reply_markup'=>json_encode([
'keyboard'=>[
[['text' => "┄┅| بازگشت |┅┄"]]
],
"resize_keyboard"=>true,
])
        ]);
        #-----------------------------------------------------------------------
    }
}
elseif($text1 =="10,000 تومانی همراه اول"){
  if ($coin > $ir10){
  file_put_contents("data/$chat_id/coin.txt",$coin-$ir10);
$sharzh = file_get_contents("sh_hm_10.txt"); 
$newsof = $sof10 + 1;
    file_put_contents("data/sofs10.txt",$newsof);
      $newsof = $adds10 - 1;
    file_put_contents("data/adds10.txt",$newsof);
        bot('sendPhoto',[
        'chat_id'=>$update->message->chat->id,
        'photo'=>"https://t.me/perti_land/39",
        'caption'=>" #خرید #موفق
      کد شارژ: $sharzh
      مقدار شارژ : 10.000
        $datee-$zaman
🛍 اطلاعات خریدار",
            'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"👉🏻ایدی خریدار👤","callback_data"=>"status"],['text'=>"$chat_id","callback_data"=>"profile"]],
[['text'=>"👉🏻اپراتور🌀","callback_data"=>"start-text"],['text'=>"️🌐همراه اول🎁","callback_data"=>"send-text"]],
[['text'=>"کد شارژ🛍","callback_data"=>"send-all"],['text'=>"📲 : $sharzh","callback_data"=>"block-user"]],
 [['text' => "تراکنشات🍉", 'url' => "http://t.me/$ch1sh"]
        ],
],
])
]);
        bot('sendmessage', [
            'chat_id' => $admin,
            'text' => "کد شارژ 10.000 همراه استفاده شد ! از پنل مدیریت کد جدید وارد کنید",
                ]);
              bot('sendPhoto',[
        'chat_id'=>$channel,
        'photo'=>"https://t.me/perti_land/34",
        'caption'=>"✅ گزارش #خرید #موفق
        $datee-$zaman
🛍 اطلاعات خرید",
            'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"👉🏻ایدی خریدار👤","callback_data"=>"status"],['text'=>"$chat_id","callback_data"=>"profile"]],
[['text'=>"👉🏻اپراتور🌀","callback_data"=>"start-text"],['text'=>"️🌐همراه اول🎁","callback_data"=>"send-text"]],
[['text'=>"👉🏻 مقدار شارژ👤","callback_data"=>"send-all"],['text'=>"10.000","callback_data"=>"block-user"]],
 [['text' => "📲شارژدهی📲", 'url' => "http://t.me/[*[USERNAME]*]"]
        ],
],
])
]);
    }else{
    bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "⛔️موجودی شما کافی نمیباشد 
             موجودی شما : $shoklt
             الماس مورد نیاز برای دریافت شارژ : $ir10
             مقدار شارژ : 10.000 ",
            'reply_markup'=>json_encode([
'keyboard'=>[
[['text' => "┄┅| بازگشت |┅┄"]]
],
"resize_keyboard"=>true,
])
        ]); 
        #-----------------------------------------------------------------------
        
    }
}
elseif($text1 =="5,000 تومانی همراه اول"){
	if ($coin > $ir20){
	file_put_contents("data/$chat_id/coin.txt",$coin-$ir20);
$sharzh = file_get_contents("sh_hm_5.txt");
$newsof = $sof5 + 1;
    file_put_contents("data/sofs5.txt",$newsof);
      $newsof = $adds5 - 1;
    file_put_contents("data/adds5.txt",$newsof);
        bot('sendPhoto',[
        'chat_id'=>$update->message->chat->id,
        'photo'=>"https://t.me/perti_land/39",
        'caption'=>" #خرید #موفق
      کد شارژ: $sharzh
      مقدار شارژ : 5000
        $datee-$zaman
🛍 اطلاعات خریدار",
            'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"👉🏻ایدی خریدار👤","callback_data"=>"status"],['text'=>"$chat_id","callback_data"=>"profile"]],
[['text'=>"👉🏻اپراتور🌀","callback_data"=>"start-text"],['text'=>"️🌐همراه اول🎁","callback_data"=>"send-text"]],
[['text'=>"کد شارژ🛍","callback_data"=>"send-all"],['text'=>"📲 : $sharzh","callback_data"=>"block-user"]],
 [['text' => "تراکنشات🍉", 'url' => "http://t.me/$ch1sh"]
        ],
],
])
]);
        bot('sendmessage', [
            'chat_id' => $admin,
            'text' => "کد شارژ 5000 همراه استفاده شد ! از پنل مدیریت کد جدید وارد کنید",
                ]);
              bot('sendPhoto',[
        'chat_id'=>$channel,
        'photo'=>"https://t.me/perti_land/34",
        'caption'=>"✅ گزارش #خرید #موفق
        $datee-$zaman
🛍 اطلاعات خرید",
            'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"👉🏻ایدی خریدار👤","callback_data"=>"status"],['text'=>"$chat_id","callback_data"=>"profile"]],
[['text'=>"👉🏻اپراتور🌀","callback_data"=>"start-text"],['text'=>"️🌐همراه اول🎁","callback_data"=>"send-text"]],
[['text'=>"👉🏻 مقدار شارژ👤","callback_data"=>"send-all"],['text'=>"5000","callback_data"=>"block-user"]],
 [['text' => "📲شارژدهی📲", 'url' => "http://t.me/[*[USERNAME]*]"]
        ],
],
])
]);
    }else{
		bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "⛔️موجودی شما کافی نمیباشد 
             موجودی شما : $shoklt
             الماس مورد نیاز برای دریافت شارژ : $ir20
             مقدار شارژ : 5000 ",
            'reply_markup'=>json_encode([
'keyboard'=>[
[['text' => "┄┅| بازگشت |┅┄"]]
],
"resize_keyboard"=>true,
])
        ]);
        #----------------------------------------------------------------------
    }
}
elseif($text1 =="20,000 تومانی همراه اول"){
  if ($coin > $ir30){
  file_put_contents("data/$chat_id/coin.txt",$coin-$ir30);
$sharzh = file_get_contents("sh_hm_20.txt"); 
$newsof = $sof20 + 1;
    file_put_contents("data/sofs20.txt",$newsof);
      $newsof = $adds20 - 1;
    file_put_contents("data/adds20.txt",$newsof);
       bot('sendPhoto',[
        'chat_id'=>$update->message->chat->id,
        'photo'=>"https://t.me/perti_land/39",
        'caption'=>" #خرید #موفق
      کد شارژ: $sharzh
      مقدار شارژ : 20.000
        $datee-$zaman
🛍 اطلاعات خریدار",
            'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"👉🏻ایدی خریدار👤","callback_data"=>"status"],['text'=>"$chat_id","callback_data"=>"profile"]],
[['text'=>"👉🏻اپراتور🌀","callback_data"=>"start-text"],['text'=>"️🌐همراه اول🎁","callback_data"=>"send-text"]],
[['text'=>"کد شارژ🛍","callback_data"=>"send-all"],['text'=>"📲 : $sharzh","callback_data"=>"block-user"]],
 [['text' => "تراکنشات🍉", 'url' => "http://t.me/$ch1sh"]
        ],
],
])
]);
        bot('sendmessage', [
            'chat_id' => $admin,
            'text' => "کد شارژ 20.000 همراه استفاده شد ! از پنل مدیریت کد جدید وارد کنید",
                ]);
              bot('sendPhoto',[
        'chat_id'=>$channel,
        'photo'=>"https://t.me/perti_land/34",
        'caption'=>"✅ گزارش #خرید #موفق
      $datee-$zaman
🛍 اطلاعات خرید",
            'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"👉🏻ایدی خریدار👤","callback_data"=>"status"],['text'=>"$chat_id","callback_data"=>"profile"]],
[['text'=>"👉🏻اپراتور🌀","callback_data"=>"start-text"],['text'=>"️🌐همراه اول🎁","callback_data"=>"send-text"]],
[['text'=>"👉🏻 مقدار شارژ👤","callback_data"=>"send-all"],['text'=>"20.000","callback_data"=>"block-user"]],
 [['text' => "📲شارژدهی📲", 'url' => "http://t.me/[*[USERNAME]*]"]
        ],
],
])
]);
    }else{
    bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "⛔️موجودی شما کافی نمیباشد 
             موجودی شما : $shoklt
             الماس مورد نیاز برای دریافت شارژ : $ir30
             مقدار شارژ : 20.000 ",
            'reply_markup'=>json_encode([
'keyboard'=>[
[['text' => "┄┅| بازگشت |┅┄"]]
],
"resize_keyboard"=>true,
])
        ]);
        #\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
    }
}
        elseif($text1 =="📲رایتل"){
        bot('sendmessage', [
            'chat_id' => $chat_id,
 'text' => "💻این قسمت به زودی افتتاح خواهد شد🕶                                                          💥در حال کد نویسی...✍️",
            'reply_markup'=>json_encode([
'keyboard'=>[
[['text' => "┄┅| بازگشت |┅┄"]]
],
"resize_keyboard"=>true,
   ])
   ]);
     /*   }
elseif($text1 == "/creator"){
  $creator = file_get_contents("../../lib/Texts/creator.txt");
        bot('sendmessage', [
            'chat_id' => $chat_id,
 'text' => "$creator",
    ]);*/
        #\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
        }

elseif($text1 =="حساب کاربری👮‍♂️"){
$mems = file_get_contents("data/$chat_id/invited.txt");
$ham21 = file_get_contents("ham21.txt"); 
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"
🎫 حساب کاربری شما در ربات :

🗣 نام : $first_name
🆔 شناسه : $chat_id
💎 موجودی شما : $coin سکه
👥 تعداد زیر مجموعه ها : $mems نفر

 شما میتوانید با دعوت دیگران از طریق لینک دعوت اختصاصی خودت اقدام به افزایش موجودی و تبدیل سکه به شارژ کنید

🎊 ربات < $ham21 > برای جذب اعتماد شما کانالی برای گزارش خرید ها تهیه کرده است که گزارش تمام خرید ها در کانال @$ch1sh ارسال میشوند
",

]);
#//////////////////////////////////////////////////////////////////////////////

}
elseif($text1 =="استعلام شارژ💸"){
        bot('sendmessage', [
            'chat_id' => $chat_id,
 'text' => "☑️ لیست اوپراتور هایی که در ربات موجودی دارند :

🌐 استعلام شارژ ها هر 10 دقیقه یک بار بروز می شود:
  $zaman  ",


  'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
'reply_markup'=>json_encode([
  'inline_keyboard'=>[
[['text'=>"👇🏻نام اوپراتور 📲","callback_data"=>"status"],['text'=>"👇🏻مقدار شارژ 💳","callback_data"=>"profile"],['text'=>"👇🏻استعلام ☑️️","callback_data"=>"profile"]],
[['text'=>"💛 ایرانسل","callback_data"=>"status"],['text'=>"2,000","callback_data"=>"profile"],['text'=>"✔️","callback_data"=>"profile"]],
[['text'=>"💛 ایرانسل","callback_data"=>"status"],['text'=>"5,000","callback_data"=>"profile"],['text'=>"✔️","callback_data"=>"profile"]],
[['text'=>"💛 ایرانسل","callback_data"=>"status"],['text'=>"10.000","callback_data"=>"profile"],['text'=>"✔️","callback_data"=>"profile"]],
[['text'=>"💛 ایرانسل","callback_data"=>"status"],['text'=>"20,000","callback_data"=>"profile"],['text'=>"✔️","callback_data"=>"profile"]],
[['text'=>"👇🏻نام اوپراتور 📲","callback_data"=>"status"],['text'=>"👇🏻مقدار شارژ 💳","callback_data"=>"profile"],['text'=>"👇🏻استعلام ☑️","callback_data"=>"profile"]],
[['text'=>"💙 همراه اول","callback_data"=>"status"],['text'=>"2,000","callback_data"=>"profile"],['text'=>"✔️","callback_data"=>"profile"]],
[['text'=>"💙 همراه اول","callback_data"=>"status"],['text'=>"5,000","callback_data"=>"profile"],['text'=>"✔️","callback_data"=>"profile"]],
[['text'=>"💙 همراه اول","callback_data"=>"status"],['text'=>"10.000","callback_data"=>"profile"],['text'=>"✔️","callback_data"=>"profile"]],
[['text'=>"💙 همراه اول","callback_data"=>"status"],['text'=>"20,000","callback_data"=>"profile"],['text'=>"✔️","callback_data"=>"profile"]],
[['text'=>"👇🏻نام اوپراتور 📲","callback_data"=>"status"],['text'=>"👇🏻مقدار شارژ 💳","callback_data"=>"profile"],['text'=>"👇🏻استعلام ☑️","callback_data"=>"profile"]],
[['text'=>"💜 رایتل","callback_data"=>"status"],['text'=>"2,000","callback_data"=>"profile"],['text'=>"❌","callback_data"=>"profile"]],
[['text'=>"💜 رایتل","callback_data"=>"status"],['text'=>"5,000","callback_data"=>"profile"],['text'=>"❌","callback_data"=>"profile"]],
[['text'=>"💜 رایتل","callback_data"=>"status"],['text'=>"10.000","callback_data"=>"profile"],['text'=>"❌","callback_data"=>"profile"]],
[['text'=>"💜 رایتل","callback_data"=>"status"],['text'=>"20,000","callback_data"=>"profile"],['text'=>"❌","callback_data"=>"profile"]],
],
"resize_keyboard"=>true,
])
]);

	 #==========================================================================

#===============================================================================    
}
//===============حساب ویژه==============//
elseif($text1 == "تراکنش های اخیر📲"){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"◼️ تعداد شارژ فروخته شده در ربات : $frosh
",
]);

#===============================================================================

}
elseif($text1 =="افزایش موجودی🛒"){
 $ham5 = file_get_contents("ham5.txt"); 
bot('sendmessage', [
'chat_id' => $chat_id,
'text' => "✅ جهت خرید موجودی برو روی مبلغ دلخواه کلیک کنید :",
 'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
'reply_markup'=>json_encode([
  'inline_keyboard'=>[

[['text' => "خرید موجودی 💰", 'url' => "https://t.me/$ham5"]],
],
"resize_keyboard"=>true,
])
]);
#===============================================================================
}

elseif($text1 =="راهنما📜"){
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🔖 راهنمای خرید شارژ از ربات
🔸 ضمن تشکر از شما کاربرگرامی برای انتخاب ربات جهت خرید شارژ اپراتور؛

1️⃣ برای خرید شارژ ابتدا از طریق دکمه استعلام شارژها ، شارژ موجود را مشاهده و سپس اقدام به خرید کنید.

2️⃣ اگر تعداد سکه های شما برابر با تعداد سکه های لازم برای بود ، کد شارژ به صورت تصویری برای شما ارسال خواهد شد.

📌با دکمه خرید شارژ میتوانید شارژ دریافت کنید.",
 'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
]);
#===============================================================================
}  
    elseif($text1=="تنظیم متن استارت" && $chat_id == $admin ){
  file_put_contents("data/$chat_id/step.txt","ham2");
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"
🎗 متن استارت مورد نظر خود را ارسال نمایید :️",
 'parse_mode'=>"MarkDown",
  ]);
}
elseif($chat_id == $admin && $step == "ham2" ){ 
file_put_contents("ham2.txt","$text1");
file_put_contents("data/$chat_id/step.txt","no");
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"
تنظیم شد ✔️",
 'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
]);
#===============================================================================
	}  
    elseif($text1=="ایدی ادمین⚡️" && $chat_id == $admin ){
  file_put_contents("data/$chat_id/step.txt","ham5");
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ایدی خود را بدون @ بفرستید.",
 'parse_mode'=>"MarkDown",
  ]);
}
elseif($chat_id == $admin && $step == "ham5" ){ 
file_put_contents("ham5.txt","$text1");
file_put_contents("data/$chat_id/step.txt","no");
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تنظیم شد ✔️",
 'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
]);
#===============================================================================
}  
    elseif($text1=="تنظیم نام ربات⚡️" && $chat_id == $admin ){
  file_put_contents("data/$chat_id/step.txt","ham21");
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"
🎗 نام ربات خود را ارسال نمایید :
    مثال : هندونه شارژ.رز شارژو️",
 'parse_mode'=>"MarkDown",
  ]);
}
elseif($chat_id == $admin && $step == "ham21" ){ 
file_put_contents("ham21.txt","$text1");
file_put_contents("data/$chat_id/step.txt","no");
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"
تنظیم شد ✔️",
 'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
]);
#===============================================================================
} 
    elseif($text1=="کانال تراکنشات" && $chat_id == $admin ){
  file_put_contents("data/$chat_id/step.txt","ir2");
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"یوزرنیم چنل رو بدون @ بفرست",
 'parse_mode'=>"MarkDown",
  ]);
}
elseif($chat_id == $admin && $step == "ir2" ){ 
file_put_contents("ir2.txt","$text1");
file_put_contents("data/$chat_id/step.txt","no");
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تنظیم شد ✔️",
 'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
]);
#===============================================================================
} 
	  elseif($text1=="افزودن ادمین ➕" && $chat_id == $admin ){
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"به زودی...",
 'parse_mode'=>"MarkDown",
  ]);

#===============================================================================
	}  
    elseif($text1=="2000✴️" && $chat_id == $admin ){
  file_put_contents("data/$chat_id/step.txt","ham20");
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"
📍 حالا مقدار امتیازی که برای کسر در برابر شارژ 2,000 کسر شود را وارد نمایید :",
 'parse_mode'=>"MarkDown",
  ]);
}
elseif($chat_id == $admin && $step == "ham20" ){ 
file_put_contents("ham20.txt","$text1");
file_put_contents("data/$chat_id/step.txt","no");
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تنظیم شد ✔️",
 'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
]);
#=============================================================================
} 
    elseif($text1=="️5000✴️" && $chat_id == $admin ){
  file_put_contents("data/$chat_id/step.txt","ir20");
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"📍 حالا مقدار امتیازی که برای کسر در برابر شارژ 5,000 کسر شود را وارد نمایید :",
 'parse_mode'=>"MarkDown",
  ]);
}
elseif($chat_id == $admin && $step == "ir20" ){ 
file_put_contents("ir20.txt","$text1");
file_put_contents("data/$chat_id/step.txt","no");
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تنظیم شد ✔️",
 'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
]);
#===============================================================================
} 
	  elseif($text1=="10.000✴️" && $chat_id == $admin ){
	file_put_contents("data/$chat_id/step.txt","ir10");
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"📍 حالا مقدار امتیازی که برای کسر در برابر شارژ 10,000 کسر شود را وارد نمایید :",
 'parse_mode'=>"MarkDown",
  ]);
}
elseif($chat_id == $admin && $step == "ir10" ){ 
file_put_contents("ir10.txt","$text1");
file_put_contents("data/$chat_id/step.txt","no");
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تنظیم شد ✔️",
 'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
]);
#-------------------------------------------------------------------------------
} 
    elseif($text1=="20.000✴️" && $chat_id == $admin ){
  file_put_contents("data/$chat_id/step.txt","ir30");
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"📍 حالا مقدار امتیازی که برای کسر در برابر شارژ 20,000 کسر شود را وارد نمایید :",
 'parse_mode'=>"MarkDown",
  ]);
}
elseif($chat_id == $admin && $step == "ir30" ){ 
file_put_contents("ir30.txt","$text1");
file_put_contents("data/$chat_id/step.txt","no");
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تنظیم شد ✔️",
 'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
]);
#-----------------------------------------------------------------------------
}  
    elseif($text1=="متن زیرمجموعه⚡️" && $chat_id == $admin ){
  file_put_contents("data/$chat_id/step.txt","ham10");
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"📝متن زیرمجموعه خود را ارسال کنید🔎",
 'parse_mode'=>"MarkDown",
  ]);
}
elseif($chat_id == $admin && $step == "ham10" ){ 
file_put_contents("ham10.txt","$text1");
file_put_contents("data/$chat_id/step.txt","no");
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تنظیم شد ✔️ ",
 'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
]);
#=======///////////=================//////////////////=================/////////
 }
	if($text1 == "تنظیم امتیاز 🚧" && $chat_id == $admin){
	  bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ادمین عزیز برای تایین امتیاز از دکمه زیر استفاده کنید.",
  'reply_markup'=>json_encode([
                    'keyboard'=>[
  
[['text'=>"2000✴️"]],
[['text'=>"️5000✴️"]],
[['text'=>"10.000✴️"]],
[['text'=>"20.000✴️"]],
[['text'=>"┄┅| بازگشت |┅┄"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
#======///////////=============//////////
}  

	elseif($text1=="تنظیم کانال〽️️" && $chat_id == $admin ){
	      file_put_contents("data/$chat_id/step.txt","chtan");
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🔸 یوزرنیم کانال اصلی را بدون @ ارسال نمایید :",
 ]);
	}
elseif($chat_id == $admin && $step == "chtan" ){ 
file_put_contents("chtan.txt","$text1");
file_put_contents("data/$chat_id/step.txt","no");
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تنظیم شد ✔️ ",
 'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
]);
/////////==================//////=////
}  

	elseif($text1=="🆙️ارتقا ربات♻️" && $chat_id == $admin ){           
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"با تشکر از همراهی شما
 
 ربات شارژدهی شما ویژه شده است دیگر نیاز  ویژه شدن نیست.",
 ]);
 }
	if($text1 == "پنل" && $chat_id == $admin){
	  bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ادمین عزیز به پنل مدیریت ربات خوش آمدید💎",
  'reply_markup'=>json_encode([
                    'keyboard'=>[
    [['text'=>"🆙️ارتقا ربات♻️"]],
  [['text'=>"امار📊"]],
[['text'=>""],['text'=>""]],
[['text'=>"تنظیم کانال〽️️"],['text'=>"کانال تراکنشات"]],
[['text'=>""],['text'=>""]],
[['text'=>"افزودن کد➕"],['text'=>""],['text'=>"تنظیم امتیاز 🚧"]],
[['text'=>"تنظیمات📝"],['text'=>"افزودن ادمین ➕"]],
[['text'=>""],['text'=>""]],
[['text'=>"خاموش کردن ربات🚫"],['text'=>"روشن کردن ربات♨️"]],
[['text'=>"┄┅| بازگشت |┅┄"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
#===============================================================================
  }
      elseif($text1=="امار📊" && $chat_id == $admin ){ 
   $txtt = file_get_contents('users.txt');
    $member_id = explode("\n",$txtt);
    $amar = count($member_id) -1;
  $frosh = file_get_contents("data/frosh.txt");
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"
آماردهی پیشرفته ⚙️ :

👤 تعداد کاربران ربات : $amar
🔰 تعداد مدیران ربات : 1
◼️ تعداد شارژ فروخته شده در ربات : $frosh
",
 'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
]);
#===============================================================================
 }
	if($text1 == "تنظیمات📝" && $chat_id == $admin){
	  bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ادمین عزیز برای تایین متن یا ایدی از دکمه زیر استفاده کنید.",
  'reply_markup'=>json_encode([
                    'keyboard'=>[
  [['text'=>"ایدی ادمین⚡️"]],
[['text'=>"متن زیرمجموعه⚡️"]],
[['text'=>"تنظیم متن استارت️"]],
[['text'=>"تنظیم نام ربات⚡️"]],
[['text'=>"┄┅| بازگشت |┅┄"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}  

	elseif($text1=="افزودن کد➕" && $chat_id == $admin ){           
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"اپراتور مورد نظر خود را انتخاب کنید :|",
  'reply_markup'=>json_encode([
                    'keyboard'=>[
  [['text'=>"همراه اول"],['text'=>"ایرانسل"],['text'=>""]],
  [['text'=>"┄┅| بازگشت |┅┄"]],
	],
		"resize_keyboard"=>true,
 	 ])
	 ]);
#===============================================================================
}
elseif($text1=="همراه اول" && $chat_id == $admin ){
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"❤️ چه خوب 😂
شارژ چندی خریدی؟
⚠️حتما باید کد شارژ به صورت عدد 16 رقمی بفرستی⚠️",
 'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text' => ".2000."]],
[['text' => ".5000."]],
[['text' => ".10.000."]],
[['text' => ".20.000."]],
[['text' => "┄┅| بازگشت |┅┄"]]
],
"resize_keyboard"=>true,
])
]);
}  

  elseif($text1==".2000." && $chat_id == $admin ){
  file_put_contents("data/$chat_id/step.txt","adcode_hm");
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"
💳 کد شارژ همراه اول را به موجودی  2,000 تومان ارسال کنید :️",
 'parse_mode'=>"MarkDown",
  ]);
}
elseif($chat_id == $admin && $step == "adcode_hm" ){ 
file_put_contents("sh_hm_2.txt","$text1");
file_put_contents("data/$chat_id/step.txt","no");
$newsof = $adcod2 + 1;
    file_put_contents("data/adcod2.txt",$newsof);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کد شارژ جدید2000 تومنی همراه با موفیقیت افزوده شد :)
 ",
 'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
]);
}  

  elseif($text1==".5000." && $chat_id == $admin ){
  file_put_contents("data/$chat_id/step.txt","adcode_hm");
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"💳 کد شارژ همراه اول را به موجودی  5,000 تومان ارسال کنید :️️",
 'parse_mode'=>"MarkDown",
  ]);
}
elseif($chat_id == $admin && $step == "adcode_hm" ){ 
file_put_contents("sh_hm_5.txt","$text1");
file_put_contents("data/$chat_id/step.txt","no");
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کد شارژ جدید5000 تومنی همراه با موفیقیت افزوده شد :)
 ",
 'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
]);
}  

  elseif($text1==".10.000." && $chat_id == $admin ){
  file_put_contents("data/$chat_id/step.txt","adcode_hm");
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"💳 کد شارژ همراه اول را به موجودی  10,000 تومان ارسال کنید :️️",
 'parse_mode'=>"MarkDown",
  ]);
}
elseif($chat_id == $admin && $step == "adcode_hm" ){ 
file_put_contents("sh_hm_10.txt","$text1");
file_put_contents("data/$chat_id/step.txt","no");
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کد شارژ جدید10.000 تومنی همراه با موفیقیت افزوده شد :)
 ",
 'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
]);
}  

  elseif($text1==".20.000." && $chat_id == $admin ){
  file_put_contents("data/$chat_id/step.txt","adcode_hm");
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"💳 کد شارژ همراه اول را به موجودی  20,000 تومان ارسال کنید :️️",
 'parse_mode'=>"MarkDown",
  ]);
}
elseif($chat_id == $admin && $step == "adcode_hm" ){ 
file_put_contents("sh_hm_20.txt","$text1");
file_put_contents("data/$chat_id/step.txt","no");
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کد شارژ جدید20.000 تومنی همراه با موفیقیت افزوده شد :)
 ",
 'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
]);
#===============================================================================
}
elseif($text1=="ایرانسل" && $chat_id == $admin ){
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"❤️ چه خوب 😂
شارژ چندی خریدی؟
⚠️حتما باید کد شارژ به صورت عدد 16 رقمی بفرستی⚠️",
 'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text' => "2000"]],
[['text' => "5000"]],
[['text' => "10.000"]],
[['text' => "20.000"]],
[['text' => "┄┅| بازگشت |┅┄"]]
],
"resize_keyboard"=>true,
])
]);
}
    elseif($text1=="2000" && $chat_id == $admin ){
  file_put_contents("data/$chat_id/step.txt","adcode_ir");
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"]
💳 کد شارژ ایرانسل را به موجودی  2,000 تومان ارسال کنید :️",
 'parse_mode'=>"MarkDown",
  ]);
}
elseif($chat_id == $admin && $step == "adcode_ir" ){ 
file_put_contents("sh_ir_2.txt","$text1");
file_put_contents("data/$chat_id/step.txt","no");
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کد شارژ جدید 2000 تومنی ایرانسل با موفیقیت افزوده شد :)
 ",
 'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
]);
}
    elseif($text1=="5000" && $chat_id == $admin ){
  file_put_contents("data/$chat_id/step.txt","adcode_ir");
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"💳 کد شارژ ایرانسل را به موجودی  5,000 تومان ارسال کنید :️",
 'parse_mode'=>"MarkDown",
  ]);
}
elseif($chat_id == $admin && $step == "adcode_ir" ){ 
file_put_contents("sh_ir_5.txt","$text1");
file_put_contents("data/$chat_id/step.txt","no");
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کد شارژ جدید 5000 تومنی ایرانسل با موفیقیت افزوده شد :)
 ",
 'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
]);
}
    elseif($text1=="10.000" && $chat_id == $admin ){
  file_put_contents("data/$chat_id/step.txt","adcode_ir");
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"💳 کد شارژ ایرانسل را به موجودی  10,000تومان ارسال کنید :️",
 'parse_mode'=>"MarkDown",
  ]);
}
elseif($chat_id == $admin && $step == "adcode_ir" ){ 
file_put_contents("sh_ir_10.txt","$text1");
file_put_contents("data/$chat_id/step.txt","no");
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کد شارژ جدید 10.000 تومنی ایرانسل با موفیقیت افزوده شد :)
 ",
 'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
]);
}
    elseif($text1=="20.000" && $chat_id == $admin ){
  file_put_contents("data/$chat_id/step.txt","adcode_ir");
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"💳 کد شارژ ایرانسل را به موجودی  20,000تومان ارسال کنید :️",
 'parse_mode'=>"MarkDown",
  ]);
}
elseif($chat_id == $admin && $step == "adcode_ir" ){ 
file_put_contents("sh_ir_20.txt","$text1");
file_put_contents("data/$chat_id/step.txt","no");
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کد شارژ جدید 20.000 تومنی ایرانسل با موفیقیت افزوده شد :)
 ",
 'reply_to_message_id'=>$message_id,
'parse_mode' => "MarkDown",
]);
#===============================================================================

#/////////////////////////////////////////////////////////////////////
}
elseif ($text1 == "روشن کردن ربات♨️" && $chat_id == $admin) {
file_put_contents("bot.txt","true");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"ربات روشن شد .
✅",
]);
#/////////////////////////////////////////////////////////////////////
}
elseif ($text1 == "خاموش کردن ربات🚫" && $chat_id == $admin) {
file_put_contents("bot.txt","false");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"ربات خاموش شد ...❌",
]);
#/////////////////////////////////////////////////////////////////////

#===============================================================================	 
 


}
unlink("error_log");

?>