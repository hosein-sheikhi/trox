<?php

/*
بسم الله الرحمن الرحیم

اپن شده توسط :@Mr_Ho3win

----------------------------
سورس های بیشتر در چنل لورکس تیم 
@LorexTeam 
-----------------------------

*/
ob_start();
$load = sys_getloadavg();
$telegram_ip_ranges = [
['lower' => '149.154.160.0', 'upper' => '149.154.175.255'], 
['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],    
];
$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
$ok=false;
foreach ($telegram_ip_ranges as $telegram_ip_range) if (!$ok) {
$lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
$upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
if($ip_dec >= $lower_dec and $ip_dec <= $upper_dec) $ok=true;
}
if(!$ok) die("Sik by /=");
include("jdf.php");
include ("KosAbjit.php");
if(!is_dir('DataRoBoots')){
    mkdir('DataRoBoots');
}

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$from_id = $message->from->id;
$message_id = $message->message_id;
$username = $message->from->username;
$textmassage = $message->text;
mkdir("data0000/$from_id");
$text1 = $update->message->text;
$text = $update->message->text;
$text3 = $update->message->text;
 $Dev = [*[ADMN]*];
$first_name = $update->message->from->first_name;
$last_name = $update->message->from->last_name;
$username = $update->message->from->username;
$Lock = file_get_contents("Lock.json");
$SerVerFree = file_get_contents("SerVerFree.json");
$first = $update->message->from->first_name;
$firstname = $update->callback_query->message->chat->first_name;
$last_name = $update->callback_query->message->chat->last_name;
$username = $update->callback_query->message->chat->username;
$rt = $update->message->reply_to_message;
$tc = $update->message->chat->type;
$reply = $update->message->reply_to_message;
$reply = $update->message->reply_to_message;
@$rt = $update->message->reply_to_message;
$rt_id = $rt->message_id;
$rtid = $rt->from->id;
$rt_name = $rt->from->first_name;
$contact = $message->contact;
$contactid = $contact->user_id;
$contactnum = $contact->phone_number;
$coin = file_get_contents("data0000/$from_id/coin.txt");
$bot = file_get_contents("data0000/$from_id/step.txt");
$wait = file_get_contents("data0000/$from_id/wait.txt");
$allcoin = file_get_contents("data0000/$from_id/allcoin.txt");
@$onof = file_get_contents("data0000/onof.txt");
@$list = file_get_contents("MMBER.txt");
@$sea = file_get_contents("data0000/$from_id/membrs.txt");
$step = file_get_contents("data0000/$from_id/step.txt");
$state = file_get_contents("data0000/$from_id/state.txt");
$Members = file_get_contents("data0000/Member.txt");
$rooz = jdate('j');
$mah = jdate('n');
$sal = jdate('y');
$ambar = "$sal/$mah/$rooz";
$type = file_get_contents("data0000/$from_id/type.txt");
$Viph = file_get_contents("data0000/$from_id/Viph.txt");
$to =  file_get_contents("data0000/$from_id/token.txt");
$zaman = file_get_contents("data0000/$from_id/zaman.txt");
$bta = file_get_contents("data0000/$from_id/bta.txt");
$url =  file_get_contents("data0000/$from_id/url.txt");
$flist =  file_get_contents("data0000/$from_id/flist.txt");
$addres =  file_get_contents("data0000/$from_id/addres.txt");
$nfile =  file_get_contents("data0000/$from_id/namefile.txt");
$fcode =  file_get_contents("data0000/$from_id/fcode.txt");
$fup =  file_get_contents("data0000/$from_id/fup.txt");
$forchaneel = json_decode(file_get_contents("https://api.telegram.org/bot$token/getChatMember?chat_id=@$channel&user_id=".$from_id));
$tch = $forchaneel->result->status;
$forchaneel1 = json_decode(file_get_contents("https://api.telegram.org/bot$token/getChatMember?chat_id=@$channel&user_id=".$from_id));
$tch1 = $forchaneel1->result->status;
$forchaneel2 = json_decode(file_get_contents("https://api.telegram.org/bot$token/getChatMember?chat_id=@$channel&user_id=".$from_id));
$tch2 = $forchaneel2->result->status;
$Ho3win = file_get_contents("data0000/$from_id/Ho3win.txt");
$file=file_get_contents("data0000/$from_id/file.txt");
$baner = "https://t.me/MrshendiGap/88";
$command = file_get_contents("data0000/$chat_id/com.txt");
@$amir = file_get_contents("data0000/$chat_id/amir.txt");
$fasl = jdate('f');
$month_name= jdate('F');
$day_name= jdate('l');
$tarikh = jdate('y/n/j');
$hour = jdate('H:i:s - a');
$animal = jdate('q');
$year = file_get_contents("https://api.codebazan.ir/new-year/");
$yesas = json_decode($year,true);
$day = $yesas["day"];
$hourss = $yesas["hour"];
$min = $yesas["min"];
$sec = $yesas["sec"];
$bot = "[*[USRNAME]*]"; 
@$list = file_get_contents("MMBER.txt");
@$sea = file_get_contents("data0000/$from_id/membrs.txt");
@$createclicker = file_get_contents("user/$chat_id/createclicker.txt");
@$tokenhelper = file_get_contents("data0000/$chat_id/tokenhelper.txt");
@$idhelper = file_get_contents("data0000/$chat_id/idhelper.txt");
@$idadmin = file_get_contents("data0000/$chat_id/idadmin.txt");
@$channelmem = file_get_contents("data0000/$chat_id/channelmem.txt");
$members = file_get_contents('Member.txt');
$memlist = explode("\n", $members);
$member = file_get_contents("data0000/$from_id/member.txt");
$Ho3win = file_get_contents("data0000/$from_id/Ho3win.txt");
$mybots = file_get_contents("DataRoBoots/$from_id.txt");
$man = file_get_contents("data0000/$from_id/man.txt");
$blocklist = file_get_contents("data0000/blocklist.txt");
$da = $update->message->reply_to_message->forward_from->id;
$forward_chat_username = $update->message->forward_from_chat->username;
$created = file_get_contents("data0000/$from_id/create.txt");
$Bots = file_get_contents("data0000/bots.txt");
$user_bots = file_get_contents("data0000/$from_id/bots.txt");
$my_id = file_get_contents("LorexTeam/$text/data0000/my_id.txt");
$time = jdate("H:i:s");
$timenow = time("h:i:s");
$timenow = time();
$emtiaz = file_get_contents("data0000/$from_id/emtiaz.txt");
$lasttime = file_get_contents("data0000/$from_id/time.txt");
$warn = file_get_contents("data0000/$from_id/warn.txt");
$emtiaz = file_get_contents("data0000/$from_id/coin.txt");
function Spam($user_id){
@mkdir("data0000/spam");
$spam_status = json_decode(file_get_contents("data0000/spam/$user_id.json"),true);
if($spam_status != null){
if(mb_strpos($spam_status[0],"time") !== false){
if(str_replace("time ",null,$spam_status[0]) >= time())
exit(false);
else
$spam_status = [1,time()+2];
}

elseif(time() < $spam_status[1]){
if($spam_status[0]+1 > 3){
$time = time() + 500;
$spam_status = ["time $time"];
file_put_contents("data0000/spam/$user_id.json",json_encode($spam_status,true));
bot('sendMessage',[
'chat_id'=>$user_id,
'text'=>"➖➖➖➖➖➖➖➖➖➖
⚠️به علت ارسال پیام مکرر 500 ثانیه مسدود شدید

⚠️ You were blocked for 500 seconds due to repeated messages
➖➖➖➖➖➖➖➖➖➖",
]);
exit(false);
}else{
$spam_status = [$spam_status[0]+1,$spam_status[1]];
}}else{
$spam_status = [1,time()+2];
}}else{
$spam_status = [1,time()+2];
}
file_put_contents("data0000/spam/$user_id.json",json_encode($spam_status,true));
}
Spam($from_id);
//=============================
function checkS($src){
$r = "";
function test($src, $t){
$r = "";
$e = explode($t, strtolower($src));
$line = count(explode("\n", $e[0]));
unset($e[0]);
foreach($e as $q){
$r .= "\nهشدار! خط: $line\nنوع: $t\nخط کد: ".explode("\n", $src)[$line-1]."\n";
$line += count(explode("\n", $q))-1;
}
return $r;
}
function test2($src, $t, $aaa){
$r = "";
$e = explode($t, strtolower($src));
$line = count(explode("\n", $e[0]));
unset($e[0]);
foreach($e as $q){
$b = true;
foreach($aaa as $aa){
if(substr($q, 0, strlen($aa))==$aa){
$b = false;
}
}
if($b===true){
$r .= "\nهشدار! خط: $line\nنوع: $t\nخط کد: ".explode("\n", $src)[$line-1]."\n";
}
$line += count(explode("\n", $q))-1;
}
return $r;
}
$r = "";
$all = ["eval", "include", "unlink", "request", "mkdir", "rmdir", "scandir", "exec", "file(", "__FILE__", "__DIR__", '$_SERVER'];
foreach($all as $a)
$r .= test($src, $a);
$r .= test2($src, "file_get_contents", ["('data", '("data']);
$r .= test2($src, "file_put_contents", ["('data", '("data']);
return $r;
}
if(strpos($blocklist, "$chat_id") !== false){
exit;
}
if($warn >= 2){
sleep(3600);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"اخطار شما به 2 رسیده است بیشتر مراقب باشید 😢",
'parse_mode'=>"HTML",
]); 
exit();
}
if(strpos($text, 'zip') !== false or strpos($text, 'ZIP') !== false or strpos($text, 'Zip') !== false or strpos($text, 'ZIp') !== false or strpos($text, 'zIP') !== false or strpos($text, 'ZipArchive') !== false or strpos($text, 'ZiP') !== false){
SendMessage($chat_id,"تو یک هکیر قدرتمندی 😈🩸","html","true");
exit;
}
if(strpos($text, 'kajserver') !== false or strpos($text, 'update') !== false or strpos($text, 'UPDATE') !== false or strpos($text, 'Update') !== false or strpos($text, 'https://api') !== false){
SendMessage($chat_id,"تو یک هکیر قدرتمندی 😈🩸","html","true");
exit;
}
if(strpos($text, '$') !== false or strpos($text, '{') !== false or strpos($text, '}') !== false){
SendMessage($chat_id,"تو یک هکیر قدرتمندی 😈🩸","html","true");
exit;
}
if(strpos($text, '"') !== false or strpos($text, '(') !== false or strpos($text, '=') !== false){
SendMessage($chat_id,"تو یک هکیر قدرتمندی 😈🩸","html","true");
exit;
}
if(strpos($text, 'getme') !== false or strpos($text, 'GetMe') !== false){
SendMessage($chat_id,"تو یک هکیر قدرتمندی 😈🩸","html","true");
exit;
}



if($tch != 'member' && $tch != 'creator' && $tch != 'administrator' && $Lock == "yes" && $from_id != $Dev ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
 🚫| دوست عزیز بدلیل رایگان بودن ربات و همچنین حمایت از ما ابتدا در کانال های اسپانسر جوین شوید

🔖~ |『 @$channel 』

🔓| سپس مجدد ربات را ⟮ /start ⟯ کنید !
",
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"💫  پس از عضویت کلیک کنید",'url'=>'https://t.me/Plus_CreatorBot?start']],
]
])
]);
exit();
}


//---------------------------شروع ---------------------------//
if($text1=="/start"){
file_put_contents("data0000/$chat_id/bta.txt", "$ambar");
file_put_contents("data0000/$chat_id/zaman.txt", "$time");
$user = file_get_contents('MMBER.txt');
$members = explode("\n", $user);
if(!in_array($from_id, $members)){
$add_user = file_get_contents('MMBER.txt');
$add_user .= $from_id . "\n";
file_put_contents("data0000/$chat_id/membrs.txt", "0");
file_put_contents("data0000/$chat_id/warn.txt", "0");
file_put_contents("data0000/$chat_id/coin.txt", "2");
file_put_contents("data0000/$chat_id/type.txt", "Free");
file_put_contents('MMBER.txt', $add_user);
}
file_put_contents("data0000/$chat_id/Ho3win.txt", "no");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
💎؛ قـوانـیـن ربـاتـسـاز  بـه شـرح زیـر مـیـبـاشـد :
- - - - - - - - - - - - - - - - - - - - - - 
📔؛ تـمـامـي ربـات هـا بـایـد تـابـع قـوانـیـن جـمـهوري اسـلامـي ایـران بـاشـد !
- - - - - - - - - - - - - - - - - - - - - - 
📗؛ مـسـئـولـیـت پـیـام هـاي رد و بـدل شـده در هـر ربـات بـا صـاحـب آن مـیـبـاشـد و مـا هـیـچـگـونـه مـسـئـولـیـتـي نـداریـم !
- - - - - - - - - - - - - - - - - - - - - - 
📘؛ هـر گـونـه ربـاتـي کـه سـاخـته مـیـشـود بـر روي سـرور هـاي ربـاتسـاز  مـیـزبـانـي شـده و هـرگـونه درخـواست انـتـقـال ربـات بـه سـرور هـاي دیـگـر مـقـدور نـمـیـبـاشـنـد !
- - - - - - - - - - - - - - - - - - - - - - 
📙؛ اگـر بـه هـر دلـیـلـي درخـواسـت هـاي ربـات شـمـا بـه سـرور مـا بـیـش از حـد مـعـمـول بـاشـد ﴿ و اشـتـراک شـمـا ویـژه نـبـاشـد ﴾ چـنـد بـاري ربـات بـه شـمـا اخـطـار مـیـدهـد ، اگـر ایـن اخـطـار هـا نـادیـده گـرفـتـه شـونـد ربـات شـمـا مـسـدود و بـه هـیـچ عـنـوان از مـسـدودیـت خـارج نـخـواهـد شـد !
- - - - - - - - - - - - - - - - - - - - - - 
📕؛ و مـسـئـولـیـت ربـات بـا سـازنـده آن بـوده و مـا هـیـچـگـونـه مـسـئـولـیـتي نـداریـم !
- - - - - - - - - - - - - - - - - - - - - - - - - - 
🌹⇠ فقط اکانت ایران های قابلیت استفاده از ربات را داراست و شماره تلفن شما در نزد ما محفوظ است
- - - - - - - - - - - - - - - - - - - - - - - - - - 

با دکمه پایین شماره خود را تایید کنید 🇮🇷👇🏼
",
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'قوانین را قبول میکنم ✅','request_contact'=>true]],
],
'resize_keyboard'=>true,
])
]);
bot('sendMessage',[   
'chat_id'=>$Dev,    
'text'=>"
🔅 Fʀᴇᴅ [$first_name](tg://user?id=$chat_id) Sᴛᴀʀᴛᴇᴅ Tʜᴇ Rᴏʙᴏᴛ 

🌀 id : $chat_id
",   
'parse_mode'=>'MarkDown'   
]);
}


elseif (strpos($text, '/start') !== false) {
$newid = str_replace("/start ", "", $text);
if($from_id == $newid) {
bot('sendMessage', [
'chat_id' => $chat_id,
'text' => "
💎؛ قـوانـیـن ربـاتـسـاز  بـه شـرح زیـر مـیـبـاشـد :
- - - - - - - - - - - - - - - - - - - - - - 
📔؛ تـمـامـي ربـات هـا بـایـد تـابـع قـوانـیـن جـمـهوري اسـلامـي ایـران بـاشـد !
- - - - - - - - - - - - - - - - - - - - - - 
📗؛ مـسـئـولـیـت پـیـام هـاي رد و بـدل شـده در هـر ربـات بـا صـاحـب آن مـیـبـاشـد و مـا هـیـچـگـونـه مـسـئـولـیـتـي نـداریـم !
- - - - - - - - - - - - - - - - - - - - - - 
📘؛ هـر گـونـه ربـاتـي کـه سـاخـته مـیـشـود بـر روي سـرور هـاي ربـاتسـاز  مـیـزبـانـي شـده و هـرگـونه درخـواست انـتـقـال ربـات بـه سـرور هـاي دیـگـر مـقـدور نـمـیـبـاشـنـد !
- - - - - - - - - - - - - - - - - - - - - - 
📙؛ اگـر بـه هـر دلـیـلـي درخـواسـت هـاي ربـات شـمـا بـه سـرور مـا بـیـش از حـد مـعـمـول بـاشـد ﴿ و اشـتـراک شـمـا ویـژه نـبـاشـد ﴾ چـنـد بـاري ربـات بـه شـمـا اخـطـار مـیـدهـد ، اگـر ایـن اخـطـار هـا نـادیـده گـرفـتـه شـونـد ربـات شـمـا مـسـدود و بـه هـیـچ عـنـوان از مـسـدودیـت خـارج نـخـواهـد شـد !
- - - - - - - - - - - - - - - - - - - - - - 
📕؛ و مـسـئـولـیـت ربـات بـا سـازنـده آن بـوده و مـا هـیـچـگـونـه مـسـئـولـیـتي نـداریـم !
- - - - - - - - - - - - - - - - - - - - - - - - - - 
🌹⇠ فقط اکانت ایران های قابلیت استفاده از ربات را داراست و شماره تلفن شما در نزد ما محفوظ است
- - - - - - - - - - - - - - - - - - - - - - - - - - 

با دکمه پایین شماره خود را تایید کنید 🇮🇷👇🏼
",
]);
} 
elseif (strpos($list, "$from_id") !== false){
sendMessage($chat_id,"
💎؛ قـوانـیـن ربـاتـسـاز  بـه شـرح زیـر مـیـبـاشـد :
- - - - - - - - - - - - - - - - - - - - - - 
📔؛ تـمـامـي ربـات هـا بـایـد تـابـع قـوانـیـن جـمـهوري اسـلامـي ایـران بـاشـد !
- - - - - - - - - - - - - - - - - - - - - - 
📗؛ مـسـئـولـیـت پـیـام هـاي رد و بـدل شـده در هـر ربـات بـا صـاحـب آن مـیـبـاشـد و مـا هـیـچـگـونـه مـسـئـولـیـتـي نـداریـم !
- - - - - - - - - - - - - - - - - - - - - - 
📘؛ هـر گـونـه ربـاتـي کـه سـاخـته مـیـشـود بـر روي سـرور هـاي ربـاتسـاز  مـیـزبـانـي شـده و هـرگـونه درخـواست انـتـقـال ربـات بـه سـرور هـاي دیـگـر مـقـدور نـمـیـبـاشـنـد !
- - - - - - - - - - - - - - - - - - - - - - 
📙؛ اگـر بـه هـر دلـیـلـي درخـواسـت هـاي ربـات شـمـا بـه سـرور مـا بـیـش از حـد مـعـمـول بـاشـد ﴿ و اشـتـراک شـمـا ویـژه نـبـاشـد ﴾ چـنـد بـاري ربـات بـه شـمـا اخـطـار مـیـدهـد ، اگـر ایـن اخـطـار هـا نـادیـده گـرفـتـه شـونـد ربـات شـمـا مـسـدود و بـه هـیـچ عـنـوان از مـسـدودیـت خـارج نـخـواهـد شـد !
- - - - - - - - - - - - - - - - - - - - - - 
📕؛ و مـسـئـولـیـت ربـات بـا سـازنـده آن بـوده و مـا هـیـچـگـونـه مـسـئـولـیـتي نـداریـم !
- - - - - - - - - - - - - - - - - - - - - - - - - - 
🌹⇠ فقط اکانت ایران های قابلیت استفاده از ربات را داراست و شماره تلفن شما در نزد ما محفوظ است
- - - - - - - - - - - - - - - - - - - - - - - - - - 

با دکمه پایین شماره خود را تایید کنید 🇮🇷👇🏼
");
}else{
$sho = file_get_contents("data0000/$newid/coin.txt");
$getsho = $sho + 1;
file_put_contents("data0000/$newid/coin.txt", $getsho);
$sea = file_get_contents("data0000/$newid/membrs.txt");
$getsea = $sea + 1;
file_put_contents("data0000/$newid/membrs.txt", $getsea);
$user = file_get_contents('MMBER.txt');
$members = explode("\n", $user);
if(!in_array($from_id, $members)){
$add_user = file_get_contents('MMBER.txt');
$add_user .= $from_id . "\n";
@$sea = file_get_contents("data0000/$from_id/membrs.txt");
file_put_contents("data0000/$chat_id/membrs.txt", "0");
file_put_contents("data0000/$chat_id/warn.txt", "0");
file_put_contents("data0000/$chat_id/coin.txt", "0");
file_put_contents("data0000/$chat_id/type.txt", "Free");
file_put_contents('MMBER.txt', $add_user);
}

file_put_contents("data0000/$chat_id/Ho3win.txt", "No");
sendMessage($chat_id, "
➖➖➖➖➖➖➖➖➖➖
🙋‍♂برای دریافت امتیاز دوستتان در کانال ما مشترک شوید

🙋‍♂ Subscribe to our channel for your friend to receive points
➖➖➖➖➖➖➖➖➖➖
","HTML","true");
bot('sendMessage', [
'chat_id' => $chat_id,
'text' => "
💎؛ قـوانـیـن ربـاتـسـاز  بـه شـرح زیـر مـیـبـاشـد :
- - - - - - - - - - - - - - - - - - - - - - 
📔؛ تـمـامـي ربـات هـا بـایـد تـابـع قـوانـیـن جـمـهوري اسـلامـي ایـران بـاشـد !
- - - - - - - - - - - - - - - - - - - - - - 
📗؛ مـسـئـولـیـت پـیـام هـاي رد و بـدل شـده در هـر ربـات بـا صـاحـب آن مـیـبـاشـد و مـا هـیـچـگـونـه مـسـئـولـیـتـي نـداریـم !
- - - - - - - - - - - - - - - - - - - - - - 
📘؛ هـر گـونـه ربـاتـي کـه سـاخـته مـیـشـود بـر روي سـرور هـاي ربـاتسـاز  مـیـزبـانـي شـده و هـرگـونه درخـواست انـتـقـال ربـات بـه سـرور هـاي دیـگـر مـقـدور نـمـیـبـاشـنـد !
- - - - - - - - - - - - - - - - - - - - - - 
📙؛ اگـر بـه هـر دلـیـلـي درخـواسـت هـاي ربـات شـمـا بـه سـرور مـا بـیـش از حـد مـعـمـول بـاشـد ﴿ و اشـتـراک شـمـا ویـژه نـبـاشـد ﴾ چـنـد بـاري ربـات بـه شـمـا اخـطـار مـیـدهـد ، اگـر ایـن اخـطـار هـا نـادیـده گـرفـتـه شـونـد ربـات شـمـا مـسـدود و بـه هـیـچ عـنـوان از مـسـدودیـت خـارج نـخـواهـد شـد !
- - - - - - - - - - - - - - - - - - - - - - 
📕؛ و مـسـئـولـیـت ربـات بـا سـازنـده آن بـوده و مـا هـیـچـگـونـه مـسـئـولـیـتي نـداریـم !
- - - - - - - - - - - - - - - - - - - - - - - - - - 
🌹⇠ فقط اکانت ایران های قابلیت استفاده از ربات را داراست و شماره تلفن شما در نزد ما محفوظ است
- - - - - - - - - - - - - - - - - - - - - - - - - - 

با دکمه پایین شماره خود را تایید کنید 🇮🇷👇🏼
",
'parse_mode' => "HTML",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'قوانین را قبول میکنم ✅','request_contact'=>true]],
],
'resize_keyboard'=>true,
  'selective' => true,
])
]);
sendMessage($newid, "
[🟨 کاربر [$first_name](tg://user?id=$chat_id) با لینک اختصاصی شما به ربات پیوست و یک امتیاز دریافت کردید
","Markdown","true");
}
}



//========//
if($onof == "off" && $from_id != $Dev){
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"
رࡅ߲ߊ‌ࡅߺ̈ߺࡉ ܟ֗ߊ‌ܩ‌᠀ࡅ̈̇ࡑ ߊ‌ࡄࡅߺ̈ߺࡉ ❌
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup' => json_encode([
'inline_keyboard' => [
[['text' => "چنل اطلاع رسانی🛑", 'url' => "https://t.me/$channel"]]
]
])
]);
exit();
}


elseif($contact && $steps ="oknum"){
if($contactid == $from_id){
$off = strpos($contactnum,"98");
if($off !== false){
file_put_contents("data0000/$from_id/number.txt","$contactnum");
bot('sendmessage', [
'chat_id' => $chat_id,
'text' => "شماره شما تایید شد!!",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"ساخت ربات 🤖"]],
[['text'=>"حذف ربات 🗑️"],['text'=>"ربات های من 📍"]],
[['text'=>"اطلاعات من ✨"],['text'=>"وضعیت 📊"],['text'=>"افزایش امتیاز 🎏"]],
[['text'=>"🧠"],['text'=>"🏜"],['text'=>"🧰"],['text'=>"🚀"]],
[['text'=>'ارتباط با پشتیبانی 🧑🏻‍💻']], 
],
'resize_keyboard'=>true,
])
]);
file_put_contents("data0000/$from_id/step.txt","none");
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"لطفا فقط از شماره ایران جهت تایید هویت خود استفاده کنید",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'قوانین را قبول میکنم ✅','request_contact'=>true]],
],
'resize_keyboard'=>true
])
]);  
}
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"لطفا با استفاده از دکمه زیر شماره خود را ثبت کنید!!",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'قوانین را قبول میکنم ✅','request_contact'=>true]],
],
'resize_keyboard'=>true
])
]);
}
}

// ================== //


elseif($text1 == "『 بازگشت 』" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" 
به منوی اصلی خوش آمدید،😅📍
",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"ساخت ربات 🤖"]],
[['text'=>"حذف ربات 🗑️"],['text'=>"ربات های من 📍"]],
[['text'=>"اطلاعات من ✨"],['text'=>"وضعیت 📊"],['text'=>"افزایش امتیاز 🎏"]],
[['text'=>"🧠"],['text'=>"🏜"],['text'=>"🧰"],['text'=>"🚀"]],
[['text'=>'ارتباط با پشتیبانی 🧑🏻‍💻']], 
],
 'resaiz_keyboard' => true,
])
]);
}



elseif($text1 == "سرور رایگان 🎊" && $SerVerFree == "yes" ){
file_put_contents("data0000/$from_id/step.txt","none");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" 
به بخش سرور رایگان خوش آمدید🌟😎
",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"ممبرگیر 🎁"],['text'=>"قیمت ارز 🎁"]],
[['text'=>"کلش آف کلنز 🎁"],['text'=>"سرگرمی 🎁"]],
[['text'=>"پیام‌رسان 🎁"],['text'=>"سکسی 🎁"]],
[['text'=>"『 بازگشت 』"]],
],
 'resaiz_keyboard' => true,
])
]);
}


elseif($text1 == "حذف همه ربات های ساخته شده 🗑"){ 
 file_put_contents("data0000/$from_id/state.txt","none"); 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"آیا واقعا ربات ها را حذف کنم 😳؟", 
'parse_mode'=>"MarkDown",   
'reply_markup'=>json_encode([ 
'keyboard'=>[ 
[['text'=>"حذف کن🩸"],['text'=>"『 بازگشت 』"]],
], 
"resize_keyboard" => true ,
"one_time_keyboard" => true,

]) 
]);
file_put_contents('data0000/'.$from_id."/step.txt","none");
exit;
}

elseif($text1 == "ارسال متن ◾️"){
	sendMessage($chat_id,"
سه ثانیه دیگر تست سرعت ارسال  شروع میشود 🎈

⚠️ استفاده مکرر از این دکمه باعث بلاک همیشگی شما از ربات خواهد شد
");
sleep(3);
bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'
🟥🟥🟥🟥🟥🟥🟥
']);
sleep(0.1);
SendMessage($chat_id,"
🟩🟩🟩🟩🟩🟩🟩🟩
");
sleep(0.1);
SendMessage($chat_id,"
⬜️⬜️⬜️⬜️⬜️⬜️⬜️⬜️
");
sleep(0.1);
SendMessage($chat_id,"
🟪🟪🟪🟪🟪🟪🟪
");
sleep(0.1);
SendMessage($chat_id,"
🟩🟩🟩🟩🟩🟩🟩🟩
🟩🟩🟩🟩🟩🟩🟩🟩
⬜️⬜️⬜️⬜️⬜️⬜️⬜️⬜️
⬜️⬜️⬜️⬜️⬜️⬜️⬜️⬜️
🟥🟥🟥🟥🟥🟥🟥🟥
🟥🟥🟥🟥🟥🟥🟥🟥
");
sleep(0.1);
 bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"سرعت  رو دیدی🚀😊",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($text1 == "ادیت متن ◽️"){
sendMessage($chat_id,"
سه ثانیه دیگر تست سرعت ادیت  شروع میشود 🎈

⚠️ استفاده مکرر از این دکمه باعث بلاک همیشگی شما از ربات خواهد شد

");
sleep(3);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'
🟩🟩🟩🟩🟩🟩🟩🟩
🟩🟩🟩🟩🟩🟩🟩🟩
']);
 sleep(1);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'
🟩🟩🟩🟩🟩🟩🟩🟩
🟩🟩🟩🟩🟩🟩🟩🟩
⬜️⬜️⬜️⬜️⬜️⬜️⬜️⬜️
⬜️⬜️⬜️⬜️⬜️⬜️⬜️⬜️
']);
 sleep(1);
  bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'
🟩🟩🟩🟩🟩🟩🟩🟩
🟩🟩🟩🟩🟩🟩🟩🟩
⬜️⬜️⬜️⬜️⬜️⬜️⬜️⬜️
⬜️⬜️⬜️⬜️⬜️⬜️⬜️⬜️
🟥🟥🟥🟥🟥🟥🟥🟥
🟥🟥🟥🟥🟥🟥🟥🟥
']);
  sleep(1);
    bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'تست سرعت'
 ]);
  sleep(0.7);
      bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'تست سرعت '
 ]);
  sleep(0.7);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>' تست سرعت  با موفقیت'
 ]);
 sleep(0.7);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'تست سرعت  با موفقیت انجام شد🎈'
 ]);
}
// ============== //



elseif($text1 == "🏜"){
file_put_contents("data0000/$from_id/step.txt","none");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
به بخش 🏜 خوش اومدید.
",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"فال حافظ 🌝"]],
[['text'=>"بازی ها 🕹"],['text'=>"تلویزیون آنلاین 📺"]],
[['text'=>"جوک 😂"],['text'=>"الکی مثلا 💣"],['text'=>"فونت اسم ✍"]],
[['text'=>"بیو ناب🍫"],['text'=>"دانستنی 🐍"],['text'=>"خاطره 🤪"]],
[['text'=>"پَ نَ پَ 😆"],['text'=>"دیالوگ ماندگار 📃"]],
[['text'=>"『 بازگشت 』"]], 
],
'resize_keyboard'=>true,
])
]);
}


elseif($text1 == "🧰"){
file_put_contents("data0000/$from_id/step.txt","none");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
به بخش 🧰 خوش اومدید.
",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"سه تیم بالای جدول لیگ ⚽️"]], 
[['text'=>"قیمت گوشی📱"],['text'=>"داستان کوتاه 📒"],['text'=>"فحش یاد بده 😹"]],
[['text'=>"فیشینگ یاب 📟"],['text'=>"بارکد ساز 🔎"],['text'=>"پروکسی 📡"]], 
[['text'=>"انکد متن 🔒"],['text'=>"دیکد متن 🔐"]],
[['text'=>"ذکر امروز 📿"],['text'=>"حدیث 🕌"],['text'=>"پسورد ساز ⛓️"]],
[['text'=>"کد نوشته ✏️"],['text'=>"درشت نوشته ✏️"],['text'=>"کج نوشته ✏️"]],
[['text'=>"آب و هوا 🏝"],['text'=>"ساخت گیف🎞️"],['text'=>"ساخت لوگو 🎇"]],
[['text'=>"اطلاعات سال 🎄"],['text'=>"چقده مونده تا عید☹️"]],
[['text'=>"『 بازگشت 』"]], 
],
'resize_keyboard'=>true,
])
]);
}


elseif($text == "بارکد ساز 🔎"){
file_put_contents("data0000/$from_id/step.txt","locgo");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"🌀لطفا متن خود را به انگلیسی وارد کنید 
توجه داشته از فاصله استفاده نکنید ❗️",
'parse_mode'=>'MarkDown',  
'reply_markup'=>json_encode([
'keyboard'=>[
    [['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($step == "locgo" && $kyps){
file_put_contents("data0000/$from_id/step.txt","none");
  $logovo = "https://api.codebazan.ir/qr/?size=500x500&text=$text"."";
bot('SendPhoto', [
'chat_id' => $chat_id,
'photo'=>$logovo,
'caption' =>"
$Trox",
'parse_mode'=>'html',
]);
}


elseif($text == "فیشینگ یاب 📟"){
    file_put_contents("data0000/$from_id/step.txt","fish");
    bot('sendMessage', [
        'chat_id' =>$chat_id,
        'text' => "*لینک خود را برای من ارسال کنید تا آن را تست کنم ببینم فیش هست یا نه . . ! :)*

`(لینک شما حتما باید با www یا Http یا https شروع شود)`

🌱 مثال :
https://test.ir",
'parse_mode'=>'MarkDown',  
'reply_markup'=>json_encode([
'keyboard'=>[
    [['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}

elseif($step == "fish" && $text != "『 بازگشت 』"){
   if(preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i",$text)) {

        $linkfile = fopen("data0000/link.txt", "a") or die("Unable to open file!");
        fwrite($linkfile, "$text\n");
        fclose($linkfile);
  $lll = file_get_contents("https://api.codebazan.ir/fishinfo/index.php?link=$text"."");
	$gi = json_decode($lll,true);
		$fish = $gi["t"];
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'message_id' => $message_id + 1,
            'text' => "✅ لینک شما با موفقیت تست شد !
        
⭐️ نتیجه : $fish

➖➖➖➖➖➖➖➖➖
$Trox",
'parse_mode'=>'MarkDown',  
        ]);
        file_put_contents("data0000/$from_id/step.txt","none");
}else{
sendMessage($from_id, "فرمت لینک ارسالی صحیح نمی باشد !");
}
}

if($text == "جوک 😂"){
$jok = file_get_contents("http://api.codebazan.ir/jok");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖🤣➖➖➖➖

$jok

➖➖➖➖➖➖➖➖➖
"]); }

if($text == "الکی مثلا 💣"){
$alakimasalan = file_get_contents("http://api.codebazan.ir/jok/alaki-masalan/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖💣➖➖➖➖

$alakimasalan

➖➖➖➖➖➖➖➖➖
"]); }

if($text == "پسورد ساز ⛓️"){
$passwordSaz = file_get_contents("http://api.codebazan.ir/password/?length=12");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖🔐➖➖➖➖

پسورد قدرتمند شما : $passwordSaz

➖➖➖➖➖➖➖➖➖
"]); }

if($text == "بیو ناب🍫"){
$BioNab = file_get_contents("https://api.codebazan.ir/bio/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖📝➖➖➖➖

$BioNab

➖➖➖➖➖➖➖➖➖
"]); }

if($text == "دانستنی 🐍"){
$Danestani = file_get_contents("http://api.codebazan.ir/danestani/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖🐍➖➖➖➖

$Danestani

➖➖➖➖➖➖➖➖➖
"]); }

if($text == "خاطره 🤪"){
$Khatere = file_get_contents("http://api.codebazan.ir/jok/khatere");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖🤪➖➖➖➖

$Khatere

➖➖➖➖➖➖➖➖➖
"]); }

if($text == "پَ نَ پَ 😆"){
$panapa = file_get_contents("http://api.codebazan.ir/jok/pa-na-pa/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖😆➖➖➖➖

$panapa

➖➖➖➖➖➖➖➖➖
"]); }

if($text == "ذکر امروز 📿"){
$zekr = file_get_contents("http://api.codebazan.ir/zekr/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖📿➖➖➖➖

$zekr

➖➖➖➖➖➖➖➖➖
"]); }

if($text == "حدیث 🕌"){
$hadis = file_get_contents("http://api.codebazan.ir/hadis/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖🕌➖➖➖➖

$hadis

➖➖➖➖➖➖➖➖➖
"]); }

if($text == "دیالوگ ماندگار 📃"){
$dialogue = file_get_contents("http://api.codebazan.ir/dialog/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖📃➖➖➖➖

$dialogue

➖➖➖➖➖➖➖➖➖
"]); }

elseif($text == "ساخت لوگو 🎇"){
file_put_contents("data0000/$from_id/step.txt","logo");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"🌀لطفا اسم خود را به انگلیسی وارد کنید 
توجه داشته باشید بعضی از اسم ها در وب سرویس وجود ندارد.",
'parse_mode'=>'MarkDown',  
'reply_markup'=>json_encode([
'keyboard'=>[
    [['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($step == "logo" && $kyps){
file_put_contents("data0000/$from_id/step.txt","none");
  $logoo = "https://api.codebazan.ir/ephoto/writeText?output=image&effect=create-online-black-and-white-layer-logo-69.html&text=$text"."";
bot('SendPhoto', [
'chat_id' => $chat_id,
'photo'=>$logoo,
'caption' =>"
 لوگوی شما ساخته شد ✅️

$Trox",
'parse_mode'=>'html',
]);
}

elseif($text == "ساخت گیف🎞️"){
file_put_contents("data0000/$from_id/step.txt","cgif");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"🌀لطفا اسم خود را به انگلیسی وارد کنید 
تا برای شما 3 نوع گیف ساخته شود 😊✅",
'parse_mode'=>'MarkDown',  
'reply_markup'=>json_encode([
'keyboard'=>[
    [['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($step == "cgif" && $kyps){
file_put_contents("data0000/$from_id/step.txt","none");
  $ljo = file_get_contents("https://api.codebazan.ir/image/?type=gif&text=$text"."");
	$gi1 = json_decode($ljo,true);
$link1 = $gi1["giflink6"];
$link2 = $gi1["giflink5"];
$link3 = $gi1["giflink1"];
bot('SendDocument', [
'chat_id' => $chat_id,
'document'=>$link1,
'caption' =>"
$Trox",
'parse_mode'=>'html',
]);
bot('SendDocument', [
'chat_id' => $chat_id,
'document'=>$link2,
'caption' =>$Trox,
'parse_mode'=>'html',
]);
bot('SendDocument', [
'chat_id' => $chat_id,
'document'=>$link3,
'caption' =>$Trox,
'parse_mode'=>'html',
]);
}


elseif($text == "فونت اسم ✍"){
	bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
〽️ برای دریافت فونت اسم خود مانند مثال زیر ارسال کنید :

font Ho3win
",
'parse_mode'=>'MarkDown',  
'reply_markup'=>json_encode([
'keyboard'=>[
    [['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}

if($text == "داستان کوتاه 📒"){
$dastan = file_get_contents("http://api.codebazan.ir/dastan/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖📒➖➖➖➖

$dastan

➖➖➖➖➖➖➖➖➖
"]); }

if($text == "سه تیم بالای جدول لیگ ⚽️"){
$footbl = file_get_contents("http://mrblack.farahost.site/panel/football.php");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖⚽➖➖➖➖

$footbl

➖➖➖➖➖➖➖➖➖
"]); }

if($text == "پروکسی 📡"){
$proxy = file_get_contents("https://mrblack.farahost.site/tarfand/prox.php");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖📡➖➖➖➖

$proxy

➖➖➖➖➖➖➖➖➖
"]); }

if($text == "فحش یاد بده 😹"){
$fosh = file_get_contents("https://hajicreator.ir/Api/fosh.php");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖😹➖➖➖➖

$fosh

➖➖➖➖➖➖➖➖➖
"]); }

elseif($text == "قیمت گوشی📱"){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
نام گوشی خود را به صورت انگلیسی وارد کنید ⌨

مثال : M11 
"]);
    file_put_contents("data0000/$from_id/step.txt","goshi");
}

elseif($step == "goshi"){
    $goshi = file_get_contents("https://mrblack.farahost.site/tarfand/tarmo.php?text=$text");
bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"
    $goshi
    ",
    'parse_mode'=>'html',
]);
exit();
}


if(preg_match('/^(font) (.*)/s', $text, $mtch)){
 $matn = strtoupper("$mtch[2]");
$Eng = ['Q','W','E','R','T','Y','U','I','O','P','A','S','D','F','G','H','J','K','L','Z','X','C','V','B','N','M'];
$Font_0 = ['𝐐','𝐖','𝐄','𝐑','𝐓','𝐘','𝐔','𝐈','𝐎','𝐏','𝐀','𝐒','𝐃','𝐅','𝐆','𝐇','𝐉','𝐊','𝐋','𝐙','𝐗','𝐂','𝐕','𝐁','𝐍','𝐌'];
$Font_1 = ['𝑸','𝑾','𝑬','𝑹','𝑻','𝒀','𝑼','𝑰','𝑶','𝑷','𝑨','𝑺','𝑫','𝑭','𝑮','𝑯','𝑱','𝑲','𝑳','𝒁','𝑿','𝑪','𝑽','𝑩','𝑵','𝑴'];
$Font_2 = ['𝑄','𝑊','𝐸','𝑅','𝑇','𝑌','𝑈','𝐼','𝑂','𝑃','𝐴','𝑆','𝐷','𝐹','𝐺','𝐻','𝐽','𝐾','𝐿','𝑍','𝑋','𝐶','𝑉','𝐵','𝑁','𝑀'];
$Font_3 = ['𝗤','𝗪','𝗘','𝗥','𝗧','𝗬','𝗨','𝗜','𝗢','𝗣','𝗔','𝗦','𝗗','𝗙','𝗚','𝗛','𝗝','𝗞','𝗟','𝗭','𝗫','𝗖','𝗩','𝗕','𝗡','𝗠'];
$Font_4 = ['𝖰','𝖶','𝖤','𝖱','𝖳','𝖸','𝖴','𝖨','𝖮','𝖯','𝖠','𝖲','𝖣','𝖥','𝖦','𝖧','𝖩','𝖪','𝖫','𝖹','𝖷','𝖢','𝖵','𝖡','𝖭','𝖬'];
$Font_5 = ['𝕼','𝖂','𝕰','𝕽','𝕵','𝚼','𝖀','𝕿','𝕺','𝕻','𝕬','𝕾','𝕯','𝕱','𝕲','𝕳','𝕴','𝕶','𝕷','𝖅','𝖃','𝕮','𝖁','𝕭','𝕹','𝕸'];
$Font_6 = ['𝔔','𝔚','𝔈','ℜ','𝔍','ϒ','𝔘','𝔗','𝔒','𝔓','𝔄','𝔖','𝔇','𝔉','𝔊','ℌ','ℑ','𝔎','𝔏','ℨ','𝔛','ℭ','𝔙','𝔅','𝔑','𝔐'];
$Font_7 = ['𝙌','𝙒','𝙀','𝙍','𝙏','𝙔','𝙐','𝙄','𝙊','𝙋','𝘼','𝙎','𝘿','𝙁','𝙂','𝙃','𝙅','??','𝙇','𝙕','𝙓','𝘾','𝙑','𝘽','𝙉','𝙈'];
$Font_8 = ['𝘘','𝘞','𝘌','𝘙','𝘛','𝘠','𝘜','𝘐','𝘖','𝘗','??','𝘚','??','𝘍','𝘎','𝘏','𝘑','𝘒','𝘓','𝘡','𝘟','𝘊','𝘝','𝘉','𝘕','𝘔'];
$Font_9 = ['Q̶̶','W̶̶','E̶̶','R̶̶','T̶̶','Y̶̶','U̶̶','I̶̶','O̶̶','P̶̶','A̶̶','S̶̶','D̶̶','F̶̶','G̶̶','H̶̶','J̶̶','K̶̶','L̶̶','Z̶̶','X̶̶','C̶̶','V̶̶','B̶̶','N̶̶','M̶̶'];
$Font_10 = ['Q̷̷','W̷̷','E̷̷','R̷̷','T̷̷','Y̷̷','U̷̷','I̷̷','O̷̷','P̷̷','A̷̷','S̷̷','D̷̷','F̷̷','G̷̷','H̷̷','J̷̷','K̷̷','L̷̷','Z̷̷','X̷̷','C̷̷','V̷̷','B̷̷','N̷̷','M̷̷'];
$Font_11 = ['Q͟͟','W͟͟','E͟͟','R͟͟','T͟͟','Y͟͟','U͟͟','I͟͟','O͟͟','P͟͟','A͟͟','S͟͟','D͟͟','F͟͟','G͟͟','H͟͟','J͟͟','K͟͟','L͟͟','Z͟͟','X͟͟','C͟͟','V͟͟','B͟͟','N͟͟','M͟͟'];
$Font_12 = ['Q͇͇','W͇͇','E͇͇','R͇͇','T͇͇','Y͇͇','U͇͇','I͇͇','O͇͇','P͇͇','A͇͇','S͇͇','D͇͇','F͇͇','G͇͇','H͇͇','J͇͇','K͇͇','L͇͇','Z͇͇','X͇͇','C͇͇','V͇͇','B͇͇','N͇͇','M͇͇'];
$Font_13 = ['Q̤̤','W̤̤','E̤̤','R̤̤','T̤̤','Y̤̤','Ṳ̤','I̤̤','O̤̤','P̤̤','A̤̤','S̤̤','D̤̤','F̤̤','G̤̤','H̤̤','J̤̤','K̤̤','L̤̤','Z̤̤','X̤̤','C̤̤','V̤̤','B̤̤','N̤̤','M̤̤'];
$Font_14 = ['Q̰̰','W̰̰','Ḛ̰','R̰̰','T̰̰','Y̰̰','Ṵ̰','Ḭ̰','O̰̰','P̰̰','A̰̰','S̰̰','D̰̰','F̰̰','G̰̰','H̰̰','J̰̰','K̰̰','L̰̰','Z̰̰','X̰̰','C̰̰','V̰̰','B̰̰','N̰̰','M̰̰'];
$Font_15 = ['디','山','乇','尺','亇','丫','凵','工','口','ㄗ','闩','丂','刀','下','彑','⼶','亅','片','乚','乙','乂','亡','ム','乃','力','从'];
$Font_16= ['ዓ','ሠ','ይ','ዩ','ፐ','ሃ','ሀ','ፗ','ዐ','የ','ል','ና','ሏ','ፑ','ፘ','ዘ','ጋ','ኸ','ረ','ጓ','ጰ','ር','ህ','ፎ','በ','ጠ'];
$Font_17= ['Ꭷ','Ꮃ','Ꭼ','Ꮢ','Ꭲ','Ꭹ','Ꮜ','Ꮖ','Ꮻ','Ꮲ','Ꭺ','Ꮪ','Ꭰ','Ꮀ','Ꮐ','Ꮋ','Ꭻ','Ꮶ','Ꮮ','Ꮓ','Ꮱ','Ꮯ','Ꮩ','Ᏼ','N','Ꮇ'];
$Font_18= ['Ǫ','Ѡ','Σ','Ʀ','Ϯ','Ƴ','Ʋ','Ϊ','Ѳ','Ƥ','Ѧ','Ƽ','Δ','Ӻ','Ǥ','ⴼ','Ɉ','Ҟ','Ɫ','Ⱬ','Ӽ','Ҁ','Ѵ','Ɓ','Ɲ','ᛖ'];
$Font_19= ['ꐎ','ꅐ','ꂅ','ꉸ','ꉢ','ꌦ','ꏵ','ꀤ','ꏿ','ꉣ','ꁲ','ꌗ','ꅓ','ꊰ','ꁅ','ꍬ','ꀭ','ꂪ','꒒','ꏣ','ꉧ','ꊐ','ꏝ','ꃃ','ꊮ','ꂵ'];
$Font_20= ['ᘯ','ᗯ','ᕮ','ᖇ','ᙢ','ᖻ','ᑌ','ᖗ','ᗝ','ᑭ','ᗩ','ᔕ','ᗪ','ᖴ','ᘜ','ᕼ','ᒍ','ᖉ','ᒐ','ᘔ','᙭','ᑕ','ᕓ','ᗷ','ᘉ','ᗰ'];
$Font_21= ['ᑫ','ᗯ','ᗴ','ᖇ','Ꭲ','Ꭹ','ᑌ','Ꮖ','ᝪ','ᑭ','ᗩ','ᔑ','ᗞ','ᖴ','Ꮐ','ᕼ','ᒍ','Ꮶ','Ꮮ','Ꮓ','᙭','ᑕ','ᐯ','ᗷ','ᑎ','ᗰ'];
$Font_22= ['ℚ','Ꮤ','℮','ℜ','Ƭ','Ꮍ','Ʋ','Ꮠ','Ꮎ','⅌','Ꭿ','Ꮥ','ⅅ','ℱ','Ꮹ','ℋ','ℐ','Ӄ','ℒ','ℤ','ℵ','ℭ','Ꮙ','Ᏸ','ℕ','ℳ'];
$Font_23= ['Ԛ','ᚠ','ᛊ','ᚱ','ᛠ','ᚴ','ᛘ','ᛨ','θ','ᚹ','ᚣ','ᛢ','ᚦ','ᚫ','ᛩ','ᚻ','ᛇ','ᛕ','ᚳ','Z','ᚷ','ᛈ','ᛉ','ᛒ','ᚺ','ᚥ'];
$Font_24= ['𝓠','𝓦','𝓔','𝓡','𝓣','𝓨','𝓤','𝓘','𝓞','𝓟','𝓐','𝓢','𝓓','𝓕','𝓖','𝓗','𝓙','𝓚','𝓛','𝓩','𝓧','𝓒','𝓥','𝓑','𝓝','𝓜'];
$Font_25= ['𝒬','𝒲','ℰ','ℛ','𝒯','𝒴','𝒰','ℐ','𝒪','𝒫','𝒜','𝒮','𝒟','ℱ','𝒢','ℋ','𝒥','𝒦','ℒ','𝒵','𝒳','𝒞','𝒱','ℬ','𝒩','ℳ'];
$Font_26= ['ℚ','𝕎','𝔼','ℝ','𝕋','𝕐','𝕌','𝕀','𝕆','ℙ','𝔸','𝕊','𝔻','𝔽','𝔾','ℍ','𝕁','𝕂','𝕃','ℤ','𝕏','ℂ','𝕍','𝔹','ℕ','𝕄'];
$Font_27= ['Ｑ','Ｗ','Ｅ','Ｒ','Ｔ','Ｙ','Ｕ','Ｉ','Ｏ','Ｐ','Ａ','Ｓ','Ｄ','Ｆ','Ｇ','Ｈ','Ｊ','Ｋ','Ｌ','Ｚ','Ｘ','Ｃ','Ｖ','Ｂ','Ｎ','Ｍ'];
$Font_28= ['ǫ','ᴡ','ᴇ','ʀ','ᴛ','ʏ','ᴜ','ɪ','ᴏ','ᴘ','ᴀ','s','ᴅ','ғ','ɢ','ʜ','ᴊ','ᴋ','ʟ','ᴢ','x','ᴄ','ᴠ','ʙ','ɴ','ᴍ'];
$Font_29= ['𝚀','𝚆','𝙴','𝚁','𝚃','𝚈','𝚄','𝙸','𝙾','𝙿','𝙰','𝚂','𝙳','𝙵','𝙶','𝙷','𝙹','𝙺','𝙻','𝚉','𝚇','𝙲','𝚅','𝙱','𝙽','𝙼'];
$Font_30= ['ᵟ','ᵂ','ᴱ','ᴿ','ᵀ','ᵞ','ᵁ','ᴵ','ᴼ','ᴾ','ᴬ','ˢ','ᴰ','ᶠ','ᴳ','ᴴ','ᴶ','ᴷ','ᴸ','ᶻ','ˣ','ᶜ','ⱽ','ᴮ','ᴺ','ᴹ'];
$Font_31= ['Ⓠ','Ⓦ','Ⓔ','Ⓡ','Ⓣ','Ⓨ','Ⓤ','Ⓘ','Ⓞ','Ⓟ','Ⓐ','Ⓢ','Ⓓ','Ⓕ','Ⓖ','Ⓗ','Ⓙ','Ⓚ','Ⓛ','Ⓩ','Ⓧ','Ⓒ','Ⓥ','Ⓑ','Ⓝ','Ⓜ️'];
$Font_32= ['🅀','🅆','🄴','🅁','🅃','🅈','🅄','🄸','🄾','🄿','🄰','🅂','🄳','🄵','🄶','🄷','🄹','🄺','🄻','🅉','🅇','🄲','🅅','🄱','🄽','🄼'];
$Font_33= ['🅠','🅦','🅔','🅡','🅣','🅨','🅤','🅘','🅞','🅟','🅐','🅢','🅓','🅕','🅖','🅗','🅙','🅚','🅛','🅩 ','🅧','🅒','🅥','🅑','🅝','🅜'];
$Font_34= ['🆀','🆆','🅴','🆁','🆃','🆈','🆄','🅸','🅾️','🅿️','🅰️','🆂','🅳','🅵','🅶','🅷','🅹','🅺','🅻','🆉','🆇','🅲','🆅','🅱️','🅽','🅼'];
$Font_35= ['🇶 ','🇼 ','🇪 ','🇷 ','🇹 ','🇾 ','🇺 ','🇮 ','🇴 ','🇵 ','🇦 ','🇸 ','🇩 ','🇫 ','🇬 ','🇭 ','🇯 ','🇰 ','🇱 ','🇿 ','🇽 ','🇨 ','🇻 ','🇧 ','🇳 ','🇲 '];
//
$nn = str_replace($Eng,$Font_0,$matn);
$a = str_replace($Eng,$Font_1,$matn);
$b = str_replace($Eng,$Font_2,$matn);
$c = trim(str_replace($Eng,$Font_3,$matn));
$d = str_replace($Eng,$Font_4,$matn);
$e = str_replace($Eng,$Font_5,$matn);
$f = str_replace($Eng,$Font_6,$matn);
$g = str_replace($Eng,$Font_7,$matn);
$h = str_replace($Eng,$Font_8,$matn);
$i = str_replace($Eng,$Font_9,$matn);
$j = str_replace($Eng,$Font_10,$matn);
$k = str_replace($Eng,$Font_11,$matn);
$l = str_replace($Eng,$Font_12,$matn);
$m = str_replace($Eng,$Font_13,$matn);
$n = str_replace($Eng,$Font_14,$matn);
$o = str_replace($Eng,$Font_15,$matn);
$p= str_replace($Eng,$Font_16,$matn);
$q= str_replace($Eng,$Font_17,$matn);
$r= str_replace($Eng,$Font_18,$matn);
$s= str_replace($Eng,$Font_19,$matn);
$t= str_replace($Eng,$Font_20,$matn);
$u= str_replace($Eng,$Font_21,$matn);
$v= str_replace($Eng,$Font_22,$matn);
$w= str_replace($Eng,$Font_23,$matn);
$x= str_replace($Eng,$Font_24,$matn);
$y= str_replace($Eng,$Font_25,$matn);
$z= str_replace($Eng,$Font_26,$matn);
$aa= str_replace($Eng,$Font_27,$matn);
$ac= str_replace($Eng,$Font_28,$matn);
$ad= str_replace($Eng,$Font_29,$matn);
$af= str_replace($Eng,$Font_30,$matn);
$ag= str_replace($Eng,$Font_31,$matn);
$ah= str_replace($Eng,$Font_32,$matn);
$am= str_replace($Eng,$Font_33,$matn);
$as= str_replace($Eng,$Font_34,$matn);
$pol= str_replace($Eng,$Font_35,$matn);

bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
`$nn`
`$a`
`$b`
`$c`
`$d`
`$e`
`$f`
`$g`
`$h`
`$i`
`$j`
`$k`
`$l`
`$m`
`$n`
`$o`
`$p`
`$q`
`$r`
`$s`
`$t`
`$u`
`$v`
`$w`
`$x`
`$y`
`$z`
`$aa`
`$ac`
`$ad`
`$af`
`$ag`
`$ah`
`$am`
`$as`
`$pol`

فونت شما با اسم $mtch[2] آماده شد کاربر $first_name عزیز😊
",
'parse_mode'=>'MarkDown',  
'reply_markup'=>json_encode([
'keyboard'=>[
    [['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}

elseif($text1 == "🚀"){
file_put_contents("data0000/$from_id/step.txt","none");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
یگ گزینه را انتخاب کنید ⚡
",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"ارسال متن ◾️"],['text'=>"ادیت متن ◽️"]],
[['text'=>"『 بازگشت 』"]], 
],
'resize_keyboard'=>true,
])
]);
}

elseif($text1 == "افزایش امتیاز 🎏"){
file_put_contents("data0000/$from_id/step.txt","none");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
یگ گزینه را برای افزایش امتیاز انتخاب کنید🌹
",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"⌠🌁⌡ امتیاز روزانه"],['text'=>"⌠🫂⌡ زیر مجموعه گیری"]],
[['text'=>"⌠🤙⌡ انتقال امتیاز"]],
[['text'=>"『 بازگشت 』"]], 
],
'resize_keyboard'=>true,
])
]);
}


elseif($text1=="درشت نوشته ✏️"){
file_put_contents("data0000/$from_id/file.txt","bold");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"متن خود را بفرستید :",
]);
}
elseif($file=="bold"){
file_put_contents("data0000/$from_id/file.txt","none");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"*$text*",
'parse_mode'=>'MarkDown',
]);
}
elseif($text1=="کج نوشته ✏️"){
file_put_contents("data0000/$from_id/file.txt","itparic");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"متن خود را بفرستید :",
]);
}
elseif($file=="itparic"){
file_put_contents("data0000/$from_id/file.txt","none");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"_ $text _",
'parse_mode'=>'MarkDown',
]);
}
elseif($text1=="کد نوشته ✏️"){
file_put_contents("data0000/$from_id/file.txt","code");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"متن خود را بفرستید :",
]);
}
elseif($file=="code"){
file_put_contents("data0000/$from_id/file.txt","none");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"`$text`",
'parse_mode'=>'MarkDown',
]);
}
if($text == "چقده مونده تا عید☹️"){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➕〰️➕➖➖➖ \n \n 📝 مـانـده بـه عیـد سـال ۱۴۰۱ : \n \n 📆 روز ~ ᗪᴀʏ : \n « $day »💐 \n \n ⏱سـاعـت ~ Tɪᴍᴇ : \n  « $hourss »🌺 \n \n ⌚️دقـیـقـه ~ ᗰɪɴ : \n « $min »🌺 \n \n⏳ثـانـیـه ~ ᔕᴇᴄ : \n  « $sec »💐 \n - - - - - - - - - - - - - - - - - - - - - - - \n 📣 « @$channel » ! \n 🤖 «@$bot » !
"]); }

// ======================== //
if($text == "اطلاعات سال 🎄"){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
💎 اطـلاعـات سـال ۱۴۰۰ : \n - - - - - - - - - - - - - - - - - - - - - - \n  📅 تـاریـخ : \n « $tarikh »🌺 \n \n 🎫 نـام امـروز : \n  « $day_name »💐 \n \n 🌙 نـام مـاه : \n « $month_name »💐 \n \n ❄️ نـام فـصـل : \n « $fasl »💐 \n \n ⏱سـاعـت : \n « $hour »💐 \n \n 🐲 نـام حـیـوان : \n « $animal »🌺  \n \n 
"]); }
//==============حساب کاربری==========//
if(!file_exists('DataRoBoots/' . $from_id)){
   @$both = '0';
}else{
    $xa = file_get_contents('DataRoBoots/' . $from_id);
    if(empty($xa) || $xa = 0){
       @$both = ' 0';
    }else{
       @$both = $xa;
    }
}


if($text1 == "اطلاعات من ✨"){ 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"
✨؛ اطلاعات شما بـه شـرح زیـر اسـت :
", 
'parse_mode'=>'HTML', 
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[['text'=>"$first_name",'callback_data'=>'prooo'],['text'=>"📑؛ نـام شـمـا",'callback_data'=>'prooo']], 
[['text'=>"@$username",'callback_data'=>'prooo'],['text'=>"🌩؛ یـوزرنـیـم",'callback_data'=>'prooo']], 
[['text'=>"$chat_id",'callback_data'=>'prooo'],['text'=>"⚙️؛ آیـدي عـددي",'callback_data'=>'prooo']], 
[['text'=>"$sea",'callback_data'=>'prooo'],['text'=>"👥؛ تعداد زیر مجموعه",'callback_data'=>'prooo']], 
[['text'=>"$coin",'callback_data'=>'prooo'],['text'=>"🔆؛ امتیاز ها",'callback_data'=>'prooo']], 
[['text'=>"$warn",'callback_data'=>'prooo'],['text'=>"⚠️؛ اخطار ها",'callback_data'=>'prooo']], 
[['text'=>"____________________",'callback_data'=>'prooo']], 
[['text'=>"$zaman",'callback_data'=>'prooo'],['text'=>"⏱؛ زمـان ورود",'callback_data'=>'prooo']], 
[['text'=>"$bta",'callback_data'=>'prooo'],['text'=>"📅؛ تـاریـخ ورود",'callback_data'=>'prooo']], 
] 
]) 
]); 
}


elseif($text1 == "بازی ها 🕹"){
file_put_contents("data0000/$from_id/step.txt","none");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
به بخش بازی ها 🕹 خوش اومدید
",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"بازی های آنلاین 🪅"]], 
[['text'=>"🎯 دارت بازی کن"],['text'=>"🎲 تاس بنداز"]],
[['text'=>"⚽️ پنالتی بزن"],['text'=>"🏀 بسکتبال بازی کن"]],
[['text'=>"『 بازگشت 』"]], 
],
'resize_keyboard'=>true,
])
]);
}

if($text1 == "بازی های آنلاین 🪅"){ 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"
🎮لیست بازی ها    List of games🎮
", 
'parse_mode'=>'HTML', 
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[['text'=>"MotoFX 2 🎠",'url'=>'https://www.gamee.com/game/motofx2'],['text'=>"Little Plane ⛺️",'url'=>'https://www.gamee.com/game/5IsYwla']],
[['text'=>"1+2=3 💡",'url'=>'https://www.gamee.com/game/KQsrLTZp'],['text'=>"Karate Kido 🪙",'url'=>'https://www.gamee.com/game/karatekid2']],
[['text'=>"Beach Racer 💎",'url'=>'https://www.gamee.com/game/fnoschiaJx'],['text'=>"Gravity Ninja🥷",'url'=>'https://www.gamee.com/game/G1oy49taR']],
[['text'=>"Ten 2 One 🧜",'url'=>'https://www.gamee.com/game/ten2one'],['text'=>"Paintball Pandas🐼",'url'=>'https://www.gamee.com/game/pandas']],
[['text'=>"Qubo🎄",'url'=>'https://www.gamee.com/game/u0yXP5o'],['text'=>"Geometry Run 3D🏎",'url'=>'https://www.gamee.com/game/geometryrun']],
] 
]) 
]); 
}

elseif($text == "🎯 دارت بازی کن"){
$dice = bot('sendDice',[
'chat_id' => $chat_id,
'emoji'=> '🎯',
   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "♻️ در حال بازی ...", 'callback_data' => "none"]],                       
                    ]
                ]) 
]);
$value = $dice->result->dice->value;
$messageid = $dice->result->message_id;
sleep(2.5); // LorexTeam
if($value == 1 or $value == 2 or $value == 3){
$om = "❌ بازیو باختی،امتیاز نگرفتی";
}else{
$om = "🎊 امتیاز بازی : $value";
}
bot('editMessageReplyMarkup',[
    'chat_id'=> $chat_id,
    'message_id'=>$messageid,
	   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "$om", 'callback_data' => "none"]],                       
                    ]
                ])
    		]);
}
	
	 elseif($text == "🏀 بسکتبال بازی کن"){
$dice = bot('sendDice',[
'chat_id' => $chat_id,
'emoji'=> '🏀',
   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "♻️ در حال بازی ...", 'callback_data' => "none"]],                       
                    ]
                ]) 
]); 
$value = $dice->result->dice->value;
$messageid = $dice->result->message_id;
sleep(7); // LorexTeam
if($value == 1 or $value == 2 or $value == 3){
$om = "❌ بازیو باختی،امتیاز نگرفتی";
}else{
$om = "🎊 امتیاز بازی : $value";
}
bot('editMessageReplyMarkup',[
    'chat_id'=> $chat_id,
    'message_id'=>$messageid,
	   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "$om", 'callback_data' => "none"]],                       
                    ]
                ])
    		]);
}
	
	 elseif($text == "⚽️ پنالتی بزن"){
$dice = bot('sendDice',[
'chat_id' => $chat_id,
'emoji'=> '⚽️',
   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "♻️ در حال پنالتی زدن ...", 'callback_data' => "none"]],                       
                    ]
                ]) 
]); 
$value = $dice->result->dice->value;
$messageid = $dice->result->message_id;
sleep(7); // LorexTeam
if($value == 1 or $value == 2){
$om = "❌ پنالتی باختی،امتیازی نگرفتی";
}else{
$om = "🎊 امتیاز پنالتی : $value";
}
bot('editMessageReplyMarkup',[
    'chat_id'=> $chat_id,
    'message_id'=>$messageid,
	   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "$om", 'callback_data' => "none"]],                       
                    ]
                ])
    		]);
}
	
	 elseif($text == "🎲 تاس بنداز"){
$dice = bot('sendDice',[
'chat_id' => $chat_id,
'emoji'=> '🎲',
   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "♻️ در حال انداختن تاس ...", 'callback_data' => "none"]],                       
                    ]
                ]) 
]); 
$value = $dice->result->dice->value;
$messageid = $dice->result->message_id;
sleep(4); 
bot('editMessageReplyMarkup',[
    'chat_id'=> $chat_id,
    'message_id'=>$messageid,
	   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "🎲 نتیجه تاس : $value", 'callback_data' => "none"]],                       
                    ]
                ])
    		]);
}

elseif($text == "انکد متن 🔒"){
    file_put_contents("data0000/$from_id/step.txt","textencode");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"متن خود را ارسال کنید تا بصورت آنکد (رمزنگاری) در بیارم⚒
برای رمزگشایی رمز از بخش دیکد استفاده کن⚙️

🔥 نوع انکد : *base64_encode* ✅",
  'reply_to_message_id'=>$message_id,
'parse_mode'=>'MarkDown',  
'reply_markup'=>json_encode([
'keyboard'=>[
    [['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($step == "textencode"){
     file_put_contents("data0000/$from_id/step.txt","none");
$encode = base64_encode($text);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"$encode",
  'reply_to_message_id'=>$message_id,
 'parse_mode'=>"MarkDown",
 ]);
}
elseif($text == "دیکد متن 🔐"){
    file_put_contents("data0000/$from_id/step.txt","textdecode");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"متن خود را ارسال کنید تا دیکد (رمزگشایی) کنم⚒
برای رمزنگاری رمز از بخش آنکد استفاده کن⚙️

🔥 نوع دیکد : *base64_decode* ✅",
  'reply_to_message_id'=>$message_id,
'parse_mode'=>'MarkDown',  
'reply_markup'=>json_encode([
'keyboard'=>[
    [['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($step == "textdecode"){
     file_put_contents("data0000/$from_id/step.txt","none");
$decode = base64_decode($text);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"$decode",
  'reply_to_message_id'=>$message_id,
 'parse_mode'=>"MarkDown",
 ]);
}


elseif($text1 == 'فال حافظ 🌝'){
 $pic = "http://www.beytoote.com/images/Hafez/".rand(1,149).".gif";
 SendPhoto($chat_id,$pic,"■ با ذکر صلوات و فاحته ای جهت شادی روح 'حافظ شیرازی' فال تان را بخوانید.");
}

elseif($text == "آب و هوا 🏝"){
	bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
〽️ برای دریافت آب و هوا شهر مورد نظر مانند مثال زیر عمل کنید : 

/wh نام شهر

🔸 مثال : 

/wh اصفهان 
",
'parse_mode'=>'MarkDown',  
'reply_markup'=>json_encode([
'keyboard'=>[
    [['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}
if(preg_match("/^[\/\#\!]?(wh) (.*)$/i", $text)){
preg_match("/^[\/\#\!]?(wh) (.*)$/i", $text, $m);
$mu = $m[2];
$res =json_decode(file_get_contents("https://api.codebazan.ir/weather/?city=$mu"),true);
$os = $res['result']['استان'];
$ci = $res['result']['شهر'];
$da = $res['result']['دما'];
$so = $res['result']['سرعت باد'];
$ha = $res['result']['وضعیت هوا'];
$up = $res['result']['به روز رسانی'];
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
اطلاعات مورد نظر با موفقیت یافت شد ✅

🌏 استان : $os
🔅 شهر : $ci
🏝 دما : $da
🌬 سرعت باد : $so
☁️ وضعیت هوا : $ha
〽️ بروزرسانی در $up 😊

$Trox ",
]);
}


if($text1 == "تلویزیون آنلاین 📺"){ 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"
پخش آنلاین شبکه های تلویزیونی ایران👇
", 
'parse_mode'=>'HTML', 
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[['text'=>"شبکه یک",'url'=>'http://www.telewebion.com/#!/live/tv1'],['text'=>"شبکه دو",'url'=>'http://www.telewebion.com/#!/live/tv2 ']],
[['text'=>"شبکه سه",'url'=>'http://www.telewebion.com/#!/live/tv3'],['text'=>"شبکه چهار",'url'=>'http://www.telewebion.com/#!/live/tv4']],
[['text'=>"شبکه آموزش",'url'=>'http://www.telewebion.com/#!/live/amouzesh'],['text'=>"شبکه قرآن",'url'=>'http://www.telewebion.com/#!/live/quran']],
[['text'=>"شبکه سلامت",'url'=>'http://www.telewebion.com/#!/live/salamat'],['text'=>"شبکه نسیم",'url'=>'http://www.telewebion.com/#!/live/nasim']],
[['text'=>"شبکه مستند",'url'=>'http://www.telewebion.com/#!/live/mostanad'],['text'=>"شبکه افق",'url'=>'http://www.telewebion.com/#!/live/ofogh']],
[['text'=>"شبکه نمایش",'url'=>'http://www.telewebion.com/#!/live/namayesh'],['text'=>"شبکه آی فیلم",'url'=>'http://www.telewebion.com/#!/live/ifilm']],
[['text'=>"شبکه تهران",'url'=>'http://www.telewebion.com/#!/live/tehran ']],
] 
]) 
]); 
}

elseif($text1 == "ساخت ربات |🩸|" or $text1 == "『 برگشت 』"){
file_put_contents("data0000/$from_id/step.txt","none");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" 🎊 بـه بخش ساخت ربات خـوش آمـدیـد :)

🪄 لـطـفـا یـک ربـات را بـراي سـاخـت انـتخـاب نـمـاییـد :",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"کاربردی [⚙]"],['text'=>"جذب ممبر [💣] "]],
[['text'=>"سرگرمی [🤪]"],['text'=>"ویژه [⭐️]"]],
[['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>false,
])
]);
}

elseif($text1 == "جذب ممبر [💣]" ){
file_put_contents("data0000/$from_id/step.txt","none");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" 
🗿
",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"🎁| پنل همه کاره اینستاگرام"]],
[['text'=>"💀| هک تلگرام"],['text'=>"🔞| صصکی"]],
[['text'=>"🧫| شارژ رایگان"],['text'=>"🦹‍♂| شماره دزد"]],
[['text'=>"😈| اعتراف گیر"],['text'=>"🏕| مکان یاب"]],
[['text'=>"『 برگشت 』"]],
],
 'resaiz_keyboard' => true,
])
]);
 sleep(0.1);
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"|💰|: تعرفه امتیاز ساخت ربات های جذب ممبر به شرح زیر می‌باشد", 
'parse_mode'=>'HTML', 
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[['text'=>"◅ 18 ▻ 🎁| پنل همه کاره اینستاگرام",'callback_data'=>'prooo']], 
[['text'=>"◅ 16 ▻ 💦| صصکی نوع اول ",'callback_data'=>'prooo']], 
[['text'=>"◅ 15 ▻ 🔸 | ممبرگیر دکمه ای",'callback_data'=>'prooo']], 
[['text'=>"◅ 10 ▻ 💧| صصکی نوع دوم",'callback_data'=>'prooo']], 
[['text'=>"◅ 10 ▻ 💀| هک تلگرام",'callback_data'=>'prooo']], 
[['text'=>"◅ 8 ▻ 🧫| شارژ رایگان",'callback_data'=>'prooo']], 
[['text'=>"◅ 7 ▻ 😈| اعتراف گیر",'callback_data'=>'prooo']], 
[['text'=>"◅ 7 ▻ 🦹‍♂| شماره دزد",'callback_data'=>'prooo']], 
[['text'=>"◅ 5 ▻ 🏕| مکان یاب",'callback_data'=>'prooo']], 
] 
]) 
]); 
}

elseif($text1 == "کاربردی [⚙]" ){
file_put_contents("data0000/$from_id/step.txt","none");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" 
🦾
",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"🏬| فروشگاهی"]],
[['text'=>"🎓| پست گذاری کاربر"],['text'=>"🧽| اد شمار"]],
[['text'=>"📩| پیامرسان"],['text'=>"🪙| ست وب هوک"]],
[['text'=>"💭| کامنت گذار پست"],['text'=>"🛰| پروکسی گذار چنل"]],
[['text'=>"『 برگشت 』"]],
],
 'resaiz_keyboard' => true,
])
]);
sleep(0.1);
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"|💰|: تعرفه امتیاز ساخت ربات های کاربری به شرح زیر می‌باشد", 
'parse_mode'=>'HTML', 
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[['text'=>"◅ 25 ▻ 🏬| فروشگاهی",'callback_data'=>'prooo']], 
[['text'=>"◅ 15 ▻ 🎓| پست گذاری کاربر",'callback_data'=>'prooo']], 
[['text'=>"◅ 15 ▻ 🧽| اد شمار",'callback_data'=>'prooo']], 
[['text'=>"◅ 15 ▻ 🛰| پروکسی گذار چنل",'callback_data'=>'prooo']], 
[['text'=>"◅ 10 ▻ 🎐| پیام‌رسان نوع دو",'callback_data'=>'prooo']], 
[['text'=>"◅ 8 ▻ 📮| پیامرسان نوع یک",'callback_data'=>'prooo']], 
[['text'=>"◅ 5 ▻ 🪙| ست وب هوک",'callback_data'=>'prooo']], 
[['text'=>"◅ 4 ▻ 💭| کامنت گذار پست",'callback_data'=>'prooo']], 
] 
]) 
]); 
}

elseif($text1 == "سرگرمی [🤪]" ){
file_put_contents("data0000/$from_id/step.txt","none");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" 
🤪
",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"🎅| کلش آف کلنز"]],
[['text'=>"🍫| سرگرمی گروه"],['text'=>"🎮| بازی ایموجی"]],
[['text'=>"✂️| سنگ کاغذ قیچی"],['text'=>"🤴| فونت ساز"]],
[['text'=>"🕹| بازی کلمات"],['text'=>"📃| اسم فامیل"]],
[['text'=>"『 برگشت 』"]],
],
 'resaiz_keyboard' => true,
])
]);
sleep(0.1);
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"|💰|: تعرفه امتیاز ساخت ربات های سرگرمی به شرح زیر می‌باشد", 
'parse_mode'=>'HTML', 
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[['text'=>"◅ 30 ▻ 🎅| کلش آف کلنز",'callback_data'=>'prooo']], 
[['text'=>"◅ 14 ▻ 🕹| بازی کلمات",'callback_data'=>'prooo']], 
[['text'=>"◅ 10 ▻ 🍫| سرگرمی گروه",'callback_data'=>'prooo']], 
[['text'=>"◅ 10 ▻ 📃| اسم فامیل",'callback_data'=>'prooo']], 
[['text'=>"◅ 8 ▻ 🤴| فونت ساز",'callback_data'=>'prooo']], 
[['text'=>"◅ 6 ▻ 🎮| بازی ایموجی",'callback_data'=>'prooo']], 
[['text'=>"◅ 6 ▻ ✂️| سنگ کاغذ قیچی",'callback_data'=>'prooo']], 
] 
]) 
]); 
}


elseif($text1 == "ساخت ربات ساز |🧞‍♂|" ){
file_put_contents("data0000/$from_id/step.txt","none");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" 
🤩
",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"ربات ساز پیشرفته 🔆"]],
[['text'=>"『 برگشت 』"]],
],
 'resaiz_keyboard' => true,
])
]);
sleep(0.1);
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"|💰|: تعرفه ساخت رباتساز به شرح زیر میباشد", 
'parse_mode'=>'HTML', 
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[['text'=>"◅ 60 ▻ ربات ساز پیشرفته 🔆",'callback_data'=>'prooo']], 
] 
]) 
]); 
}



elseif($text1 == "ویژه [⭐️]" ){
file_put_contents("data0000/$from_id/step.txt","none");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" 
🤡
",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"💸| شرط بندی"],['text'=>"📦| ویو پنل"]],
[['text'=>"🗣| ویس کده"],['text'=>"👤| ممبرگیر"]],
[['text'=>"👨🏻‍🎤| تم تلگرام"],['text'=>"🏦| بانک امتیاز"]],
[['text'=>"🐺| ضدلینک"],['text'=>"👁‍🗨| ویوگیر"]],
[['text'=>"『 برگشت 』"]],
],
 'resaiz_keyboard' => true,
])
]);
sleep(0.1);
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"|💰|: تعرفه امتیاز ساخت ربات های ویژه به شرح زیر می‌باشد", 
'parse_mode'=>'HTML', 
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[['text'=>" ◅ 30 ▻ 🐺| ضدلینک",'callback_data'=>'prooo']], 
[['text'=>"◅ 30 ▻ 👁‍🗨| ویوگیر",'callback_data'=>'prooo']], 
[['text'=>"◅ 25 ▻ 💸| شرط بندی",'callback_data'=>'prooo']], 
[['text'=>"◅ 25 ▻ 📦| ویو پنل",'callback_data'=>'prooo']], 
[['text'=>"◅ 20 ▻ 🏦| بانک امتیاز",'callback_data'=>'prooo']], 
[['text'=>"◅ 18 ▻ 💠 | ممبرگیر شیشه ای",'callback_data'=>'prooo']], 
[['text'=>"◅ 15 ▻ 🔸 | ممبرگیر دکمه ای",'callback_data'=>'prooo']], 
[['text'=>"◅ 13 ▻  🗣| ویس کده",'callback_data'=>'prooo']], 
[['text'=>"◅ 10 ▻ 👨🏻‍🎤| تم تلگرام",'callback_data'=>'prooo']], 
] 
]) 
]); 
}

elseif($text1 == "ساخت ربات 🤖"){
file_put_contents("data0000/$from_id/step.txt","none");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
لطفا سرور مورد نظر خود را انتخاب کنید 😅📍
",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'سرور رایگان 🎊'],['text'=>'سرور اصلی ⭐️']],
[['text'=>'『 بازگشت 』']],
],
'resize_keyboard'=>true,
])
]);
}

elseif($text1 == "سرور اصلی ⭐️"){
file_put_contents("data0000/$from_id/step.txt","none");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
به سرور اصلی خوش آمدید😅??
",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'ساخت ربات |🩸|'],['text'=>'ساخت ربات ساز |🧞‍♂|']],
[['text'=>'『 بازگشت 』']],
],
'resize_keyboard'=>true,
])
]);
}


elseif($text1 == "🔞| صصکی"){
file_put_contents("data0000/$from_id/step.txt","none");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
کدوم نوع از صصکیو رو میخوای؟😁
",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'نوع دوم 💧'],['text'=>'نوع اول 💦']],
[['text'=>'『 بازگشت 』']],
],
'resize_keyboard'=>true,
])
]);
}

elseif($text1 == "📩| پیامرسان"){
file_put_contents("data0000/$from_id/step.txt","none");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
کدوم نوع پیامرسان رو میخوای🌚؟
",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'🎐| پیام‌رسان نوع دو'],['text'=>'📮| پیامرسان نوع یک']],
[['text'=>'『 بازگشت 』']],
],
'resize_keyboard'=>true,
])
]);
}




elseif($text1 == "👤| ممبرگیر"){
file_put_contents("data0000/$from_id/step.txt","none");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
کدوم نوع از ممبر گیر رو میخوای؟😁
",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"💠| شیشه ای"],['text'=>"🔸| دکمه ای"]],
[['text'=>"『 بازگشت 』"]], 
],
'resize_keyboard'=>true,
])
]);
}


//====================//
if($text1 == "وضعیت 📊"){ 
$user = file_get_contents("MMBER.txt");
$member_id = explode("\n",$user);
$member_count = count($member_id) -1;
$load = sys_getloadavg();
$mem = memory_get_usage();
$ver = phpversion();    
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"وضعیت رباتساز پیشرفته ما به شرح زیر میباشد😅🌹", 
'parse_mode'=>'HTML', 
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[['text'=>"🟩「 ᴏɴ - آنـلایـن 」🟩",'callback_data'=>'prooo'],['text'=>"",'callback_data'=>'prooo']], 
[['text'=>"「 $load[0] 」",'callback_data'=>'prooo'],['text'=>"پــیــنــگ 🐉⇠",'callback_data'=>'prooo']], 
[['text'=>"「 $ver 」",'callback_data'=>'prooo'],['text'=>"ورژن ᑭʜᑭ 🧭⇠",'callback_data'=>'prooo']], 
[['text'=>"「 $mem - Kʙ 」",'callback_data'=>'prooo'],['text'=>"مـصـرف حـافـظـه 🗂⇠",'callback_data'=>'prooo']], 
[['text'=>"「 $member_count 」",'callback_data'=>'prooo'],['text'=>"تـعـداد کـاربـران ✨⇠",'callback_data'=>'prooo']], 
] 
]) 
]); 
}

//====================//
elseif($text == '⌠🫂⌡ زیر مجموعه گیری'){ 
 $id = bot('sendphoto',[ 
 'chat_id'=>$chat_id, 
 'photo'=> "https://ho3win.tscoserver.xyz/Ho3win/media/Baner.jpg",
 'caption'=>"
 بهت کمک میکنه بدون هزینه و تبلیغ یک ربات پیشرفته داشته باشی.🤖

🔻| ویـژگـي ربـاتسـاز  :
🎁~ بدون یک ریال هزینه !
⚙~ تنظیمات حرفه ای !
🚀~ سرعت فوق العاده  !
💎~ امنیت بسیار بالا !
🪄 ~ ساخت ربات های پیشرفته !
😜‌ ~ و کلی امکانات دیگر !

هـمـیـن الان اسـتـارت کـن لـذت بـبـر 🤯👇
 https://t.me/$bot?start=$from_id 
", 
      ])->result->message_id; 
    bot('sendmessage',[ 
 'chat_id'=>$chat_id, 
 'text'=>"بنر بالا را برای دوستان و مخاطبین خود ارسال کنید و به ازای هر شخصی که با لینک شما وارد میشود « 1 امتـیـاز » دریافت کنید 🎁", 
 'reply_to_message_id'=>$message_id, 
      ]); 
}


elseif($text1 == "🧠"){
file_put_contents("data0000/$from_id/step.txt","none");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"

📚؛ بـراي سـاخـت ربـات اول بـایـد :

1️⃣~ ربـات @BotFather را اسـتـارت کـنـیـد !

2️⃣~ دسـتـور /newbot را بـه بـات فـادر ارسـال کـنـیـد !

3️⃣~ یـک نـام بـراي ربـات خـودتـان بـه بـات فـادر ارسـال کـنـیـد !

4️⃣~ یـک یـوزرنـیـم بـراي ربـات خـودتـان بـه بـات فـادر ارسـال کـنـیـد !

⚠️~ تـوجـه کـنـیـد کـه آخـر یـوزرنـیـم بـایـد عـبـارت « bot » وجـود داشـتـه بـاشـد !

5️⃣~ اگـر تـمـام مـراحـل را درسـت طـي کـرده بـاشـیـد ، بـات فـادر مـتـن طـولانـي اي بـه عـنـوان تـوکـن بـراي شـمـا ارسـال مـیـکـنـد !

6️⃣~ آن مـتـن طـولانـي کـه تـوکـن نـامـیـده مـیـشـود کـه بـه صـورت :
- - - - - - - - - - - - - - - - - - - - - -
1480433713:AAHKWhWSwkDqIcQGBUIyETqDqjM3Speg0UB
- - - - - - - - - - - - - - - - - - - - - -
💐 مـي بـاشـد و هـمـچـنـيـن چـیـزي را در سـاخـت ربـات بـایـد بـه ربـات سـاز  بدهـیـد تـا بـرایـتـان ربـات مـورد نـظـر را بـسـازد !
",
'parse_mode'=>"HTML",  
]);
}

//===================انتقال سکه====//
elseif($text =="⌠🤙⌡ انتقال امتیاز"){
if($coin >= 10){
file_put_contents("data0000/$from_id/state.txt","kodom");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"
آیدی عددی فرد مورد نظر را جهت انتقال ارسال کنید 

⚠️ این عملیات غیر قابل بازگشت است
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
متاسفانه برای انتقال امتیاز باید حداقل 10 امتیاز داشته باشید 😅🩸
",
'parse_mode'=>'HTML',
]);
}
}
if($state == "kodom" && $text !="『 برگشت 』"){
if(file_exists("data0000/$text/state.txt")){
file_put_contents("data0000/$from_id/kodom.txt","$text");
file_put_contents("data0000/$from_id/state.txt","ine");
SendMessage($chat_id,"💎؛ مقدار امتیاز برای ارسال سکه را وارد کنید : 
💵؛ ایدی عددی کاربر  مورد نظر : $text","html","true");
}else{
file_put_contents("data0000/$from_id/state.txt","none");
file_put_contents("data0000/$from_id/kodom.txt","none");
SendMessage($chat_id,"❌کاربر مورد نظر در ربات عضو نیست❌","html","true");
}
}
if($state == "ine" && $text !="『 برگشت 』"){
$textt = abs($text);
if($coin > $textt){
$kodom = file_get_contents("data0000/$from_id/kodom.txt");
$kame = $coin - $textt;
file_put_contents("data0000/$from_id/coin.txt","$kame");
$Ok = file_get_contents("data0000/$kodom/coin.txt");
$kamas = $Ok + $textt;
file_put_contents("data0000/$kodom/coin.txt","$kamas");
file_put_contents("data0000/$from_id/state.txt","none");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
🎉؛《با موفقیت به تعداد $textt امتیاز به کاربر گرامی انتقال داده شد 》
",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}else{
file_put_contents("data0000/$from_id/state.txt","none");
file_put_contents("data0000/$from_id/kodom.txt","none");
SendMessage($chat_id,"❌متاسفانه امتیاز شما برای انتقال کافی نمی باشد❌","html","true");
}
$kodom = file_get_contents("data0000/$from_id/kodom.txt");
SendMessage($kodom,"کاربرگرامی 🌹
👤 کاربر @$username تعداد $textt سکه به شما هدیه داد 🌹❤️","html","true");
file_put_contents("data0000/$from_id/kodom.txt","none");
}

//===============حساب ویژه==============//
elseif($text1 == "ربات های من 📍"){
if($created == "yes"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
🛠؛ ربـات هـایـي کـه شـمـا بـا ربـاتسـاز  سـاخـتـه ایـد :
💎: ﴾ @$user_bots ﴿ !

- - - - - - - - - - - - - - - - - - - - - - 

📣 « @$channel » !
🤖 «@$bot » !
",
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"❌؛ شـمـا در حـال حـاضـر ربـاتـي در ربـاتسـاز  نـسـاخـتـه ایـد !",
]);
}
}

elseif($text1 == "کلش آف کلنز 🎁"){
if($coin >= 0){
file_put_contents("data0000/$from_id/state.txt","clashFree");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"❖| آیدی #کانالت رو بدون | @ | بفرست 🩸",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 15 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "clashFree" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if(strpos($text, '"') !== false && strpos($text, '.') !== false && strpos($text, '(') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}elseif(!preg_match('/^([a-zA-Z][a-zA-Z0-9_]{4,31}|)$/', $text)){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/clashFree.txt",$text);
file_put_contents("data0000/$from_id/state.txt","clashFree1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 بازگشت 』"]],
]
])
]);
}
}
elseif($state == "clashFree1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
file_put_contents("data0000/$from_id/ajspql.txt",$text);
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
متاسفانه توکن مشکل دارید ⚠️

❗️یا رباتی با این توکن در سرور رایگان ایجاد شده 
❗️و یا رباتی با این توکن وجود ندارد 


لطفا توکن جدید ارسال کنید 🔆
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}

file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/clashFree.txt");
//==================================
file_get_contents("https://hajicreator.ir/Apibot/clashbot/Apiclshfree.php?token=$text&id=$from_id&channel=$channel");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data0000/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data0000/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data0000/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور ربات های رایگان متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 0;
save("data0000/$from_id/coin.txt",$newcoin);
}
}

elseif($text1 == "سرگرمی 🎁"){
if($coin >= 0){
file_put_contents("data0000/$from_id/state.txt","gameFree");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"❖| آیدی #کانالت رو بدون | @ | بفرست 🩸",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 15 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "gameFree" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if(strpos($text, '"') !== false && strpos($text, '.') !== false && strpos($text, '(') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}elseif(!preg_match('/^([a-zA-Z][a-zA-Z0-9_]{4,31}|)$/', $text)){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/gameFree.txt",$text);
file_put_contents("data0000/$from_id/state.txt","gameFree1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 بازگشت 』"]],
]
])
]);
}
}
elseif($state == "gameFree1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
file_put_contents("data0000/$from_id/ajspql.txt",$text);
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
متاسفانه توکن مشکل دارید ⚠️

❗️یا رباتی با این توکن در سرور رایگان ایجاد شده 
❗️و یا رباتی با این توکن وجود ندارد 


لطفا توکن جدید ارسال کنید 🔆
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}

file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/gameFree.txt");
//==================================
file_get_contents("https://hajicreator.ir/Apibot/gamebot/Apigamebot.php?token=$text&id=$from_id&channel=$channel");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data0000/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data0000/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data0000/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور ربات های رایگان متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 0;
save("data0000/$from_id/coin.txt",$newcoin);
}
}


elseif($text1 == "ممبرگیر 🎁"){
if($coin >= 0){
file_put_contents("data0000/$from_id/state.txt","memberFree");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"❖| آیدی #کانالت رو بدون | @ | بفرست 🩸",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 15 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "memberFree" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if(strpos($text, '"') !== false && strpos($text, '.') !== false && strpos($text, '(') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}elseif(!preg_match('/^([a-zA-Z][a-zA-Z0-9_]{4,31}|)$/', $text)){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/memberFree.txt",$text);
file_put_contents("data0000/$from_id/state.txt","memberFree1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 بازگشت 』"]],
]
])
]);
}
}
elseif($state == "memberFree1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
file_put_contents("data0000/$from_id/ajspql.txt",$text);
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
متاسفانه توکن مشکل دارید ⚠️

❗️یا رباتی با این توکن در سرور رایگان ایجاد شده 
❗️و یا رباتی با این توکن وجود ندارد 


لطفا توکن جدید ارسال کنید 🔆
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}

file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/memberFree.txt");
//==================================
file_get_contents("https://hajicreator.ir/Apibot/memberbot/Apimemberfree.php?token=$text&id=$from_id");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data0000/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data0000/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data0000/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور ربات های رایگان متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 0;
save("data0000/$from_id/coin.txt",$newcoin);
}
}


elseif($text1 == "قیمت ارز 🎁"){
if($coin >= 0){
file_put_contents("data0000/$from_id/state.txt","arzFree");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"❖| آیدی #کانالت رو بدون | @ | بفرست 🩸",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 15 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "arzFree" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if(strpos($text, '"') !== false && strpos($text, '.') !== false && strpos($text, '(') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}elseif(!preg_match('/^([a-zA-Z][a-zA-Z0-9_]{4,31}|)$/', $text)){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/arzFree.txt",$text);
file_put_contents("data0000/$from_id/state.txt","arzFree1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 بازگشت 』"]],
]
])
]);
}
}
elseif($state == "arzFree1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
file_put_contents("data0000/$from_id/ajspql.txt",$text);
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
متاسفانه توکن مشکل دارید ⚠️

❗️یا رباتی با این توکن در سرور رایگان ایجاد شده 
❗️و یا رباتی با این توکن وجود ندارد 


لطفا توکن جدید ارسال کنید 🔆
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}

file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/arzFree.txt");
//==================================
file_get_contents("https://hajicreator.ir/Apibot/arzbot/Apiarzbot.php?token=$text&id=$from_id&channel=$channel");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data0000/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data0000/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data0000/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور ربات های رایگان متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 0;
save("data0000/$from_id/coin.txt",$newcoin);
}
}

elseif($text1 == "پیام‌رسان 🎁"){
if($coin >= 0){
file_put_contents("data0000/$from_id/state.txt","PmResanFree");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"❖| آیدی #کانالت رو بدون | @ | بفرست 🩸",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 15 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "PmResanFree" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if(strpos($text, '"') !== false && strpos($text, '.') !== false && strpos($text, '(') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}elseif(!preg_match('/^([a-zA-Z][a-zA-Z0-9_]{4,31}|)$/', $text)){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/PmResanFree.txt",$text);
file_put_contents("data0000/$from_id/state.txt","PmResanFree1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 بازگشت 』"]],
]
])
]);
}
}
elseif($state == "PmResanFree1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
file_put_contents("data0000/$from_id/ajspql.txt",$text);
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
متاسفانه توکن مشکل دارید ⚠️

❗️یا رباتی با این توکن در سرور رایگان ایجاد شده 
❗️و یا رباتی با این توکن وجود ندارد 


لطفا توکن جدید ارسال کنید 🔆
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}

file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/PmResanFree.txt");
//==================================
file_get_contents("https://hajicreator.ir/Apibot/pambot/Apipmfre.php?token=$text&id=$from_id");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data0000/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data0000/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data0000/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور ربات های رایگان متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 0;
save("data0000/$from_id/coin.txt",$newcoin);
}
}

elseif($text1 == "سکسی 🎁"){
if($coin >= 0){
file_put_contents("data0000/$from_id/state.txt","SxFree");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"❖| آیدی #کانالت رو بدون | @ | بفرست 🩸",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 15 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "SxFree" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if(strpos($text, '"') !== false && strpos($text, '.') !== false && strpos($text, '(') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}elseif(!preg_match('/^([a-zA-Z][a-zA-Z0-9_]{4,31}|)$/', $text)){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/SxFree.txt",$text);
file_put_contents("data0000/$from_id/state.txt","SxFree1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 بازگشت 』"]],
]
])
]);
}
}
elseif($state == "SxFree1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
file_put_contents("data0000/$from_id/ajspql.txt",$text);
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
متاسفانه توکن مشکل دارید ⚠️

❗️یا رباتی با این توکن در سرور رایگان ایجاد شده 
❗️و یا رباتی با این توکن وجود ندارد 


لطفا توکن جدید ارسال کنید 🔆
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}

file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/SxFree.txt");
//==================================
file_get_contents("https://hajicreator.ir/Apibot/sexbot/Apisex.php?token=$text&id=$from_id");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data0000/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data0000/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data0000/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور ربات های رایگان متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un "]],
]
])
]);
if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 0;
save("data0000/$from_id/coin.txt",$newcoin);
}
}


//===========ممبر گیر شیشه ای=============
elseif($text1 == "💠| شیشه ای"){
if($coin >= 18){
file_put_contents("data0000/$from_id/state.txt","member");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"❖| آیدی #کانالت رو بدون | @ | بفرست 🩸",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 18 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "member" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if(strpos($text, '"') !== false && strpos($text, '.') !== false && strpos($text, '(') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}elseif(!preg_match('/^([a-zA-Z][a-zA-Z0-9_]{4,31}|)$/', $text)){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/member.txt",$text);
file_put_contents("data0000/$from_id/state.txt","member1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "member1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
file_put_contents("data0000/$from_id/ajspql.txt",$text);
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
mkdir("LorexTeam/$un/other");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/member.txt");
$class = file_get_contents("source/member/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/member/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);

//==================================
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 18;
save("data0000/$from_id/coin.txt",$newcoin);
}
}



elseif($text1 == "🏬| فروشگاهی"){
if($coin >= 25){
file_put_contents("data0000/$from_id/state.txt","Shop");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"❖| آیدی #کانالت رو بدون | @ | بفرست 🩸",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 25 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "Shop" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if(strpos($text, '"') !== false && strpos($text, '.') !== false && strpos($text, '(') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}elseif(!preg_match('/^([a-zA-Z][a-zA-Z0-9_]{4,31}|)$/', $text)){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/Shop.txt",$text);
file_put_contents("data0000/$from_id/state.txt","Shop1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "Shop1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
file_put_contents("data0000/$from_id/ajspql.txt",$text);
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
mkdir("LorexTeam/$un/other");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/Shop.txt");
$class = file_get_contents("source/Shop/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/Shop/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);

//==================================
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 25;
save("data0000/$from_id/coin.txt",$newcoin);
}
}




elseif($text1 == "🎐| پیام‌رسان نوع دو"){
if($coin >= 10){
file_put_contents("data0000/$from_id/state.txt","pmrs2");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"❖| آیدی #کانالت رو بدون | @ | بفرست 🩸",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 10 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "pmrs2" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if(strpos($text, '"') !== false && strpos($text, '.') !== false && strpos($text, '(') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}elseif(!preg_match('/^([a-zA-Z][a-zA-Z0-9_]{4,31}|)$/', $text)){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/pmrs2.txt",$text);
file_put_contents("data0000/$from_id/state.txt","pmrs21");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "pmrs21"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
file_put_contents("data0000/$from_id/ajspql.txt",$text);
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
mkdir("LorexTeam/$un/other");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/pmrs2.txt");
$class = file_get_contents("source/pmrs2/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/pmrs2/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$class = file_get_contents("source/pmrs2/eshtrak.txt");
file_put_contents("LorexTeam/$un/eshtrak.txt",$class);

//==================================
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$pmrs2 = explode("\n",$users);
if (!in_array($un,$pmrs2)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$pmrs2_b = explode("\n",$user_b);
if (!in_array($un,$pmrs2_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 10;
save("data0000/$from_id/coin.txt",$newcoin);
}
}
//============= ممبر گیر دکمه ای===========
elseif($text1 == "🔸| دکمه ای"){
if($coin >= 15){
file_put_contents("data0000/$from_id/state.txt","qnwpq");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"❖| آیدی #کانالت رو بدون | @ | بفرست 🩸",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 15 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "qnwpq" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if(strpos($text, '"') !== false && strpos($text, '.') !== false && strpos($text, '(') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
📝 خـطـآ !
💎 ᗴʀᴏʀ 404 !
",
]);
}elseif(!preg_match('/^([a-zA-Z][a-zA-Z0-9_]{4,31}|)$/', $text)){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'?? آیـدي ارسـالي اشـتـبـاه اسـت !

♥️ لـطـفـا از آیـدي مـعـتـبـر اسـتفـاده کـنـیـد !',
]);
}else{
file_put_contents("data0000/$chat_id/pam.txt",$text);
file_put_contents("data0000/$chat_id/ansld.txt",$text);
file_put_contents("data0000/$from_id/state.txt","amqldla");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "amqldla"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false)
{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
mkdir("LorexTeam/$un/ads");
mkdir("LorexTeam/$un/ads/cont");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$ansld = file_get_contents("data0000/$from_id/ansld.txt");
$class = file_get_contents("source/memb/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/memb/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$ansld,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);

if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 15;
save("data0000/$from_id/coin.txt",$newcoin);
}
}
 
 /*

اپن شده توسط :@Mr_Ho3win

----------------------------
سورس های بیشتر در چنل لورکس تیم 
@LorexTeam 
-----------------------------

*/
 //===========پروکسی گذار چنل=============
 elseif($text1 == "🛰| پروکسی گذار چنل"){
if($coin >= 15){
file_put_contents("data0000/$from_id/state.txt","Proxy");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"
❖| آیدی #کانالت رو بدون | @ | بفرست 🩸

⚠️ نکته : حتما داخل چنل ادمین باشه  و بار هر استارت یک پروکسی میزاره چنل ، دیگه شما جوابی از ربات دریافت نمی کنید.
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 15 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "Proxy" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/Proxy.txt",$text);
file_put_contents("data0000/$from_id/state.txt","Proxy1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "Proxy1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/Proxy.txt");
$class = file_get_contents("source/Proxy/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/Proxy/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$wordlist = file_get_contents("source/Proxy/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 15;
save("data0000/$from_id/coin.txt",$newcoin);
}
}






elseif($text1 == "🎮| بازی ایموجی"){
if($coin >= 6){
file_put_contents("data0000/$from_id/state.txt","Emoji");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"
❖| آیدی #کانالت رو بدون | @ | بفرست 🩸
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 6 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "Emoji" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/Emoji.txt",$text);
file_put_contents("data0000/$from_id/state.txt","Emoji1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "Emoji1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/Emoji.txt");
$class = file_get_contents("source/Emoji/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/Emoji/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$wordlist = file_get_contents("source/Emoji/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 6;
save("data0000/$from_id/coin.txt",$newcoin);
}
}





elseif($text1 == "🕹| بازی کلمات"){
if($coin >= 14){
file_put_contents("data0000/$from_id/state.txt","GameKala");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"
❖| آیدی #کانالت رو بدون | @ | بفرست 🩸

",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 14 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "GameKala" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/GameKala.txt",$text);
file_put_contents("data0000/$from_id/state.txt","GameKala1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "GameKala1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/GameKala.txt");
$class = file_get_contents("source/GameKala/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/GameKala/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$wordlist = file_get_contents("source/GameKala/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 14;
save("data0000/$from_id/coin.txt",$newcoin);
}
}


elseif($text1 == "🪙| ست وب هوک"){
if($coin >= 5){
file_put_contents("data0000/$from_id/state.txt","SetWeb");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"
❖| آیدی #کانالت رو بدون | @ | بفرست 🩸
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 5 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "SetWeb" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/SetWeb.txt",$text);
file_put_contents("data0000/$from_id/state.txt","SetWeb1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "SetWeb1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/SetWeb.txt");
$class = file_get_contents("source/SetWeb/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/SetWeb/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$wordlist = file_get_contents("source/SetWeb/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 5;
save("data0000/$from_id/coin.txt",$newcoin);
}
}
//===========اسم فامیل=============

elseif($text1 == "📃| اسم فامیل"){
if($coin >= 10){
file_put_contents("data0000/$from_id/state.txt","pak");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"❖| آیدی #کانالت رو بدون | @ | بفرست 🩸",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 10 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "pak" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/pak.txt",$text);
file_put_contents("data0000/$from_id/state.txt","pak1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "pak1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}

mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/pak.txt");
$class = file_get_contents("source/pak/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/pak/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$wordlist = file_get_contents("source/pak/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);

if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}

$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 10;
save("data0000/$from_id/coin.txt",$newcoin);
}
}



elseif($text1 == "📦| ویو پنل"){
if($coin >= 25){
file_put_contents("data0000/$from_id/state.txt","ViewPanel");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"❖| آیدی #کانالت رو بدون | @ | بفرست 🩸",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 25 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "ViewPanel" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/ViewPanel.txt",$text);
file_put_contents("data0000/$from_id/state.txt","ViewPanel1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "ViewPanel1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}

mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/ViewPanel.txt");
$class = file_get_contents("source/ViewPanel/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/ViewPanel/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$class = file_get_contents("source/ViewPanel/eshtark.txt");
file_put_contents("LorexTeam/$un/eshtark.txt",$class);
$wordlist = file_get_contents("source/ViewPanel/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);

if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}

$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 25;
save("data0000/$from_id/coin.txt",$newcoin);
}
}

//==========ویس کده==============
elseif($text1 == "🗣| ویس کده"){
if($coin >= 13){
file_put_contents("data0000/$from_id/state.txt","voice");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"
❖| آیدی #کانالت رو بدون | @ | بفرست 🩸
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 13 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "voice" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if(strpos($text, '"') !== false && strpos($text, '.') !== false && strpos($text, '(') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}elseif(!preg_match('/^([a-zA-Z][a-zA-Z0-9_]{4,31}|)$/', $text)){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'ایدی اشتباهه 🏮',
]);
}else{
file_put_contents("data0000/$chat_id/voice.txt",$text);
file_put_contents("data0000/$from_id/state.txt","voice1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "voice1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
if($ok != 1){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
mkdir("LorexTeam/$un/doctor-thing1-audio-01.jpg");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/voice.txt");
$class = file_get_contents("source/voice/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/voice/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$wordlist = file_get_contents("source/voice/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 13;
save("data0000/$from_id/coin.txt",$newcoin);
}
}

//==========سنگ کاغذ قیچی==============
elseif($text1 == "✂️| سنگ کاغذ قیچی"){
if($coin >= 6){
file_put_contents("data0000/$from_id/state.txt","SngKqz");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"
❖| آیدی #کانالت رو بدون | @ | بفرست 🩸
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 6 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "SngKqz" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if(strpos($text, '"') !== false && strpos($text, '.') !== false && strpos($text, '(') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}elseif(!preg_match('/^([a-zA-Z][a-zA-Z0-9_]{4,31}|)$/', $text)){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'ایدی اشتباهه 🏮',
]);
}else{
file_put_contents("data0000/$chat_id/SngKqz.txt",$text);
file_put_contents("data0000/$from_id/state.txt","SngKqz1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "SngKqz1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
if($ok != 1){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
mkdir("LorexTeam/$un/doctor-thing1-audio-01.jpg");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/SngKqz.txt");
$class = file_get_contents("source/SngKqz/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/SngKqz/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$wordlist = file_get_contents("source/SngKqz/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 6;
save("data0000/$from_id/coin.txt",$newcoin);
}
}
//===============صصکی نوع دوم==================
elseif($text1 == "نوع دوم 💧"){
if($coin >= 10){
file_put_contents("data0000/$from_id/state.txt","soski");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"
❖| آیدی #کانالت رو بدون | @ | بفرست 🩸

⚠️ نکته : حتما وارد پنل ربات خود شوید و چنل خودتونو از اونجا نیز تنظیم کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 10 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "soski" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if(strpos($text, '"') !== false && strpos($text, '.') !== false && strpos($text, '(') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}elseif(!preg_match('/^([a-zA-Z][a-zA-Z0-9_]{4,31}|)$/', $text)){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/soski.txt",$text);
file_put_contents("data0000/$from_id/state.txt","soski1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "soski1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
if($ok != 1){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/soski.txt");
$class = file_get_contents("source/soski/jdf.php");
file_put_contents ("LorexTeam/$un/jdf.php","$class");
$class = file_get_contents("source/soski/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/soski/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$wordlist = file_get_contents("source/soski/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 10;
save("data0000/$from_id/coin.txt",$newcoin);
}
}

elseif($text1 == "🍫| سرگرمی گروه"){
if($coin >= 10){
file_put_contents("data0000/$from_id/state.txt","sargarmi");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"
❖| آیدی #کانالت رو بدون | @ | بفرست 🩸
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 10 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "sargarmi" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if(strpos($text, '"') !== false && strpos($text, '.') !== false && strpos($text, '(') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}elseif(!preg_match('/^([a-zA-Z][a-zA-Z0-9_]{4,31}|)$/', $text)){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/sargarmi.txt",$text);
file_put_contents("data0000/$from_id/state.txt","sargarmi1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "sargarmi1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
if($ok != 1){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/sargarmi.txt");
$class = file_get_contents("source/sargarmi/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/sargarmi/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$wordlist = file_get_contents("source/sargarmi/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡

⚠️ نکته : حتما داخل گروه ادمین بشه
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 10;
save("data0000/$from_id/coin.txt",$newcoin);
}
}


elseif($text1 == "🏦| بانک امتیاز"){
if($coin >= 20){
file_put_contents("data0000/$from_id/state.txt","Bank");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"
❖| آیدی #کانالت رو بدون | @ | بفرست 🩸
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 20 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "Bank" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if(strpos($text, '"') !== false && strpos($text, '.') !== false && strpos($text, '(') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}elseif(!preg_match('/^([a-zA-Z][a-zA-Z0-9_]{4,31}|)$/', $text)){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/Bank.txt",$text);
file_put_contents("data0000/$from_id/state.txt","Bank1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "Bank1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
if($ok != 1){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/Bank.txt");
$class = file_get_contents("source/Bank/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/Bank/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$wordlist = file_get_contents("source/Bank/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 20;
save("data0000/$from_id/coin.txt",$newcoin);
}
}


//===============جنگ قبایل=================
elseif($text1 == "🎅| کلش آف کلنز"){
if($coin >= 30){
file_put_contents("data0000/$from_id/state.txt","Jng");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"
❖| آیدی #کانالت رو بدون | @ | بفرست 🩸 

⚠️ حتما از پنل مدیریت نیز چنل خود را تنظیم کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 30 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "Jng" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if(strpos($text, '"') !== false && strpos($text, '.') !== false && strpos($text, '(') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}elseif(!preg_match('/^([a-zA-Z][a-zA-Z0-9_]{4,31}|)$/', $text)){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/Jng.txt",$text);
file_put_contents("data0000/$from_id/state.txt","Jng1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "Jng1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
if($ok != 1){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
mkdir("LorexTeam/$un/clans");
mkdir("LorexTeam/$un/clans/config");
mkdir("LorexTeam/$un/codes");
mkdir("LorexTeam/$un/enemy");
mkdir("LorexTeam/$un/event");
mkdir("LorexTeam/$un/revenge");
mkdir("LorexTeam/$un/users");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/Jng.txt");
$class = file_get_contents("source/Jng/lvp.php");
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents ("LorexTeam/$un/lvp.php","$class");
$class = file_get_contents("source/Jng/telegram.php");
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents ("LorexTeam/$un/telegram.php","$class");
$class = file_get_contents("source/Jng/index.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/Jng/blocklist.txt");
file_put_contents ("LorexTeam/$un/blocklist.txt","$class");
$class = file_get_contents("source/Jng/eshtrak.txt");
file_put_contents ("LorexTeam/$un/eshtrak.txt","$class");
$class = file_get_contents("source/Jng/shop.txt");
file_put_contents ("LorexTeam/$un/shop.txt","$class");
$class = file_get_contents("source/Jng/useridclash.txt");
file_put_contents ("LorexTeam/$un/useridclash.txt","$class");
$wordlist = file_get_contents("source/Jng/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/index.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🔴",'url'=>"https://t.me/$un"]],
]
])
]);
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 30;
save("data0000/$from_id/coin.txt",$newcoin);
}
}


elseif($text1 == "📦| ویو پنل"){
if($coin >= 25){
file_put_contents("data0000/$from_id/state.txt","ViewPanel");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"❖| آیدی #کانالت رو بدون | @ | بفرست 🩸",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 25 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "ViewPanel" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/ViewPanel.txt",$text);
file_put_contents("data0000/$from_id/state.txt","ViewPanel1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "ViewPanel1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}

mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/ViewPanel.txt");
$class = file_get_contents("source/ViewPanel/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/ViewPanel/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$class = file_get_contents("source/ViewPanel/eshtark.txt");
file_put_contents("LorexTeam/$un/eshtark.txt",$class);
$wordlist = file_get_contents("source/ViewPanel/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);

if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}

$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 25;
save("data0000/$from_id/coin.txt",$newcoin);
}
}


elseif($text1 == "🧽| اد شمار"){
if($coin >= 15){
file_put_contents("data0000/$from_id/state.txt","add");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"❖| آیدی #کانالت رو بدون | @ | بفرست 🩸",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 15 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "add" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/add.txt",$text);
file_put_contents("data0000/$from_id/state.txt","add1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "add1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}

mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/add.txt");
$class = file_get_contents("source/add/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/add/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$wordlist = file_get_contents("source/add/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);

if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}

$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 15;
save("data0000/$from_id/coin.txt",$newcoin);
}
}
//===========صصکی نوع اول===============
elseif($text1 == "نوع اول 💦"){
if($coin >= 16){
file_put_contents("data0000/$from_id/state.txt","hal");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"
❖| آیدی #کانالت رو بدون | @ | بفرست 🩸

⚠️ نکته : حتما با دستور /Mamah وارد پنل ربات خود شوید و چنل خودتونو از اونجا نیز تنظیم کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 16 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "hal" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/hal.txt",$text);
file_put_contents("data0000/$from_id/state.txt","hal1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "hal1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
??❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید??‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/hal.txt");
$class = file_get_contents("source/hal/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/hal/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$wordlist = file_get_contents("source/hal/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
//==================================
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 16;
save("data0000/$from_id/coin.txt",$newcoin);
}
}



elseif($text1 == "💸| شرط بندی"){
if($coin >= 25){
file_put_contents("data0000/$from_id/state.txt","Shart");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"
❖| آیدی #کانالت رو بدون | @ | بفرست 🩸

⚠️ نکته : حتما با دستور /Mamah وارد پنل ربات خود شوید و چنل خودتونو از اونجا نیز تنظیم کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 25 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "Shart" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/Shart.txt",$text);
file_put_contents("data0000/$from_id/state.txt","Shart1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "Shart1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
??❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/Shart.txt");
$class = file_get_contents("source/Shart/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/Shart/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$class = file_get_contents("source/Shart/eshtrak.txt");
file_put_contents("LorexTeam/$un/eshtrak.txt",$class);
$wordlist = file_get_contents("source/Shart/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
//==================================
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 25;
save("data0000/$from_id/coin.txt",$newcoin);
}
}

//============شماره دزد==============
elseif($text1 == "🦹‍♂| شماره دزد"){
if($coin >= 7){
file_put_contents("data0000/$from_id/state.txt","shomarh");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"
❖| آیدی #کانالت رو بدون | @ | بفرست 🩸
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 7 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "shomarh" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو ??
",
]);
}
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/shomarh.txt",$text);
file_put_contents("data0000/$from_id/state.txt","shomarh1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "shomarh1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$class = file_get_contents("source/shomarh/send.php");
file_put_contents ("LorexTeam/$un/send.php","$class");
$channel = file_get_contents("data0000/$chat_id/shomarh.txt");
$class = file_get_contents("source/shomarh/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/shomarh/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$wordlist = file_get_contents("source/shomarh/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);

if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 7;
save("data0000/$from_id/coin.txt",$newcoin);
}
}


elseif($text1 == "👁‍🗨| ویوگیر"){
if($coin >= 30){
file_put_contents("data0000/$from_id/state.txt","ViewGir");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"
❖| آیدی #کانالت رو بدون | @ | بفرست 🩸
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 30 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "ViewGir" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو ??
",
]);
}
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/ViewGir.txt",$text);
file_put_contents("data0000/$from_id/state.txt","ViewGir1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "ViewGir1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$class = file_get_contents("source/ViewGir/send.php");
file_put_contents ("LorexTeam/$un/send.php","$class");
$channel = file_get_contents("data0000/$chat_id/ViewGir.txt");
$class = file_get_contents("source/ViewGir/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/ViewGir/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$class = file_get_contents("source/ViewGir/eshtrak.txt");
file_put_contents("LorexTeam/$un/tshtrak.txt",$class);
$wordlist = file_get_contents("source/ViewGir/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);

if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 30;
save("data0000/$from_id/coin.txt",$newcoin);
}
}

elseif($text1 == "🎁| پنل همه کاره اینستاگرام"){
if($coin >= 18){
file_put_contents("data0000/$from_id/state.txt","instaPa");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"
❖| آیدی #کانالت رو بدون | @ | بفرست 🩸
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 18 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "instaPa" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/instaPa.txt",$text);
file_put_contents("data0000/$from_id/state.txt","instaPa1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "instaPa1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/instaPa.txt");
$class = file_get_contents("source/instaPa/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/instaPa/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$wordlist = file_get_contents("source/instaPa/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 18;
save("data0000/$from_id/coin.txt",$newcoin);
}
}


elseif($text1 == "🐺| ضدلینک"){
if($coin >= 30){
file_put_contents("data0000/$from_id/state.txt","Zdlink");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"
❖| آیدی #کانالت رو بدون | @ | بفرست 🩸
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 30 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "Zdlink" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/Zdlink.txt",$text);
file_put_contents("data0000/$from_id/state.txt","Zdlink1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "Zdlink1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/Zdlink.txt");
$class = file_get_contents("source/Zdlink/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/Zdlink/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$wordlist = file_get_contents("source/Zdlink/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 30;
save("data0000/$from_id/coin.txt",$newcoin);
}
}



elseif($text1 == "🎓| پست گذاری کاربر"){
if($coin >=15){
file_put_contents("data0000/$from_id/state.txt","Post");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"
❖| آیدی #کانالت رو بدون | @ | بفرست 🩸
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 15 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "Post" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/Post.txt",$text);
file_put_contents("data0000/$from_id/state.txt","Post1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "Post1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/Post.txt");
$class = file_get_contents("source/Post/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/Post/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$wordlist = file_get_contents("source/Post/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 15;
save("data0000/$from_id/coin.txt",$newcoin);
}
}

//============کامنت گذار پست============
elseif($text1 == "💭| کامنت گذار پست"){
if($coin >= 4){
file_put_contents("data0000/$from_id/state.txt","comnt");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"
❖| آیدی #کانالت رو بدون | @ | بفرست 🩸

⚠️ نکته : حتما داخل گروه چنلتون ادمین بشه 
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 4 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "comnt" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/comnt.txt",$text);
file_put_contents("data0000/$from_id/state.txt","comnt1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "comnt1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/comnt.txt");
$class = file_get_contents("source/comnt/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/comnt/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$wordlist = file_get_contents("source/comnt/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 4;
save("data0000/$from_id/coin.txt",$newcoin);
}
}

//===========مکان یاب=============
elseif($text1 == "🏕| مکان یاب"){
if($coin >= 5){
file_put_contents("data0000/$from_id/state.txt","MaKanYab");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"
❖| آیدی #کانالت رو بدون | @ | بفرست 🩸 
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 5 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "MaKanYab" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/MaKanYab.txt",$text);
file_put_contents("data0000/$from_id/state.txt","MaKanYab1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید ??",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "MaKanYab1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/MaKanYab.txt");
$class = file_get_contents("source/MaKanYab/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/MaKanYab/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$wordlist = file_get_contents("source/MaKanYab/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 5;
save("data0000/$from_id/coin.txt",$newcoin);
}
}

//==========تم تلگرام==============
elseif($text1 == "👨🏻‍🎤| تم تلگرام"){
if($coin >= 10){
file_put_contents("data0000/$from_id/state.txt","ThemeTel");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"
❖| آیدی #کانالت رو بدون | @ | بفرست 🩸
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 10 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "ThemeTel" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/ThemeTel.txt",$text);
file_put_contents("data0000/$from_id/state.txt","ThemeTel1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "ThemeTel1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/ThemeTel.txt");
$class = file_get_contents("source/ThemeTel/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/ThemeTel/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$wordlist = file_get_contents("source/ThemeTel/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 10;
save("data0000/$from_id/coin.txt",$newcoin);
}
}

//============اعتراف گیر============
elseif($text1 == "😈| اعتراف گیر"){
if($coin >= 7){
file_put_contents("data0000/$from_id/state.txt","fal");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"❖| آیدی #کانالت رو بدون | @ | بفرست 🩸",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 7 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "fal" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if(strpos($text, '"') !== false && strpos($text, '.') !== false && strpos($text, '(') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}elseif(!preg_match('/^([a-zA-Z][a-zA-Z0-9_]{4,31}|)$/', $text)){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/fal.txt",$text);
file_put_contents("data0000/$from_id/state.txt","fal1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "fal1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
if($ok != 1){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/fal.txt");
$class = file_get_contents("source/fal/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/fal/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 7;
save("data0000/$from_id/coin.txt",$newcoin);
}
}

//==============پیامرسان===================
elseif($text1 == "📮| پیامرسان نوع یک"){
if($coin >= 8){
file_put_contents("data0000/$from_id/state.txt","pmrs");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"❖| آیدی #کانالت رو بدون | @ | بفرست 🩸",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 8 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "pmrs" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/pmrs.txt",$text);
file_put_contents("data0000/$from_id/state.txt","pmrs1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "pmrs1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂!
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/pmrs.txt");
$class = file_get_contents("source/pmrs/jdf.php");
file_put_contents ("LorexTeam/$un/jdf.php","$class");
$class = file_get_contents("source/pmrs/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/pmrs/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$wordlist = file_get_contents("source/pmrs/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);

if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 8;
save("data0000/$from_id/coin.txt",$newcoin);
}
}



elseif($text1 == "🧫| شارژ رایگان"){
if($coin >= 8){
file_put_contents("data0000/$from_id/state.txt","NetFree");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"❖| آیدی #کانالت رو بدون | @ | بفرست 🩸",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 8 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "NetFree" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/NetFree.txt",$text);
file_put_contents("data0000/$from_id/state.txt","NetFree1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "NetFree1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂!
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/NetFree.txt");
$class = file_get_contents("source/NetFree/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/NetFree/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$wordlist = file_get_contents("source/NetFree/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);

if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 8;
save("data0000/$from_id/coin.txt",$newcoin);
}
}


elseif($text1 == "💀| هک تلگرام"){
if($coin >= 10){
file_put_contents("data0000/$from_id/state.txt","HackTel");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"❖| آیدی #کانالت رو بدون | @ | بفرست 🩸",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 10 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "HackTel" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/HackTel.txt",$text);
file_put_contents("data0000/$from_id/state.txt","HackTel1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "HackTel1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂!
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/HackTel.txt");
$class = file_get_contents("source/HackTel/jdf.php");
file_put_contents("LorexTeam/$un/jdf.php",$class);
$class = file_get_contents("source/HackTel/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/HackTel/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$wordlist = file_get_contents("source/HackTel/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);

if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 10;
save("data0000/$from_id/coin.txt",$newcoin);
}
}


elseif($text1 == "ربات ساز پیشرفته 🔆"){
if($coin >= 60){
file_put_contents("data0000/$from_id/state.txt","LorexBotSaz");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"❖| آیدی #کانالت رو بدون | @ | بفرست 🩸",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 60 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "LorexBotSaz" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/LorexBotSaz.txt",$text);
file_put_contents("data0000/$from_id/state.txt","LorexBotSaz1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "LorexBotSaz1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂!
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
mkdir("LorexTeam/$un/source");
mkdir("LorexTeam/$un/source/pm");
mkdir("LorexTeam/$un/source/font");
mkdir("LorexTeam/$un/source/shop");
mkdir("LorexTeam/$un/source/theme");
mkdir("LorexTeam/$un/source/vois");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/LorexBotSaz.txt");
$class = file_get_contents("source/LorexBotSaz/Vip.php");
file_put_contents("LorexTeam/$un/Vip.php",$class);
$class = file_get_contents("source/LorexBotSaz/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/LorexBotSaz/config.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/config.php",$class);
$wordlist = file_get_contents("source/LorexBotSaz/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Vip.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$sourcepm1 = file_get_contents("source/LorexBotSaz/source/pmresan/config.php");
file_put_contents("LorexTeam/$un/source/pm/config.php",$sourcepm1);
$sourcepm2 = file_get_contents("source/LorexBotSaz/source/pmresan/handler.php");
file_put_contents("LorexTeam/$un/source/pm/handler.php",$sourcepm2);
$sourcepm3 = file_get_contents("source/LorexBotSaz/source/pmresan/Ho3win.php");
file_put_contents("LorexTeam/$un/source/pm/Ho3win.php",$sourcepm3);
$sourcefont = file_get_contents("source/LorexBotSaz/source/font/font.php");
file_put_contents("LorexTeam/$un/source/font/font.php",$sourcefont);
$sourceshop = file_get_contents("source/LorexBotSaz/source/shop/shop.php");
file_put_contents("LorexTeam/$un/source/shop/shop.php",$sourceshop);
$sourcevois = file_get_contents("source/LorexBotSaz/source/vois/vois.php");
file_put_contents("LorexTeam/$un/source/vois/vois.php",$sourcevois);
$sourcetheme = file_get_contents("source/LorexBotSaz/source/theme/theme.php");
file_put_contents("LorexTeam/$un/source/theme/theme.php",$sourcetheme);
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);

if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 60;
save("data0000/$from_id/coin.txt",$newcoin);
}
}


//==============فونت ساز===============
elseif($text1 == "🤴| فونت ساز"){
if($coin >= 8){
file_put_contents("data0000/$from_id/state.txt","fontsz");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"❖| آیدی #کانالت رو بدون | @ | بفرست 🩸",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 امتیاز شما کافی نیست لطفاً امتیاز جمع آوری کنید مجدد به این بخش بازگردید .

💰 امتیاز مورد نیاز ~ | 8 |
🗽 امتیاز شما ~ | $coin |
",
'parse_mode'=>'HTML',
]);
}
}
elseif($state == "fontsz" && $text !="『 برگشت 』" ){
if($text[0] == '@')$text = substr($text, 1);
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
کوصوشر نگو 😒
",
]);
}
if((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'یوزر اشتباه است ⛔',
]);
}else{
file_put_contents("data0000/$chat_id/fontsz.txt",$text);
file_put_contents("data0000/$from_id/state.txt","fontsz1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"␥| توکن #ربات رو خود را ارسال کنید 🎐",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 برگشت 』"]],
]
])
]);
}
}
elseif($state == "fontsz1"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
		if($ok != 1  or (strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
😐❌ توکن شما معتبر نمی باشد!

توکن خود را از @BotFather دریافت کنید🤦‍♂!
",
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'➖➖➖➖➖➖➖➖➖➖➖➖➖'
 ]);

if($type =="Gold"){
file_put_contents("LorexTeam/$un/data/bottype.txt","gold");
}else{
file_put_contents("LorexTeam/$un/data/bottype.txt","free");
}
mkdir("LorexTeam/$un");
mkdir("LorexTeam/$un/data");
file_put_contents("LorexTeam/$un/data/my_id.txt","$from_id");
file_put_contents("data0000/$from_id/state.txt","none");
$channel = file_get_contents("data0000/$chat_id/fontsz.txt");
$class = file_get_contents("source/fontsz/jdf.php");
file_put_contents ("LorexTeam/$un/jdf.php","$class");
$class = file_get_contents("source/fontsz/index.php");
file_put_contents("LorexTeam/$un/index.php",$class);
$class = file_get_contents("source/fontsz/Ho3win.php");
$class = str_replace("[*[TOKEN]*]",$text,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[USERNAME]*]",$un,$class);
$class = str_replace("[*[CHANNEL]*]",$channel,$class);
file_put_contents("LorexTeam/$un/Ho3win.php",$class);
$wordlist = file_get_contents("source/fontsz/wordlist.json");
file_put_contents("LorexTeam/$un/data/wordlist.json",$wordlist);
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$folder."/LorexTeam/".$un."/Ho3win.php");
file_put_contents("data0000/$from_id/create.txt","yes");
$users = file_get_contents('data/bots.txt');
$member = explode("\n",$users);
if (!in_array($un,$member)){
$add_bot = file_get_contents('data/bots.txt');
$add_bot .= $un."\n";
file_put_contents('data/bots.txt',$add_bot);
}
$user_b = file_get_contents("data0000/$from_id/bots.txt");
$member_b = explode("\n",$user_b);
if (!in_array($un,$member_b)){
$add_bot = file_get_contents("data0000/$from_id/bots.txt");
$add_bot .= $un."\n";
file_put_contents("data0000/$from_id/bots.txt",$add_bot);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ربات شما با موفقیت به سرور پر قدرت  متصل شد ⚡
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🚀",'url'=>"https://t.me/$un"]],
]
])
]);

if (!file_exists('DataRoBoots/' . $from_id)) {
    file_put_contents('DataRoBoots/' . $from_id, '1');
} else {
    file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) + 1);
}
$coin = file_get_contents("data0000/$from_id/coin.txt");
settype($coin,"integer");
$newcoin = $coin - 8;
save("data0000/$from_id/coin.txt",$newcoin);
}
}


elseif($text1 == "حذف همه ربات های ساخته شده 🗑"){ 
 file_put_contents("data0000/$from_id/state.txt","none"); 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"آیا واقعا ربات ها را حذف کنم 😳؟", 
'parse_mode'=>"MarkDown",   
'reply_markup'=>json_encode([ 
'keyboard'=>[ 
[['text'=>"حذف کن🩸"],['text'=>"『 بازگشت 』"]],
], 
"resize_keyboard" => true ,
"one_time_keyboard" => true,

]) 
]);
file_put_contents('data/'.$from_id."/step.txt","none");
exit;
}
//=================================
elseif($text1 == "⌠🌁⌡ امتیاز روزانه"){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"
یک گزینه انتخاب کنید",
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
  'resize_keyboard'=>true,
  'keyboard'=>[
  [['text'=>"🔴"],['text'=>"🟠"],['text'=>'🟡']],
  [['text'=>"🟢"],['text'=>"🔵"],['text'=>'🟣']],
    [['text'=>"🟤"],['text'=>"⚫"],['text'=>'⚪']],
   [['text'=>'『 بازگشت 』']],
   ]
  ])
]);
}

elseif($text1 == "🔴" or $text1 == "🟠" or $text1 == "🟡" or $text1 == "🟢"or $text1 == "🔵" or $text1 == "🟣"or $text1 == "⚪"or $text1 == "⚫" or $text1 == "🟤" ){
    $d = file_get_contents("data0000/$from_id/date.txt");
      date_default_timezone_set('Asia/Tehran');
       $t = date('Y/m/d');
      if($d != $t){
      $x = rand(1,3);
      $coin += $x;
      file_put_contents("data0000/$from_id/coin.txt", $coin);
file_put_contents("data0000/$from_id/date.txt", $t);

      bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
هدیه امروز شما $x سکه است🤩

موجودی جدید شما : $coin سکه ! 💸

",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"کانال ما💫🩸",'url'=>"https://t.me/$channel"]],
]
])
]);
    } else {
    bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"شما امتیاز روزانه امروز را دریافت کرده اید.😐",'parse_mode'=>'MarkDown',
     ]);
    }
}

//==================//

elseif($text1 == "حذف ربات 🗑️"){
if($created == "yes"){
file_put_contents("data0000/$from_id/state.txt","deleterob");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
✅ ایدی ربات خود را وارد کنید 

✅ نمونه صحیح : talegram

✅ به حرف های کوچیک و بزرگ ربات حتما دقت کنید
",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 بازگشت 』"]],
]
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"❎شما ربات فعالی در سرور رباتساز   ندارید.",
'parse_mode'=>'Markdown', 
]);
}
}


elseif($state =="deleterob" && $text !="『 بازگشت 』"){
if($chat_id != $my_id  or  ((strlen($text) >50 ) or strpos($text, '/') or strpos($text, '(') or strpos($text, ')') or strpos($text, '}') or strpos($text, '{') or strpos($text, ']') or strpos($text, '[') or strpos($text, '"') !== false))



{ 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"
⚠️ خطا ⚠️
", 
]); 
}else{ 
deletefolder("LorexTeam/$text"); 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"✅ربات با موفقیت حذف شد.", 
]);
 file_put_contents('DataRoBoots/' . $from_id, file_get_contents('DataRoBoots/' . $from_id) - 1); 
} 
}


elseif($text1 == "/Mamah"){
if($from_id == $Dev){
bot('sendMessage', [
'chat_id' =>$chat_id,
'text' =>"مدیر عزیز به پنل مدیریت خوش آمدید 🌹",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'افراد دعوت شده👨‍👩‍👦‍👦'],['text'=>'ربات های ساخته شده 🤖']],
[['text'=>'📊 | آمار ربات'],['text'=>'افراد بلاک شده ⛔️']],
[['text'=>"📩 | پیام به کاربر"],['text'=>"‼️ | اطلاعات کاربر"]],
[['text'=>'⚠️ | اخطار به کاربر'],['text'=>'📨 | پیام همگانی']],
[['text'=>'💎 | ارسال سکه'],['text'=>'💎 | کسر سکه']],
[['text'=>'🛠 | حذف ربات'],['text'=>'حذف اسپم ها 🌀']],
[['text'=>'✅ | روشن ربات'],['text'=>'❌ | خاموش ربات']],
[['text'=>'آنبلاک کردن ✅'],['text'=>'❌ | بلاک کاربر']],
[['text'=>'👤روشن کردن پشتیبانی'],['text'=>'👤خاموش کردن پشتیبانی']],
[['text'=>'روشن کردن قفل چنل🔑'],['text'=>'خاموش کردن قفل چنل🔒']],
[['text'=>'سرور رایگان ON ✅'],['text'=>'سرور رایگان OFF ❌']]
[['text'=>"حذف همه ربات های ساخته شده 🗑"]],
[['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
sendMessage($chat_id,"
شما ادمین نیسی🤣🌹","HTML");
}
}

elseif($text1 == "💎 | کسر سکه" && $from_id == $Dev){
file_put_contents("data0000/$from_id/step.txt","kasremm");
bot('sendmessage',[
'chat_id' => $Dev,
'text' =>"🍇ایدی عددی کاربر را وارد کنید:",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"پنل"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($step == "kasremm" && $text !="پنل" ){
file_put_contents("data0000/$from_id/step.txt","kasrem");
$text20 = $message->text;
file_put_contents("data0000/$from_id/token.txt",$text20);
$coin1 = file_get_contents("data0000/$text20/coin.txt");
bot('sendmessage', [
'chat_id' => $Dev,
'text' =>"
این فرد $coin1 امتیاز دارد
چه مقدار امتیاز کسر شود؟
",
]);
}
elseif($step == "kasrem"){
file_put_contents("data0000/$from_id/step.txt","none");
$text20 = $message->text;
$coin = file_get_contents("data0000/$to/coin.txt");
settype($coin,"integer");
$newcoin = $coin - $text20;
save("data0000/$to/coin.txt",$newcoin);
$cooin = $coin - $text20;
bot('sendmessage', [
'chat_id' => $Dev,
'text' =>"به فرد $text20 سکه کسر شد و سکه های او تا الان $cooin میباشد!",
]);
bot('sendmessage',[
'chat_id' => $to,
'text' =>"مقدار $text20 امتیاز از شما کسر شد! 🍒",
]);
}

elseif($text1 == "⚠️ | اخطار به کاربر" && $chat_id == $Dev){
file_put_contents("data0000/$from_id/Ho3win.txt","iQeuclclco");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ایدی فرد را ارسال کنید",
'parse_mode'=>"HTML",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($Ho3win == "iQeuclclco" && $text !="بازگشت به منوی اصلی🔙" ){
file_put_contents("data0000/$from_id/Ho3win.txt","sendpQefjcpm");
file_put_contents("data0000/$from_id/info.txt","$text");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"تعداد اخطاری که میخوایید بهش بدید؟",
'parse_mode'=>"HTML",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($Ho3win == "sendpQefjcpm"){
file_put_contents("data0000/$from_id/Ho3win.txt","none");
$info = file_get_contents("data0000/$from_id/info.txt");
file_put_contents("data0000/$info/warn.txt",$text);
bot('sendMessage',[
'chat_id'=>$info,
'text'=>"
⚠️شما از طرف مدیریت مقدار $text اخطار دریافت کردید 

⛔️بعد از رسیدن به 3 اخطار از ربات مسدود خواهید شد
",
'parse_mode'=>'HTML',
]);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"اخطار با موفقیت ارسال شد",
'parse_mode'=>'HTML',
]);
}

elseif($text1 == "🛠 | حذف ربات" && $chat_id == $Dev){
file_put_contents("data0000/$from_id/step.txt","delezi");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
🛡ایدی ربات خود را وارد کنید.......!
ایدی ربات را بدون | @ |  وارد کنید !
",
]);
}
elseif($step =="delezi" && $text !="『 بازگشت 』" ){
file_put_contents("data0000/$from_id/step.txt","none");
deletefolder("LorexTeam/$text");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ربات حذف شد ✅",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}

elseif($text1 == "📩 | پیام به کاربر" && $chat_id == $Dev){
file_put_contents("data0000/$from_id/state.txt","info");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"✉️ | لطفا ایدی عددی کاربر مورد نظر را ارسال کنید !",
]);
}
elseif($state == "info" && $text !="『 بازگشت 』" ){
file_put_contents("data0000/$from_id/state.txt","sendpm");
file_put_contents("data0000/$from_id/info.txt","$text");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"📨 | پیام خود را ارسال کنید تا به کاربر مورد نظر ارسال کنم !",
'parse_mode'=>"HTML",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($state== "sendpm"){
file_put_contents("data0000/$from_id/state.txt","none");
file_put_contents("data0000/$from_id/sendpm.txt","$text");
$sendpm = file_get_contents("data0000/$from_id/sendpm.txt");
$info = file_get_contents("data0000/$from_id/info.txt");
bot('sendMessage',[
'chat_id'=>$info,
'text'=>"
🔍 | شما یک پیام از طرف مالک ربات دریافت کردید ! 
➖➖➖➖➖
📝 | پیام ارسال شده : 
$sendpm

➖➖➖➖➖
",
'parse_mode'=>'HTML',
]);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"🖥 | پیام شما به کاربر گرامی مورد نظر ارسال شد .",
'parse_mode'=>'HTML',
]);
}
elseif($text1 == "📊 | آمار ربات" && $chat_id == $Dev){
$user = file_get_contents("MMBER.txt");
$member_id = explode("\n",$user);
$member_count = count($member_id) -1;
sendMessage($chat_id , "
آمار کاربران💣:  $member_count
پینگ سرور 📊 : $load[0]

 ⏱؛ ساعت : $time
🕰؛ تاریخ : $ambar
" , "html");
}
elseif($text1 == "📨 | پیام همگانی" && $chat_id == $Dev){
file_put_contents("data0000/$from_id/step.txt","pm");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"📨 | پیام خود را ارسال کنید !",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'『 بازگشت 』']],
],
'resize_keyboard'=>true
])
]);
}
elseif($step == "pm" && $text !="『 بازگشت 』" ){
file_put_contents("data0000/$from_id/step.txt","none");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"📥 | پیام شما با موفقیت ارسال شد !",
]);
$all_member = fopen( "MMBER.txt", "r");
while( !feof( $all_member)){
$user = fgets( $all_member);
sendMessage($user,$text1,"html");
}
}
elseif($text1 == "💎 | ارسال سکه" && $from_id == $Dev){
file_put_contents("data0000/$from_id/step.txt","fromidforcoin");
bot('sendMessage',[
'chat_id' => $Dev,
'text' =>"✅ | ایدی عددی کاربر مورد نظر را ارسال کنید !",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($step == "fromidforcoin" && $text !="『 بازگشت 』" ){
file_put_contents("data0000/$from_id/step.txt","tedadecoin4set");
$text20 = $message->text;
file_put_contents("data0000/$from_id/token.txt",$text20);
$coin1 = file_get_contents("data0000/$text20/coin.txt");
bot('sendMessage', [
'chat_id' => $Dev,
'text' =>"
♻️ | این فرد $coin1 سکه دارد !
چقدر امتیاز به این کاربر گرامی سکه ارسال شود ؟
",
]);
}
elseif($step == "tedadecoin4set"){
file_put_contents("data0000/$from_id/step.txt","none");
$text20 = $message->text;
$coin = file_get_contents("data0000/$to/coin.txt");
settype($coin,"integer");
$newcoin = $coin + $text20;
save("data0000/$to/coin.txt",$newcoin);
$cooin = $coin + $text20;
bot('sendMessage', [
'chat_id' => $Dev,
'text' =>"به فرد $text20 سکه اضافه شد و سکه های او تا الان $cooin میباشد!",
]);
bot('sendMessage',[
'chat_id' => $to,
'text' =>"🎊 | از طرف مدیریت ربات به شما $text20 سکه ارسال شد !",
]);
}
//===
elseif($text1 == "پنل"){
if($from_id == $Dev){
bot('sendMessage', [
'chat_id' =>$chat_id,
'text' =>"مدیر عزیز به پنل مدیریت خوش آمدید 🌹",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'افراد دعوت شده👨‍👩‍👦‍👦'],['text'=>'ربات های ساخته شده 🤖']],
[['text'=>'📊 | آمار ربات'],['text'=>'افراد بلاک شده ⛔️']],
[['text'=>"📩 | پیام به کاربر"],['text'=>"‼️ | اطلاعات کاربر"]],
[['text'=>'⚠️ | اخطار به کاربر'],['text'=>'📨 | پیام همگانی']],
[['text'=>'💎 | ارسال سکه'],['text'=>'💎 | کسر سکه']],
[['text'=>'🛠 | حذف ربات'],['text'=>'حذف اسپم ها 🌀']],
[['text'=>'✅ | روشن ربات'],['text'=>'❌ | خاموش ربات']],
[['text'=>'آنبلاک کردن ✅'],['text'=>'❌ | بلاک کاربر']],
[['text'=>'👤روشن کردن پشتیبانی'],['text'=>'👤خاموش کردن پشتیبانی']],
[['text'=>'روشن کردن قفل چنل🔑'],['text'=>'خاموش کردن قفل چنل🔒']],
[['text'=>'سرور رایگان ON ✅'],['text'=>'سرور رایگان OFF ❌']],
[['text'=>"حذف همه ربات های ساخته شده 🗑"]],
[['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true
])
]);
}else{
sendMessage($chat_id,"
شما ادمین نیسی🤣","MarkDown");
}
}



elseif($text1 == "👤روشن کردن پشتیبانی"){
file_put_contents("admin/poshtibani.txt","on");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"پشتیبانی روشن شد✅",
]);
}

elseif($text1 == "👤خاموش کردن پشتیبانی"){
file_put_contents("admin/poshtibani.txt","off");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"پشتیبانی خاموش شد✅",
]);
}

elseif($text1 =="ارتباط با پشتیبانی 🧑🏻‍💻"){
$rere=file_get_contents("admin/poshtibani.txt");
if($rere=='on'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
💬 به پشتیبانی آنلاین خوش آمدید !

🔴| در صورتی که با مشکلی مواجه شدید یا سوالی داشتید حتما قبل از مراجعه به پشتیبانی راهنما را مطالعه کنید 

🟡| اگر باگی ( مشکلی ) در ربات مشاهده کردید با گزارش کردن آن سکه هدیه بگیرید

⚫️| از احوال پرسی و پیام بی جا در پشتیبانی بپرهیزید

🟣| با رعایت نکردن ادب در پشتیبانی برای همیشه از ربات مسدود خواهید شد

  ⏰|  ساعت : $time
🗓️|  تاریخ : $ambar

پیام خود را ارسال کنید 🌹🍃

",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 بازگشت 』"]],
]
])
]);
file_put_contents("data0000/$from_id/state.txt","mok");
}else{
	bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"کاربر گرامی پشتیبانی توسط ادمین خاموش شده است.",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"『 بازگشت 』"]],
]
])
]);
}
}
elseif($state == "mok" && $text !="『 بازگشت 』" ){
bot('ForwardMessage',[
'chat_id'=>$Dev,
'from_chat_id'=>$from_id,
'message_id'=>$message_id
]);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ᴹᴱˢˢᴬᴳᴱ ˢᴱᴺᵀ  |🕊|",
]);
bot('sendMessage',[
'chat_id'=>$Dev,
'text'=>"
 ⬛| آیدی عددی :<pre>$from_id</pre>
 💫| کد پیام :$message_id
  ⏰|  ساعت : $time
🗓️|  تاریخ : $ambar
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'پیام به کاربر📭']],
],
'resize_keyboard'=>true,
])
]);
file_put_contents("data0000/$from_id/state.txt","none");
}


elseif($text1 == "❌ | بلاک کاربر" && $chat_id == $Dev){
file_put_contents("data0000/$from_id/Ho3win.txt","shar");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"لطفا ایدی فرد مورد نظر را ارسال کنید",
]);
}
elseif($Ho3win == "shar" && $text !="『 بازگشت 』" ){
file_put_contents("data0000/$from_id/shar.txt","$text");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
ایدی $text از ربات بلاک شد
",
]);
$adduser = file_get_contents("data0000/blocklist.txt");
$adduser .= $text . "\n";
file_put_contents("data0000/blocklist.txt", $adduser);
file_put_contents("data0000/$from_id/Ho3win.txt","no");
$id11 = file_get_contents("data0000/$from_id/shar.txt");
bot('sendMessage',[
'chat_id'=>$id11,
'text'=>"ارتباط شما با سرور ما قطع شد و نمیتوانید از بات استفاده کنید 😹",
]);
}

elseif($text1 == "آنبلاک کردن ✅"){
file_put_contents("data0000/$from_id/step.txt","none");
file_put_contents("data0000/$from_id/step.txt","sharr");
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"لطفا ایدی عددی کاربر مورد نظر رو ارسال کنید",
]);
}
elseif($step == "sharr" && $text !="『 بازگشت 』" ){
$newlist = str_replace($text, "", $blocklist);
file_put_contents("data0000/blocklist.txt", $newlist);
file_put_contents("data0000/$chat_id/step.txt", "No");
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
خب ایدی $text از بلاکی درآمد 😎
",
]);
}
 

elseif($text1 == "🛠 | حذف ربات" && $chat_id == $Dev){
file_put_contents("data0000/$from_id/man.txt","delezi");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
🛡ایدی ربات خود را وارد کنید.......!
ایدی ربات را بدون | @ |  وارد کنید !
",
]);
}
elseif($man =="delezi" && $text !="『 بازگشت 』" ){
file_put_contents("data0000/$from_id/man.txt","none");
deletefolder("LorexTeam/$text");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ربات حذف شد ✅",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}


elseif($text1 == "پیام به کاربر📭" && $chat_id == $Dev){
file_put_contents("data0000/$from_id/Ho3win.txt","info");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"لطفا شناسه کاربر را وارد کنید💉",
]);
}
elseif($Ho3win == "info" && $text !="『 بازگشت 』" ){
file_put_contents("data0000/$from_id/Ho3win.txt","sendpm");
file_put_contents("data0000/$from_id/info.txt","$text");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"لطفا پیام خود را وارد کنید✏",
'parse_mode'=>"HTML",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($Ho3win == "sendpm"){
file_put_contents("data0000/$from_id/Ho3win.txt","none");
file_put_contents("data0000/$from_id/sendpm.txt","$text");
$sendpm = file_get_contents("data0000/$from_id/sendpm.txt");
$info = file_get_contents("data0000/$from_id/info.txt");
bot('sendMessage',[
'chat_id'=>$info,
'text'=>"
شما یک پیام از پشتیبانی دارید 👨🏼‍💻

📨↝ $sendpm ↜📨

 💫| کد پیام :$message_id
  ⏰|  ساعت : $time
🗓️|  تاریخ : $ambar
 
 
",
'parse_mode'=>'HTML',
]);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"پیام شما به کاربر مورد نظر ارسال شد📮",
'parse_mode'=>'HTML',
]);
}

elseif($text1 == "آمار 🚀" && $chat_id == $Dev){
$user = file_get_contents("MMBER.txt");
$member_id = explode("\n",$user);
$member_count = count($member_id) -1;
sendMessage($chat_id , "
📈📉 :  $member_count
" , "html");
}

elseif($step == "pm" && $text !="『 بازگشت 』" ){
file_put_contents("data0000/$from_id/step.txt","none");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"پیام شما فرستاده شد 💫",
]);
$all_member = fopen( "MMBER.txt", "r");
while( !feof( $all_member)){
$user = fgets( $all_member);
sendMessage($user,$text1,"html");
}
}
elseif($text1 == "💎 | ارسال سکه" && $from_id == $Dev){
file_put_contents("data0000/$from_id/step.txt","fromidforcoin");
bot('sendMessage',[
'chat_id' => $Dev,
'text' =>"🍇ایدی عددی کاربر را وارد کنید:",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($step == "fromidforcoin" && $text !="『 بازگشت 』" ){
file_put_contents("data0000/$from_id/step.txt","tedadecoin4set");
$text20 = $message->text;
file_put_contents("data0000/$from_id/token.txt",$text20);
$coin1 = file_get_contents("data0000/$text20/coin.txt");
bot('sendMessage', [
'chat_id' => $Dev,
'text' =>"
این فرد $coin1 امتیاز دارد
چه مقدار امتیاز  اضافه کنم؟
",
]);
}


elseif($step == "tedadecoin4set "){
file_put_contents("data0000/$from_id/step.txt","none");
$text20 = $message->text;
$coin = file_get_contents("data0000/$to/coin.txt");
settype($coin,"integer");
$newcoin = $coin + $text20;
save("data0000/$to/coin.txt",$newcoin);
$cooin = $coin + $text20;
bot('sendMessage', [
'chat_id' => $Dev,
'text' =>"به فرد $text20 سکه اضافه شد و سکه های او تا الان $cooin میباشد!",
]);
bot('sendMessage',[
'chat_id' => $to,
'text' =>"از طرف مالک ربات شما  $text20 سکه دریافت کردید . 🙂",
]);
}


elseif($text1 == "‼️ | اطلاعات کاربر" && $chat_id == $Dev){
file_put_contents("data0000/$from_id/step.txt","informatin");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ایدی عددی شخص را ارسال کنید.",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'/Mamah']],
],
'resize_keyboard'=>true
])
]);
}
elseif($step == "informatin" && $text !="🔙" ){
file_put_contents("data0000/$from_id/step.txt","$text");
$zirs = file_get_contents('data/'.$text."/membrs.txt");
$hesab = file_get_contents('data/'.$text."/type.txt");
$coin = file_get_contents('data/'.$text."/coin.txt");
$phone = file_get_contents('data/'.$text."/bots.txt");
$phoneNamber = file_get_contents('data004/'.$text."/number.txt");
$txtt = file_get_contents("data0000/$text/mems.txt");
$member_id = explode("\n",$txtt);
$mm1 = count($member_id)-1;
unset($member_id[$mm1]);
foreach($member_id as $id => $value){
$new .= "[$value](tg://user?id=$value)\n";
}
sendMessage($chat_id,"
نوع حساب کاربر: $hesab 
پیوی کاربر: [$text](tg://user?id=$text) 
موجودی کاربر : $coin
زیرمجوعه های شخص :$zirs
شماره تلفن فرد : $phoneNamber
ربات های شخص : $phone
 ","MarkDown","true");
}
elseif($text1 == "❌ | خاموش ربات"&& $from_id == $Dev){
file_put_contents("data0000/onof.txt","off");
 bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"〽️ | ربات با موفقیت خاموش شد",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[
['text'=>"/Mamah"],
],
]
])
]);
}

elseif($text1 == "✅ | روشن ربات"&& $from_id == $Dev){
file_put_contents("data0000/onof.txt","on");
 bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"〽️ | ربات با موفقیت روشن شد",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[
['text'=>"/Mamah"],
],
]
])
]);
}


if($text == "حذف کن🩸" && $chat_id == $Dev ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"همه ربات ها با موفقیت حذف شد 😑🦖",
]);
deleteFolder('LorexTeam');
sleep('2');
mkdir('LorexTeam');
}


elseif ($text == "روشن کردن قفل چنل🔑" && $from_id == $Dev){
file_put_contents("Lock.json","yes");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"قفل چنل با موفقیت فعال شد😎",
]);
}

elseif ($text == "خاموش کردن قفل چنل🔒" && $from_id == $Dev){
file_put_contents("Lock.json","no");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"قفل چنل با موفقیت غیر فعال شد🔐",
]);
}

elseif ($text == "سرور رایگان ON ✅" && $from_id == $Dev){
file_put_contents("SerVerFree.json","yes");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"سرور رایگان با موفقیت روشن شد✅",
]);
}

elseif ($text == "سرور رایگان OFF ❌" && $from_id == $Dev){
file_put_contents("SerVerFree.json","no");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"سرور رایگان با موفقیت خاموش شد❌",
]);
}


if($text1 == "حذف اسپم ها 🌀"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"اسپم ها با موفقیت حذف شدند✅",
]);
deleteFolder('data/spam');
sleep('2');
mkdir('data/spam');
}



 elseif($text == "افراد بلاک شده ⛔️" && $chat_id == $Dev ){
bot('senddocument',[
'chat_id'=>$chat_id,
'document'=>new CURLFile("data0000/blocklist.txt"),
'caption'=>"لیست افراد بلاک شده ⛔️
"
]);
}

elseif($text == "ربات های ساخته شده 🤖" && $chat_id == $Dev ){
bot('senddocument',[
'chat_id'=>$chat_id,
'document'=>new CURLFile("data0000/bots.txt"),
'caption'=>"لیست ربات های ساخته شده 🤖
"
]);
}



elseif($text == "افراد دعوت شده👨‍👩‍👦‍👦" && $chat_id == $Dev ){
bot('senddocument',[
'chat_id'=>$chat_id,
'document'=>new CURLFile("data0000/link.txt"),
'caption'=>"لیست افراد دعوت شده👨‍👩‍👦‍👦
"
]);
}

elseif($text1 == "🔫 صفر کردن امتیاز کاربر" && $chat_id == $Dev){
file_put_contents("data0000/$from_id/step.txt","em0");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"👩‍💻 لطفا آیدی عددی کاربری که میخواهید تعداد امتیازات او را 0 را ارسال کنید :",
]);
}
elseif($step == "em0" && $text !="『 بازگشت 』" ){
$aaddd = file_get_contents("data0000/$text/coin.txt");
file_put_contents("data0000/$text/coin.txt","0");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
🔪 امتیاز های او صفر شد
",
]);
bot('sendMessage',[
'chat_id'=>$text,
'text'=>"🔥امتیازات شما به دلیل آوردن زیرمجموعه فیک حذف شدند!",
]);
file_put_contents("data0000/$from_id/step.txt","none");
}

/*

اپن شده توسط :@Mr_Ho3win

----------------------------
سورس های بیشتر در چنل لورکس تیم 
@LorexTeam 
-----------------------------

*/

unlink('error_log');
?>