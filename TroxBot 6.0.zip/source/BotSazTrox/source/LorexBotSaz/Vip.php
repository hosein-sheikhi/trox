<?php

/*
بسم الله الرحمن الرحیم

اپن شده توسط :@Mr_Ho3win

----------------------------
سورس های بیشتر در چنل لورکس تیم 
@LorexTeam 
-----------------------------

*/

error_reporting(0);
$telegram_ip_ranges = [
['lower' => '149.154.160.0', 'upper' => '149.154.175.255'], 
['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],    
];
$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
$ok=false;
foreach ($telegram_ip_ranges as $telegram_ip_range) if (!$ok) {
$lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
$upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
if($ip_dec >= $lower_dec and $ip_dec <= $upper_dec) $ok=true;
}
if(!$ok) die("@Mr_Ho3win");
include("config.php");
define('API_KEY','$token');
function bot($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
 $res = curl_exec($ch);
 if(curl_error($ch)){
var_dump(curl_error($ch));
}else{
return json_decode($res);
}
}
function SendMessage($chat_id, $text){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>$text,
'parse_mode'=>'MarkDown']);
}
function EditMessageText($xchatid,$xmessageid,$text,$parse_mode,$disable_web_page_preview,$keyboard){
bot('editMessagetext',[
'chat_id'=>$xchatid,
'message_id'=>$xmessageid,
'text'=>$text,
'parse_mode'=>$parse_mode,
'disable_web_page_preview'=>$disable_web_page_preview,
'reply_markup'=>$keyboard
]);
}
function sendphoto($chat_id, $photo, $captionl){
bot('sendphoto',[
'chat_id'=>$chat_id,
'photo'=>$photo,
'caption'=>$caption,
]);
}
function senddocument($chat_id, $document, $caption){
bot('senddocument',[
'chat_id'=>$chat_id,
'document'=>$document,
'caption'=>$caption
]);
}
function Forward($koja,$key,$pm)
{
bot('ForwardMessage',[
'chat_id'=>$koja,
'from_chat_id'=>$key,
'message_id'=>$pm
]);
}
function save($filename, $data){
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}
function json($from_id,$type,$what){
$user = json_decode(file_get_contents("data/$from_id.json"),true);
$user[$type] = $what;
$out = json_encode($user,128|256);
file_put_contents("data/$from_id.json",$out);
}
function DeleteFolder($path){
 if($handle=opendir($path)){
  while (false!==($file=readdir($handle))){
   if($file<>"." AND $file<>".."){
    if(is_file($path.'/'.$file)){ 
     @unlink($path.'/'.$file);
    } 
    if(is_dir($path.'/'.$file)) { 
     deletefolder($path.'/'.$file); 
     @rmdir($path.'/'.$file); 
    }
   }
        }
    }
}

$update = json_decode(file_get_contents('php://input'));
$username = $update->message->from->username;
$message = $update->message;
$first_name = $message->from->first_name;
$chat_id = $message->chat->id;
$from_id = $message->from->id;
$message_id = $message->message_id;
$text = $message->text;

$Mostafa = $update->message->reply_to_message->forward_from->id; 
$truechannel = json_decode(file_get_contents("https://api.telegram.org/bot$token/getChatMember?chat_id=$channel&user_id=$from_id"));
$tch = $truechannel->result->status;
$tc = $update->message->chat->type;

$Mostafa_Off_On = file_get_contents("data/SenatorTmbot.txt");
$modhoviat = file_get_contents("data/modhoviat.txt");
$my_id = file_get_contents("Bots/$text/my_id.txt");
$mychannel = file_get_contents("data/my_channel.txt");
$givebanner = file_get_contents("data/givebanner.txt");
$textstart = file_get_contents("data/textstart.txt");
$sek = file_get_contents("data/sek.txt");
$code = file_get_contents("data/code.txt");

date_default_timezone_set('Asia/Tehran');
$date = date('Y/m/d');
$time = date('H:i:s');

mkdir("data");
mkdir("data/spam");
mkdir("Bots");
mkdir("Settings");

$botid = bot('GetMe',[]) -> result -> username;
$first_bot = bot('GetMe',[]) -> result -> first_name;
$id_bot = bot('GetMe',[]) -> result -> id;

$Lock = file_get_contents("Settings/Lock.json");
$user = json_decode(file_get_contents("data/$from_id.json"),true);
$step = $user["step"];
$coin = $user["coin"];
$mybot = $user["mybot"];
$mybotpm = $user["mybotpm"];
$mybotshop = $user["mybotshop"];
$mybotvois = $user["mybotvois"];
$mybottheme = $user["mybottheme"];
$type = $user["type"];
$pm = $user["pm"];
$font = $user["font"];
$shop = $user["shop"];
$vois = $user["vois"];
$theme = $user["theme"];
$chanel = $user["chanel"];
$hoviat = $user["hoviat"];

function Spam($user_id){
$spam_status = json_decode(file_get_contents("data/spam/$user_id.json"),true);
if($spam_status != null){
if(mb_strpos($spam_status[0],"time") !== false){
if(str_replace("time ",null,$spam_status[0]) >= time())
exit(false);
else
$spam_status = [1,time()+2];
}
elseif(time() < $spam_status[1]){
if($spam_status[0]+1 > 2){
$time = time() + 200;
$spam_status = ["time $time"];
file_put_contents("data/spam/$user_id.json",json_encode($spam_status,true));
bot('SendMessage',[
'chat_id'=>$user_id,
'text'=>"🔥 بدلیل ارسال پیام مکرر 200 ثانیه بلاک شدید!"
]);
exit(false);
}else{
$spam_status = [$spam_status[0]+1,$spam_status[1]];
}}else{
$spam_status = [1,time()+2];
}}else{
$spam_status = [1,time()+2];
}
file_put_contents("data/spam/$user_id.json",json_encode($spam_status,true));
}
if($tc == "private"){
Spam($from_id);
}
if($step == "ban"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"",
]); 
return false;
}

if($hoviat== "No" && $modhoviat == "on" ){
json($from_id,"hoviat","yes");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"در حال ارسال کپچا [ تایید هویت ] ⏳

لطفا صبر کنید . . .
ＬＯＡＤＩＮＧ . . .",
'reply_markup'=>json_encode([
'KeyboardRemove'=>[],
'remove_keyboard'=>true,
])
]);
$r = rand(1111,99999);
json($from_id,"step","cap$r");
bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=>"https://dynamic.brandcrowd.com/asset/logo/ade8c4ec-17d5-4d35-9444-3b552649bd7e/logo?v=4&text=$r",
'caption'=>"برای استفاده از ربات لازم است تایید هویت کنید♻️

لطفا کد در تصویر رو ارسال کنید✅
فقط اعداد انگلیسی 🇦🇺",
]);
return false;
}
if($text != "sss" && strpos($step,"cap") !== false && $text != "برگشت"){
$ok = str_replace("cap","",$step);
if($text == $ok){
json($from_id,"step","none");
json($from_id,"hoviat","yes");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"مرحله تایید هویت با موفقیت انجام شد✔️

برای ادامه کار از کیبرد استفاده کنید🔰",
'reply_markup'=>json_encode([
"resize_keyboard"=>true,
'keyboard'=>[
[['text'=>'•|🤖 ساخت ربات 🤖|•']],
[['text'=>'حساب من|💫|'],['text'=>'حذف ربات|🗑|'],['text'=>'ربات های من|🌿|']],
[['text'=>'راهنما |🧠|'],['text'=>'پشتیبانی|🧑🏻‍💻|']],
[['text'=>'کانال ما |🐙|'],['text'=>'تست سرعت|🌪️|']]
],
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"عدد ارسالی اشتباه هست‼️  دباره سعی کنید❗️",
]);
}
return false;
}
	
if(strpos($Mostafa_Off_On,"false") !== false && $from_id != $admin ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ربات فعلا از طرف مدیریت خاموش شده است🧨",
]); 
return false;
}

if($coin > 9 && $type == "free" ){
json($from_id,"type","vip");
json($from_id,"coin","0");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"✅ شما موفق به دعوت 10 نفر شدید !
 
🌟 حساب شما هم اکنون ویژه شد !",
]);
}

if(strpos($text=="/start") !== false  && $text !=="/start"){
$tofanhost=str_replace("/start ","",$text);
$HosseinKhorsandi=file_get_contents("data/Member.txt");
$exp=explode("\n",$HosseinKhorsandi);
if(!in_array($from_id,$exp) && $from_id != $tofanhost){
$myfile2 = fopen("data/Member.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$from_id\n");
fclose($myfile2);
$user["step"] = "none";
$user["coin"] = "0";
$user["mybot"] = "No";
$user["mybotshop"] = "No";
$user["mybotpm"] = "No";
$user["mybotvois"] = "No";
$user["mybottheme"] = "No";
$user["type"] = "free";
$user["hoviat"] = "No";
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"عضویت شمارا تبریک میگوییم🎉

برای ادامه کار روی [ /start ] کلیک کنید🔑",
	 ]); 
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson); 
$user1 = json_decode(file_get_contents("data/$tofanhost.json"),true);
$Hossein = $user1['coin'] + 1;
$user1["coin"] = "$Hossein";
$outjson = json_encode($user1,true);
file_put_contents("data/$tofanhost.json",$outjson);
bot('sendMessage',[
'chat_id'=>$tofanhost,
'text'=>"یک نفر با لینک شما وارد ربات شد و شما یک امتیاز دریافت کردید🎊",
'parse_mode'=>"HTML"
]);
return false;
}
}

if(strpos($text,"'") !== false or strpos($text,'"') !== false or strpos($text,"}") !== false or strpos($text,"{") !== false or strpos($text,")'") !== false or strpos($text,"(") !== false or strpos($text,",") !== false){ 
$user = json_decode(file_get_contents("data/$from_id.json"),true);
$user["step"] = "ban";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"شما به دلیل استفاده از کد در رباتساز بلاک شدید🚨
از این پس ربات برای شما |#فقط| غیر فعال میباشد و هیچگونه پاسخی به شما نمیدهد🤘

🧩Dev: $Sup

برای رفع |#مسدودیت| دقایقی دیگر به پشتیبانی اطلاع دهید🧩",
'parse_mode'=>"HTML",
'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
'chat_id'=>$admin,
'text'=>"شخص زیر به دلیل کد دادن به ربات بلاک شد🤘
🧩آیدی عددی کاربر:
$from_id
[👤پروفایلش](tg://user?id=$from_id)",
 'parse_mode'=>"MarkDown",
  ]); 
 }

elseif($text == "🪓لغو عملیات🧨" ){
json($from_id,"step","none");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"عملیات لغو شد🩸   برای ادامه کار | /start | کنید🦠",
'parse_mode'=>'HTML',
]);
return false;
 }

if($text == "『 بازگشت 』" or $text == "/menu" or $text == "/start"  ){
$user1 = file_get_contents('data/Member.txt');
$members = explode("\n",$user1);
if (!in_array($chat_id,$members)){
$add_user = file_get_contents('data/Member.txt');
}
if (!file_exists("data/$from_id.json")) {
$myfile2 = fopen("data/Member.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$from_id\n");
fclose($myfile2);
$user["step"] = "none";
$user["coin"] = "0";
$user["mybot"] = "No";
$user["mybotshop"] = "No";
$user["mybotpm"] = "No";
$user["mybotvois"] = "No";
$user["mybottheme"] = "No";
$user["type"] = "free";
$user["hoviat"] = "No";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
 }
bot('sendMessage', [
'chat_id' => $chat_id,
'text'=>"
کاربر $first_name به ربات ما خوش اومدی🙂
برای استفاده از رباتساز از دکمه های زیر کمک بگیرید🧸",
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'•|🤖 ساخت ربات 🤖|•']],
[['text'=>'حساب من|💫|'],['text'=>'حذف ربات|🗑|'],['text'=>'ربات های من|🌿|']],
[['text'=>'راهنما |🧠|'],['text'=>'پشتیبانی|🧑🏻‍💻|']],
[['text'=>'کانال ما |🐙|'],['text'=>'تست سرعت|🌪️|']],
],
"resize_keyboard"=>true,
])
]); 
}

if($tch != 'member' && $tch != 'creator' && $tch != 'administrator' && $Lock == "yes" && $from_id != $admin ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"با سلام!!👋
کاربر $first_name به ربات ما خوش اومدی🙂

برای ادامه کار و استفاده از رباتساز به کانال ما بپیوندید😉
ID : $channel
ID : $channel
بعد از عضویت روی دکمه زیر کلیک کنید👇",
'parse_mode'=>"HTML",
'resize_keyboard'=>true,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'『 بازگشت 』']],
],
])
]);
}

elseif($text == "حساب من|💫|"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"به قسمت حساب من|💫| خوش اومدین.😉

در این بخش میتوانید با زدن بر روی دکمه 🧧دریافت بنر📥 بنر دریافت کنید و با استفاده از اون در ربات ویژه شوید.

اطلاعات بیشتر در بخش راهنما...👌",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"🧧دریافت بنر📥"],['text'=>"مشخصات من👤"]],
[['text'=>"کد هدیه🎉"]],
[['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}
 
 elseif($text == "مشخصات من👤" ){
bot('SendPhoto', [
'chat_id'=>$from_id,
'photo'=>"https://telegram.me/$username",
'caption'=>"مشخصات شما در ربات ما😉
⏰Time: $time
🕰Date: $date
ایدی شما🆔️: @$username
🥀نام شما: $first_name
🎾حساب شما در ربات: $type
🥇مقدار سکه های شما در ربات: |$coin|

🆔آیدی عددی شما: 

<code>$from_id</code>
",
'parse_mode'=>'HTML',
]);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"😌اطلاعات شما در رباتساز ما 👆

اگر چیزی دریافت نکردین لطفا یک عکس در پروفایل خود قرار دهید و مجددا تلاش کنید👌",
'parse_mode'=>'HTML',
]);
}
 
 elseif($text == "ربات های من|🌿|"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"🤖ربات های شما:

@$mybot
@$mybotpm
@$mybotshop
@$mybottheme

Chanel: $channel",
'parse_mode'=>'HTML',
]);
 }

 elseif($text == "راهنما |🧠|" or $text == "صفحه قبلی🔙" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"خسته نباشید    :)   🎀
به بخش راهنما خوش اومدید 🎉 با استفاده از دکمه های زیر به بخش راهنما مورد نظر بروید🎈",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"راهنمای ʙᴏᴛғᴀᴛʜᴇʀ🔧"]],
[['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}

elseif($text == "راهنمای ʙᴏᴛғᴀᴛʜᴇʀ🔧"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"برای اینکه در رباتساز ما ربات بسازید نیاز به توکن(Token#)دارید.

ما با استفاده از بوت فادر (ربات رسمی تلگرام) این توکن رو بدست میاریم🎊

با بوت فادر شما میتوانید تنظیمات اولیه ربات خود را انجام دهید🎃

برای شروع اموزش از دکمه ها زیر استفاده کنید🤘",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"دستورات کامل Botfather🖱"],['text'=>"ساخت توکن 🖨"]],
[['text'=>"صفحه قبلی🔙"]],
[['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}

elseif($text == "دستورات کامل Botfather🖱" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"👈 آموزش دستورات بات فادر از تیم رباتسازی سناتور🎃
—-------------
/newbot
《 یک ربات جدید ایجاد کنید 》
/mybots
《 ربات های خود را ویرایش کنید 》
/mygames
《 بازی های خود را ویرایش کنید 》
/setname
《 نام یک ربات را تغییر دهید 》
/setdescription
《 توضیحات ربات را تغییر دهید 》
/setabouttext
《 درباره ربات را تغییر دهید 》
/setuserpic
《 تغییر عکس پروفایل ربات 》
/setcommands
《 لیستی از دستورات را تغییر دهید 》
/deletebot
《 رباتی را حذف کنید 》
/token
《 گرفتن توکن یک ربات 》
/setinline
《 حالت خطی را تغییر دهید 》
/setinlinegeo
《 تغییر مکان درخواست های داخلی 》
/setinlinefeedback
《 تغییر تنظیمات بازخورد درون خطی 》
/setjoingroups
《 آیا ربات شما می تواند به گروه اضافه شود 》
/setprivacy
《 حالت حریم خصوصی در گروه ها را تغییر دهید 》
/newgame
《 یک بازی جدید ایجاد کنید 》
/listgames
《 یک لیست از بازی های خود را دریافت کنید 》
/editgame
《 یک بازی را ویرایش کنید 》
/deletegame
《 یک بازی موجود را حذف کنید 》
—-------------
$channel",
'parse_mode'=>'HTML',
]);
 }

 elseif($text == "ساخت توکن 🖨" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"📱ساخت ربات و گرفتن توکن📱
📱🔻برای ساخت ربات و گرفتن توکن توضیحات ربات خودتون مراحله زیر را انجام بدید:
1》به ربات @BotFather وارد بشید
2》دستور  /token تایب کنید یا انتخاب کنید
3》بعد یه اسم واسه رباتتون انتخاب کنید
4》بعد آیدی که واسه رباتتون میخاین بزارید و بفرستین آخر آیدی حتما باید Bot داشته باشد و ارسال میکنید و توکن تو بدست میارید.

°•°•°•°•°•°•°•°•°•°•°•°•°•°•°•°
📱تغیر اسم ربات📱
📱🔻برای عوض کردن اسم ربات خودتون مراحله زیر را انجام بدید:
1》به ربات @BotFather وارد بشید
2》دستور    /setname  تایب کنید یا انتخاب کنید
3》ربات خودتون انتخاب کنید
4》نام جدید رباتتون ارسال کنید.

°•°•°•°•°•°•°•°•°•°•°•°°•°•°•
📱تغیر عکس ربات📱
📱🔻برای عوض کردن عکس ربات خودتون مراحله زیر را انجام بدید:
1》به ربات @BotFather وارد بشید
2》دستور  /setuserpic تایب کنید یا انتخاب کنید
3》ربات خودتون انتخاب کنید
4》عکس جدید رباتتون ارسال کنید.

°•°•°•°•°•°•°•°•°•°•°•°•°•°•°•
📱تغیر اطلاعات ربات📱
📱🔻برای عوض کردن اطلاعت  ربات خودتون مراحله زیر را انجام بدید:
1》به ربات @BotFather وارد بشید
2》دستور  /setabouttext  تایب کنید یا انتخاب کنید
3》ربات خودتون انتخاب کنید
4》اطلاعات جدید رباتتون ارسال کنید.

°•°•°•°•°•°•°•°•°•°•°•°•°•°•°•°
📱تغیر توضیحات ربات📱
📱🔻برای عوض کردن توضیحات ربات خودتون مراحله زیر را انجام بدید:
1》به ربات @BotFather وارد بشید
2》دستور  /setdescription تایب کنید یا انتخاب کنید
3》ربات خودتون انتخاب کنید
4》توضیحات جدید رباتتون ارسال کنید.
📱 @mphp405

🆔 $channel",
'parse_mode'=>'HTML',
]);
 }
 
 elseif($text == "•|🤖 ساخت ربات 🤖|•" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"به بخش ساخت ربات خوش اومدین🌈

یکی از |#بخش| های زیر رو انتخاب کنید.☂",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"بخش ویژه⭐️"],['text'=>"بخش رایگان☀️"]],
[['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}

elseif($text == "/panel" && $from_id != $admin ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"☆شرمنده دوست عزیز☹️

■این دستور فقط مخصوص |#ادمین| میباشد🤘

",
'parse_mode'=>'HTML',
]);
 }

elseif($text == "بخش رایگان☀️" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"این بخش در آپدیت آینده فعال خواهد شد👌",
'parse_mode'=>'HTML',
]);
 }

elseif($text == "بخش ویژه⭐️" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"به بخش ساخت ربات رایگان خوش امدید💚
این بخش نیاز به حساب ویژه دارد اگر ویژه هستید از منوی زیر انتخاب کنید🙂",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"🤴| پیام‌رسان"],['text'=>"🖋| فونت ساز"],['text'=>"🎄| تم تلگرام"]],
[['text'=>"🛒| فروشگاهی"],['text'=>"🎙| شهر ویس"]],
[['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}

elseif($text == "پشتیبانی|🧑🏻‍💻|"){
json($from_id,"step","sup");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"به بخش پشتیبانی رباتساز خوش آمدید🥀

1-لطفا پیام هایی که قبلا پاسخ گرفتید رو ارسال نکنید🐊

2-از پیام های تکراری و توهین آمیز بپرهیزید🐆

3-برای دریافت پاسخ فوروارد تان را باز کنید🦜

4-پیامتان را فقط در قالب متن ارسال کنید🦩

پشتیبانی 12 ساعته در طول روز📩

بعد از ارسال پیام منتظر پاسخ باشید.🗞

با توجه به قوانین بالا پیامتان را ارسال کنید تا بدست مدیریت برسد📬",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🪓لغو عملیات🧨"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($text != "『 بازگشت 』" && $step == "sup"){
json($from_id,"step","none");
$s = "[این شخص](tg://user?id=$from_id)";
bot('ForwardMessage',[
  'chat_id'=>$admin,
  'from_chat_id'=>$from_id,
  'message_id'=>$message_id
  ]);
  bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"👆 توسط $s ارسال شده !",
 'parse_mode'=>"MarkDown",
]); 
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"👌 پیام شما به دست پشتیبانی رسید .",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>'•|🤖 ساخت ربات 🤖|•']],
[['text'=>'حساب من|💫|'],['text'=>'حذف ربات|🗑|'],['text'=>'ربات های من|🌿|']],
[['text'=>'راهنما |🧠|'],['text'=>'پشتیبانی|🧑🏻‍💻|']],
[['text'=>'کانال ما |🐙|'],['text'=>'تست سرعت|🌪️|']],
],
"resize_keyboard"=>true,
])
]); 
}

elseif($Mostafa != "" && $chat_id == $admin ){
     bot('sendMessage',[
 'chat_id'=>$Mostafa,
 'text'=>"📨 پیغامی جدید از مدیریت به شما !
➖➖➖➖➖➖➖➖➖
<code>$text</code>",
 'parse_mode'=>"HTML",
   ]);
        bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"✅پیام شما به فرد ارسال شد.",
 'parse_mode'=>"HTML",
   'reply_to_message_id'=>$message_id,
   ]);
    }

elseif($text == "🧧دریافت بنر📥" ){
bot('SendPhoto', [
'chat_id'=>$from_id,
'photo'=>"$linkphoto",
'caption'=>"$givebanner
https://t.me/$botid?start=$from_id",
]);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"بنر بالا رو به (دوستان،گروه ها،کانال،و...) ارسال کنید .🙂

➕کسانی که برای بار اول با لینک شما وارد ربات شوند شما در ربات سکه میگیرید✅

هر کاربر = یک سکه🔅
|#موفق_باشید|
IDƁΘƬ: @$botid",
'parse_mode'=>'HTML',
]);
}

elseif($text == "تست سرعت|🌪️|"){
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'●○○○○○○○○○10%'
 ]);
 sleep(0.1);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'●●○○○○○○○○20%'
 ]);
 sleep(0.1);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'●●●○○○○○○○30%'
 ]);
 sleep(0.1);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'●●●●○○○○○○40%'
 ]);
 sleep(0.1);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'●●●●●○○○○○50%'
 ]);
 sleep(0.1);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'●●●●●●○○○○60%'
 ]);
 sleep(0.1);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'●●●●●●●○○○70%'
 ]);
 sleep(0.1);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'●●●●●●●●○○80%'
 ]);
 sleep(0.1);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'●●●●●●●●●○90%'
 ]);
 sleep(0.1);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'●●●●●●●●●●100%'
 ]);
 sleep(0.1);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'𝙸 𝙻𝙾𝚅𝙴 :)'
]);
sleep(0.1);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>':)'
]);
}

elseif($text == "کانال ما |🐙|" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"$mychannel",
'parse_mode'=>'HTML',
]);
}

elseif($text == "کد هدیه🎉" ){
json($from_id,"step","code_hedie1");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"کد هدیه ای که در کانال ارسال شده است رو ارسال کنید🧸",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"🪓لغو عملیات🧨"]]
]
])
]);
}
elseif($step == "code_hedie1" ){
if($text == $code){
$ezafe = $coin+$sek;
json($from_id,"coin","$ezafe");
json($from_id,"step","none");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"#تبریک🎊
شما برنده شدین و | $sek سکه دریافت کردین | ",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"🪓لغو عملیات🧨"]]
]
])
]);
bot('SendPhoto', [
'chat_id'=>"@".$channel,
'photo'=>"",
'caption'=>"کد هدیه با موفقیت استفاده شد🔑

🎁فرد استفاده کننده:
[$first_name](tg://user?id=$from_id)
➖➖➖➖➖➖➖➖➖➖➖➖➖➖
🪁تاریخ استفاده کد: $date
⏰ساعت استفاده کد: $time

🏆مقدار امتیاز دریافتی: $sek
لحظات خوبی را برایتان ارزو مندیم🎈",
'parse_mode'=>"MarkDown",
]);
unlink("data/code.txt");
unlink("data/sek.txt");
}else{
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"کد شما درست نمیباشد یا قبلا استفاده شده☘",
]);
}
}

elseif($text == "🤴| پیام‌رسان" && $type == "free" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"حساب شما |free| میباشد🪓

برای ساخت ربات ها نیاز به حساب ویژه دارید🔮

برای ویژه شدن نیاز به 10 زیر مجموعه دارید🕳",
'parse_mode'=>'HTML',
]);
}

elseif($text == "🤴| پیام‌رسان" && $pm == "yes" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"شما قبلا یک ربات پیامرسان ساخته اید☹️",
'parse_mode'=>'HTML',
]);
}

elseif($text == "🤴| پیام‌رسان" && $type == "vip" ){
json($from_id,"step","pm");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"توکن ربات خود را ارسال کنید💎=>سعی کنید درست ارسال کنید🧬",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"🪓لغو عملیات🧨"]],
]
])
]);
}
elseif($step == "pm"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
if($ok != 1){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"| #توکن | ارسالی اشتباه هست🚫

سعی کنید توکن صحیح رو از [ʙᴏᴛғᴀᴛʜᴇʀ] ارسال کنید✅",
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"درحال ساخت ربات پیامرسان✂️
لحظاتی صبور باشید ....🦅",
]);
if($type =="nonono"){
file_put_contents("Botas/$un/bottype.txt","vip");
}else{
file_put_contents("Bots/$un/bottype.txt","free");
}
//=============Mr_Ho3win=====================//
mkdir("Bots/$un");
json($from_id,"step","none");
json($from_id,"pm","yes");
file_put_contents("Bots/$un/my_id.txt","$from_id");
$pm1 = file_get_contents("source/pm/config.php");
$pm1 = str_replace("[*[TOKEN]*]",$text,$pm1);
$pm1 = str_replace("[*[ADMIN]*]",$from_id,$pm1);
file_put_contents("Bots/$un/config.php",$pm1);
$pm2 = file_get_contents("source/pm/index.php");
file_put_contents("Bots/$un/index.php",$pm2);
$pm3 = file_get_contents("source/pm/handler.php");
file_put_contents("Bots/$un/handler.php",$pm3);
//=============Mr_Ho3win=====================//
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$Adras."/Bots/".$un."/index.php");
json($from_id,"mybotpm","$un");
}
sleep(5.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'درحال ساخت ربات پیامرسان✂️
لحظاتی صبور باشید 🧞‍♂
 Loading .... |1/2|'
 ]);
 sleep(4.4);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'درحال ساخت ربات پیامرسان✂️
لحظاتی صبور باشید 🧞‍♂
 Loading .... |2/2|'
 ]);
 bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"با دکمه زیر به ربات خود هدایت میشوید😏",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🤗ورود به ربات🥳",'url'=>"https://t.me/$un"]],
]
])
]);
}

elseif($text == "🖋| فونت ساز" && $type == "free" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"حساب شما |free| میباشد🪓

برای ساخت ربات ها نیاز به حساب ویژه دارید🔮

برای ویژه شدن نیاز به 10 زیر مجموعه دارید🕳",
'parse_mode'=>'HTML',
]);
}

elseif($text == "🖋| فونت ساز" && $font == "yes" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"شما قبلا یک ربات فونت ساز ساخته اید☹️",
'parse_mode'=>'HTML',
]);
}

elseif($text == "🖋| فونت ساز" && $type == "vip" ){
json($from_id,"step","font1");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"ایدی کانالت رو بفرست⚙ => حتما با [ @ ] باشد🦠",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"🪓لغو عملیات🧨"]],
],
'resize_keyboard'=>true
])
]);
}
elseif($step == "font1"){
$getch = json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getchat?chat_id=$text"));
$title = $getch->result->title;
$userch = $getch->result->username;
$ok = $getch->ok;
if($ok != false){
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🛄 کانال با اطلاعات
☢نام کانال:
$title 〽️
🆔ایدی کانال: 
@$userch 〽️
☑️ثبت شد✅

توکن ربات خود را ارسال کنید〽️",
]);
json($from_id,"chanel","$text");
json($from_id,"step","font2");
}else{
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"این کانال وجود ندارد...🚫
سعی کنید ایدی کانال رو دقیق و با [ @ ] ارسال کنید❗️",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"🪓لغو عملیات🧨"]],
],
'resize_keyboard'=>true
])
]);
}
}
elseif($step == "font2"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
if($ok != 1){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"| #توکن | ارسالی اشتباه هست🚫

سعی کنید توکن صحیح رو از [ʙᴏᴛғᴀᴛʜᴇʀ] ارسال کنید✅",
]);
return false;
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"درحال ساخت ربات فونت ساز 🙃
لحظاتی صبور باشید ....🦅",
]);
if($type =="nonono"){
file_put_contents("Botas/$un/bottype.txt","vip");
}else{
file_put_contents("Bots/$un/bottype.txt","free");
}
//=============Mr_Ho3win=====================//
mkdir("Bots/$un");
json($from_id,"step","none");
json($from_id,"font","yes");
file_put_contents("Bots/$un/my_id.txt","$from_id");
$font = file_get_contents("source/font/font.php");
$font = str_replace("[*[TOKEN]*]",$text,$font);
$font = str_replace("[*[ADMIN]*]",$from_id,$font);
$font = str_replace("[*[CHANEL]*]",$chanel,$font);
file_put_contents("Bots/$un/font.php",$font);
//=============Mr_Ho3win=====================//
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$Adras."/Bots/".$un."/font.php");
json($from_id,"mybot","$un");
}
sleep(5.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'درحال ساخت ربات فونت ساز 🙃
لحظاتی صبور باشید 🧞‍♂
 Loading .... |1/2|'
 ]);
 sleep(4.4);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'درحال ساخت ربات فونت ساز 🙃
لحظاتی صبور باشید 🧞‍♂
 Loading .... |2/2|'
 ]);
 bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"با دکمه زیر به ربات خود هدایت میشوید😏",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🤗ورود به ربات🥳",'url'=>"https://t.me/$un"]],
]
])
]);
}

elseif($text == "🛒| فروشگاهی" && $type == "free" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"حساب شما |free| میباشد🪓

برای ساخت ربات ها نیاز به حساب ویژه دارید🔮

برای ویژه شدن نیاز به 10 زیر مجموعه دارید🕳",
'parse_mode'=>'HTML',
]);
}

elseif($text == "🛒| فروشگاهی" && $shop == "yes" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"شما قبلا یک ربات فروشگا ساخته اید☹️",
'parse_mode'=>'HTML',
]);
}

elseif($text == "🛒| فروشگاهی" && $type == "vip" ){
json($from_id,"step","shop1");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"ایدی کانالت رو بفرست⚙ => حتما با [ @ ] باشد🦠",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"🪓لغو عملیات🧨"]],
],
'resize_keyboard'=>true
])
]);
}
elseif($step == "shop1"){
$getch = json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getchat?chat_id=$text"));
$title = $getch->result->title;
$userch = $getch->result->username;
$ok = $getch->ok;
if($ok != false){
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🛄 کانال با اطلاعات
☢نام کانال:
$title 〽️
🆔ایدی کانال: 
@$userch 〽️
☑️ثبت شد✅

توکن ربات خود را ارسال کنید〽️",
]);
json($from_id,"chanel","$text");
json($from_id,"step","shop2");
}else{
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"این کانال وجود ندارد...🚫
سعی کنید ایدی کانال رو دقیق و با [ @ ] ارسال کنید❗️",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"🪓لغو عملیات🧨"]],
],
'resize_keyboard'=>true
])
]);
}
}
elseif($step == "shop2"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
if($ok != 1){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"| #توکن | ارسالی اشتباه هست🚫

سعی کنید توکن صحیح رو از [ʙᴏᴛғᴀᴛʜᴇʀ] ارسال کنید✅",
]);
return false;
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"درحال ساخت ربات فروشگا 🙃
لحظاتی صبور باشید ....🦅",
]);
if($type =="nonono"){
file_put_contents("Botas/$un/bottype.txt","vip");
}else{
file_put_contents("Bots/$un/bottype.txt","free");
}
//=============Mr_Ho3win=====================//
mkdir("Bots/$un");
mkdir("Bots/$un/data");
mkdir("Bots/$un/pro");
mkdir("Bots/$un/free");
json($from_id,"step","none");
json($from_id,"shop","yes");
file_put_contents("Bots/$un/my_id.txt","$from_id");
$shop = file_get_contents("source/shop/shop.php");
$shop = str_replace("[*[TOKEN]*]",$text,$shop);
$shop = str_replace("[*[ADMIN]*]",$from_id,$shop);
$shop = str_replace("[*[CHANEL]*]",$chanel,$shop);
$shop = str_replace("[*[USERBOT]*]",$un,$shop);
file_put_contents("Bots/$un/shop.php",$shop);
//=============Mr_Ho3win=====================//
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$Adras."/Bots/".$un."/shop.php");
json($from_id,"mybotshop","$un");
}
sleep(5.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'درحال ساخت ربات فروشگا 🙃
لحظاتی صبور باشید 🧞‍♂
 Loading .... |1/2|'
 ]);
 sleep(4.4);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'درحال ساخت ربات فروشگا 🙃
لحظاتی صبور باشید 🧞‍♂
 Loading .... |2/2|'
 ]);
 bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"با دکمه زیر به ربات خود هدایت میشوید😏",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🤗ورود به ربات🥳",'url'=>"https://t.me/$un"]],
]
])
]);
}

elseif($text == "🖋| فونت ساز" && $type == "free" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"حساب شما |free| میباشد🪓

برای ساخت ربات ها نیاز به حساب ویژه دارید🔮

برای ویژه شدن نیاز به 10 زیر مجموعه دارید🕳",
'parse_mode'=>'HTML',
]);
}

elseif($text == "🖋| فونت ساز" && $font == "yes" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"شما قبلا یک ربات فونت ساز ساخته اید☹️",
'parse_mode'=>'HTML',
]);
}

elseif($text == "🖋| فونت ساز" && $type == "vip" ){
json($from_id,"step","font1");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"ایدی کانالت رو بفرست⚙ => حتما با [ @ ] باشد🦠",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"🪓لغو عملیات🧨"]],
],
'resize_keyboard'=>true
])
]);
}
elseif($step == "font1"){
$getch = json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getchat?chat_id=$text"));
$title = $getch->result->title;
$userch = $getch->result->username;
$ok = $getch->ok;
if($ok != false){
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🛄 کانال با اطلاعات
☢نام کانال:
$title 〽️
🆔ایدی کانال: 
@$userch 〽️
☑️ثبت شد✅

توکن ربات خود را ارسال کنید〽️",
]);
json($from_id,"chanel","$text");
json($from_id,"step","font2");
}else{
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"این کانال وجود ندارد...🚫
سعی کنید ایدی کانال رو دقیق و با [ @ ] ارسال کنید❗️",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"🪓لغو عملیات🧨"]],
],
'resize_keyboard'=>true
])
]);
}
}
elseif($step == "font2"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
if($ok != 1){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"| #توکن | ارسالی اشتباه هست🚫

سعی کنید توکن صحیح رو از [ʙᴏᴛғᴀᴛʜᴇʀ] ارسال کنید✅",
]);
return false;
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"درحال ساخت ربات فونت ساز 🙃
لحظاتی صبور باشید ....🦅",
]);
if($type =="nonono"){
file_put_contents("Botas/$un/bottype.txt","vip");
}else{
file_put_contents("Bots/$un/bottype.txt","free");
}
//=============Mr_Ho3win=====================//
mkdir("Bots/$un");
json($from_id,"step","none");
json($from_id,"font","yes");
file_put_contents("Bots/$un/my_id.txt","$from_id");
$font = file_get_contents("source/font/font.php");
$font = str_replace("[*[TOKEN]*]",$text,$font);
$font = str_replace("[*[ADMIN]*]",$from_id,$font);
$font = str_replace("[*[CHANEL]*]",$chanel,$font);
file_put_contents("Bots/$un/font.php",$font);
//=============Mr_Ho3win=====================//
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$Adras."/Bots/".$un."/font.php");
json($from_id,"mybot","$un");
}
sleep(5.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'درحال ساخت ربات فونت ساز 🙃
لحظاتی صبور باشید 🧞‍♂
 Loading .... |1/2|'
 ]);
 sleep(4.4);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'درحال ساخت ربات فونت ساز 🙃
لحظاتی صبور باشید 🧞‍♂
 Loading .... |2/2|'
 ]);
 bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"با دکمه زیر به ربات خود هدایت میشوید😏",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🤗ورود به ربات🥳",'url'=>"https://t.me/$un"]],
]
])
]);
}

elseif($text == "🎙| شهر ویس" && $type == "free" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"حساب شما |free| میباشد🪓

برای ساخت ربات ها نیاز به حساب ویژه دارید🔮

برای ویژه شدن نیاز به 10 زیر مجموعه دارید🕳",
'parse_mode'=>'HTML',
]);
}

elseif($text == "🎙| شهر ویس" && $vois == "yes" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"شما قبلا یک ربات 🎙| شهر ویس ساخته اید☹️",
'parse_mode'=>'HTML',
]);
}

elseif($text == "🎙| شهر ویس" && $type == "vip" ){
json($from_id,"step","vois1");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"ایدی کانالت رو بفرست⚙ => حتما با [ @ ] باشد🦠",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"🪓لغو عملیات🧨"]],
],
'resize_keyboard'=>true
])
]);
}
elseif($step == "vois1"){
$getch = json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getchat?chat_id=$text"));
$title = $getch->result->title;
$userch = $getch->result->username;
$ok = $getch->ok;
if($ok != false){
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🛄 کانال با اطلاعات
☢نام کانال:
$title 〽️
🆔ایدی کانال: 
@$userch 〽️
☑️ثبت شد✅

توکن ربات خود را ارسال کنید〽️",
]);
json($from_id,"chanel","$text");
json($from_id,"step","vois2");
}else{
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"این کانال وجود ندارد...🚫
سعی کنید ایدی کانال رو دقیق و با [ @ ] ارسال کنید❗️",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"🪓لغو عملیات🧨"]],
],
'resize_keyboard'=>true
])
]);
}
}
elseif($step == "vois2"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
if($ok != 1){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"| #توکن | ارسالی اشتباه هست🚫

سعی کنید توکن صحیح رو از [ʙᴏᴛғᴀᴛʜᴇʀ] ارسال کنید✅",
]);
return false;
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"درحال ساخت ربات 🎙| شهر ویس 🙃
لحظاتی صبور باشید ....🦅",
]);
if($type =="nonono"){
file_put_contents("Botas/$un/bottype.txt","vip");
}else{
file_put_contents("Bots/$un/bottype.txt","free");
}
//=============Mr_Ho3win=====================//
mkdir("Bots/$un");
mkdir("Bots/$un/girlen");
mkdir("Bots/$un/GIRL FOSH");
mkdir("Bots/$un/girl");
mkdir("Bots/$un/data");
mkdir("Bots/$un/boyen");
mkdir("Bots/$un/boy2");
mkdir("Bots/$un/boy fosh");
mkdir("Bots/$un/boy");
json($from_id,"step","none");
json($from_id,"vois","yes");
file_put_contents("Bots/$un/my_id.txt","$from_id");
$vois = file_get_contents("source/vois/vois.php");
$vois = str_replace("[*[TOKEN]*]",$text,$vois);
$vois = str_replace("[*[ADMIN]*]",$from_id,$vois);
$vois = str_replace("[*[CHANEL]*]",$chanel,$vois);
$vois = str_replace("[*[USERBOT]*]",$un,$vois);
file_put_contents("Bots/$un/vois.php",$vois);
//=============Mr_Ho3win=====================//
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$Adras."/Bots/".$un."/vois.php");
json($from_id,"mybotvois","$un");
}
sleep(5.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'درحال ساخت ربات 🎙| شهر ویس 🙃
لحظاتی صبور باشید 🧞‍♂
 Loading .... |1/2|'
 ]);
 sleep(4.4);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'درحال ساخت ربات 🎙| شهر ویس 🙃
لحظاتی صبور باشید 🧞‍♂
 Loading .... |2/2|'
 ]);
 bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"با دکمه زیر به ربات خود هدایت میشوید😏",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🤗ورود به ربات🥳",'url'=>"https://t.me/$un"]],
]
])
]);
}

elseif($text == "🎄| تم تلگرام" && $type == "free" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"حساب شما |free| میباشد🪓

برای ساخت ربات ها نیاز به حساب ویژه دارید🔮

برای ویژه شدن نیاز به 10 زیر مجموعه دارید🕳",
'parse_mode'=>'HTML',
]);
}

elseif($text == "🎄| تم تلگرام" && $theme == "yes" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"شما قبلا یک ربات 🎄| تم تلگرام ساخته اید☹️",
'parse_mode'=>'HTML',
]);
}

elseif($text == "🎄| تم تلگرام" && $type == "vip" ){
json($from_id,"step","theme1");
bot('sendMessage',[
'chat_id'=>$chat_id,
 'text'=>"ایدی کانالت رو بفرست⚙ => حتما با [ @ ] باشد🦠",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"🪓لغو عملیات🧨"]],
],
'resize_keyboard'=>true
])
]);
}
elseif($step == "theme1"){
$getch = json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getchat?chat_id=$text"));
$title = $getch->result->title;
$userch = $getch->result->username;
$ok = $getch->ok;
if($ok != false){
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🛄 کانال با اطلاعات
☢نام کانال:
$title 〽️
🆔ایدی کانال: 
@$userch 〽️
☑️ثبت شد✅

توکن ربات خود را ارسال کنید〽️",
]);
json($from_id,"chanel","$text");
json($from_id,"step","theme2");
}else{
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"این کانال وجود ندارد...🚫
سعی کنید ایدی کانال رو دقیق و با [ @ ] ارسال کنید❗️",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"🪓لغو عملیات🧨"]],
],
'resize_keyboard'=>true
])
]);
}
}
elseif($step == "theme2"){
function objectToArrays( $object ){
if( !is_object( $object ) && !is_array( $object ))
{
return $object;
}
if( is_object( $object ))
{
$object = get_object_vars( $object );
}
return array_map( "objectToArrays", $object );
}
$userbot = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
if($ok != 1){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"| #توکن | ارسالی اشتباه هست🚫

سعی کنید توکن صحیح رو از [ʙᴏᴛғᴀᴛʜᴇʀ] ارسال کنید✅",
]);
return false;
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"درحال ساخت ربات  🎄| تم تلگرام
لحظاتی صبور باشید ....🦅",
]);
if($type =="nonono"){
file_put_contents("Botas/$un/bottype.txt","vip");
}else{
file_put_contents("Bots/$un/bottype.txt","free");
}
//=============Mr_Ho3win=====================//
mkdir("Bots/$un");
mkdir("Bots/$un/data");
json($from_id,"step","none");
json($from_id,"theme","yes");
file_put_contents("Bots/$un/my_id.txt","$from_id");
$theme = file_get_contents("source/theme/theme.php");
$theme = str_replace("[*[TOKEN]*]",$text,$theme);
$theme = str_replace("[*[ADMIN]*]",$from_id,$theme);
$theme = str_replace("[*[CHANEL]*]",$chanel,$theme);
$theme = str_replace("[*[USERBOT]*]",$un,$theme);
file_put_contents("Bots/$un/theme.php",$theme);
//=============Mr_Ho3win=====================//
file_get_contents("https://api.telegram.org/bot".$text."/setwebhook?url=".$Adras."/Bots/".$un."/theme.php");
json($from_id,"mybottheme","$un");
}
sleep(5.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'درحال ساخت ربات 🎄| تم تلگرام
لحظاتی صبور باشید 🧞‍♂
 Loading .... |1/2|'
 ]);
 sleep(4.4);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'درحال ساخت ربات 🎄| تم تلگرام
لحظاتی صبور باشید 🧞‍♂
 Loading .... |2/2|'
 ]);
 bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"با دکمه زیر به ربات خود هدایت میشوید😏",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🤗ورود به ربات🥳",'url'=>"https://t.me/$un"]],
]
])
]);
}

elseif($text == "حذف ربات|🗑|"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"یکی از گزینه های زیر رو انتخاب کن👌",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"حذف پیامرسان🪓"],['text'=>"حذف فونت ساز🪓"]],
[['text'=>"حذف فروشگاه♨️"],['text'=>"حذف ویس بات🎈"]],
[['text'=>"حذف تم تلکرام 💥️"]],
[['text'=>"『 بازگشت 』"]],
],
'resize_keyboard'=>true,
])
]);
}

 elseif($text == "حذف فونت ساز🪓" ){	
if($font == "yes"){
json($from_id,"step","pakfont");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"لطفا آیدی رباتی که میخاهید حذف کنید رو ارسال کنید😉
از لیست زیر⬇️
توجه‼️    => حتما بدون  [@]  ارسال کنید✅",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"$mybot"]],
[['text'=>"🪓لغو عملیات🧨"]],
]
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"شما هنوز رباتی نساخته اید⚠️",
'parse_mode'=>'Markdown', 
]);
}
}
elseif($step =="pakfont" && $text !="『 بازگشت 』"){
if($chat_id != $my_id  && $chat_id != $admin){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"شما مالک این ربات نیستید...🔆💢",
]);
}else{
json($from_id,"step","none");
json($from_id,"font","no");
json($from_id,"mybot","No");
deletefolder("Bots/$text");
rmdir("Bots/$text");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت حذف شد =Bot=> 🗑",
]);
}
}

 elseif($text == "حذف پیامرسان🪓" ){	
if($pm == "yes"){
json($from_id,"step","pakpm");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"لطفا آیدی رباتی که میخاهید حذف کنید رو ارسال کنید😉
از لیست زیر⬇️
توجه‼️    => حتما بدون  [@]  ارسال کنید✅",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"$mybotpm"]],
[['text'=>"🪓لغو عملیات🧨"]],
]
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"شما هنوز رباتی نساخته اید⚠️",
'parse_mode'=>'Markdown', 
]);
}
}
elseif($step =="pakpm" && $text !="『 بازگشت 』"){
if($chat_id != $my_id  && $chat_id != $admin){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"شما مالک این ربات نیستید...🔆💢",
]);
}else{
json($from_id,"step","none");
json($from_id,"pm","no");
json($from_id,"mybotpm","No");
deletefolder("Bots/$text");
rmdir("Bots/$text");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت حذف شد =Bot=> 🗑",
]);
}
}

 elseif($text == "حذف فروشگاه♨️" ){	
if($shop == "yes"){
json($from_id,"step","pakshop");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"لطفا آیدی رباتی که میخاهید حذف کنید رو ارسال کنید😉
از لیست زیر⬇️
توجه‼️    => حتما بدون  [@]  ارسال کنید✅",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"$mybotshop"]],
[['text'=>"🪓لغو عملیات🧨"]],
]
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"شما هنوز رباتی نساخته اید⚠️",
'parse_mode'=>'Markdown', 
]);
}
}
elseif($step =="pakshop" && $text !="『 بازگشت 』"){
if($chat_id != $my_id  && $chat_id != $admin){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"شما مالک این ربات نیستید...🔆💢",
]);
}else{
json($from_id,"step","none");
json($from_id,"shop","no");
json($from_id,"mybotshop","No");
deletefolder("Bots/$text");
rmdir("Bots/$text");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت حذف شد =Bot=> 🗑",
]);
}
}

elseif($text == "حذف ویس بات🎈" ){	
if($vois == "yes"){
json($from_id,"step","pakvois");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"لطفا آیدی رباتی که میخاهید حذف کنید رو ارسال کنید😉
از لیست زیر⬇️
توجه‼️    => حتما بدون  [@]  ارسال کنید✅",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"$mybotvois"]],
[['text'=>"🪓لغو عملیات🧨"]],
]
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"شما هنوز رباتی نساخته اید⚠️",
'parse_mode'=>'Markdown', 
]);
}
}
elseif($step =="pakvois" && $text !="『 بازگشت 』"){
if($chat_id != $my_id  && $chat_id != $admin){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"شما مالک این ربات نیستید...🔆💢",
]);
}else{
json($from_id,"step","none");
json($from_id,"vois","no");
json($from_id,"mybotvois","No");
deletefolder("Bots/$text");
rmdir("Bots/$text");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت حذف شد =Bot=> 🗑",
]);
}
}

elseif($text == "حذف تم تلکرام 💥️" ){	
if($theme == "yes"){
json($from_id,"step","paktheme");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"لطفا آیدی رباتی که میخاهید حذف کنید رو ارسال کنید😉
از لیست زیر⬇️
توجه‼️    => حتما بدون  [@]  ارسال کنید✅",
'parse_mode'=>'Markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"$mybottheme"]],
[['text'=>"🪓لغو عملیات🧨"]],
]
])
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"شما هنوز رباتی نساخته اید⚠️",
'parse_mode'=>'Markdown', 
]);
}
}
elseif($step =="paktheme" && $text !="『 بازگشت 』"){
if($chat_id != $my_id  && $chat_id != $admin){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"شما مالک این ربات نیستید...🔆💢",
]);
}else{
json($from_id,"step","none");
json($from_id,"theme","no");
json($from_id,"mybottheme","No");
deletefolder("Bots/$text");
rmdir("Bots/$text");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت حذف شد =Bot=> 🗑",
]);
}
}

elseif ($text == '📨پیام همگانی📤' && $chat_id == $admin){
json($from_id,"step","f1all");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "پیام مورد نظرتونو بفرستید تا برای همه ی کاربرا ارسالش کنم",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'🪓لغو عملیات🧨']],
],
'resize_keyboard'=>true,
])
]);
}
elseif($text != "🪓لغو عملیات🧨" && $step == "f1all"){
json($from_id,"step","f1all");
Bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>" پیام همگانی فرستاده شد.",
'parse_mode' => 'html'
]);
$all_member = fopen( "data/Member.txt", "r");
while( !feof( $all_member)) {
$user = fgets( $all_member);
SendMessage($user,$text,'html');
}
}

elseif($text == "فوروارد همگانی📰" && $chat_id == $admin ){
json($from_id,"step","f2all");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"پیام خود را برای فروارد همگانی فروارد نمایید👌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🪓لغو عملیات🧨"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($text != "🪓لغو عملیات🧨" && $step == "f2all"){
json($from_id,"step","none");
$file = file_get_contents("data/Member.txt");
$ex = explode("\n",$file);
foreach($ex as $users){
		   bot('ForwardMessage',[
	'chat_id'=>$users,
	'from_chat_id'=>$chat_id,
	'message_id'=>$message_id
	]);
		}    
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"✅فروارد همگانی به همه اعضای ربات فروارد شد.",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}

elseif ($text == '〽️آمار ربات♻️' && $chat_id == $admin){
$Mostafa1 = file_get_contents("data/Member.txt");
$Mostafa0= explode("\n",$Mostafa1);
$mphp405 = count($Mostafa0)-1;
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "تعداد دقیق کاربران ربات⚜
| 🌐  $mphp405 |
تقدیم به مدیر عزیز🔆",
'parse_mode' => 'MarkDown'
]);
}

elseif($text == "ریسیت شخص♻️" && $chat_id == $admin ){
$user["step"] = "restart_user";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"🆔 ایدی عددی شخص را ارسال کنید :",
'parse_mode'=>"HTML",
"resize_keyboard"=>true,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"لغو🔌"]],
],
])
]); 
}
elseif($text != "لغو🔌" && $step == "restart_user"){
if(file_exists("data/$text.json")){
unlink("data/$text.json");
$index = file_get_contents("data/Member.txt");
$index = str_replace("$text\n","",$index);
save("data/Member.txt",$index);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"دیتا |ᴅᴀᴛᴀ| شخص ریست شد♻️",
'parse_mode'=>"HTML",
]); 
bot('sendMessage',[
'chat_id'=>$text,
'text'=>"حسابت شما با موفقیت ریست شد♻️",
'parse_mode'=>"HTML",
]); 
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"❌ شخص در ربات وجود ندارد !",
'parse_mode'=>"HTML",
]); 
}
}

elseif($text == "مسدود کردن کاربر⛔️" && $chat_id == $admin ){
$user["step"] = "Ban-user";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"🆔 ایدی عددی شخص را ارسال کنید :",
'parse_mode'=>"HTML",
"resize_keyboard"=>true,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"لغو🔌"]],
],
])
]); 
}
elseif($text != "لغو🔌" && $text !="لغو🔌"  && $step == "Ban-user" ){
if(file_exists("data/$text.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$text.json"),true);
$user1["step"] = "ban";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$text.json",$outjson1);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"شخص مورد نظر با موفقیت |ʙᴀɴ| شد⛔️",
'parse_mode'=>"HTML",
]); 
bot('sendMessage',[
'chat_id'=>$text,
'text'=>"یه گهی خوردی ʙᴀɴ شدی😎🤘",
'parse_mode'=>"HTML",
]); 
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"❌ شخص در ربات وجود ندارد !",
'parse_mode'=>"HTML",
'reply_to_message_id'=>$message_id,
]); 
}
}

elseif($text == "آزاد کردن کاربر✅" && $chat_id == $admin ){
$user["step"] = "UnBan-user";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"🆔 ایدی عددی شخص را ارسال کنید :",
'parse_mode'=>"HTML",
"resize_keyboard"=>true,
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"لغو🔌"]],
],
])
]); 
}
elseif($text != "لغو🔌" && $step == "UnBan-user"){
if(file_exists("data/$text.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$text.json"),true);
$user1["step"] = "none";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$text.json",$outjson1);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"شخص مورد نظر با موفقیت |ᴜɴʙᴀɴ| شد✅",
'parse_mode'=>"HTML",
'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
'chat_id'=>$text,
'text'=>"اون گهی که خوردی رو پاک کردی و |ᴜɴʙᴀɴ| شدی 😈",
'parse_mode'=>"HTML",
]); 
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"❌ شخص در ربات وجود ندارد !",
'parse_mode'=>"HTML",
'reply_to_message_id'=>$message_id,
]); 
}
}

elseif ($text == "خاموش کردن ربات | ᵒᶠᶠ" && $from_id == $admin) {
file_put_contents("data/SenatorTmbot.txt","false");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"ربات با موفقیت از دسترس کاربران خارج شد❌
|ᵒᶠᶠ|>օʄʄ",
]);
}

elseif ($text == "روشن کردن ربات | ᵒⁿ✅" && $from_id == $admin){
file_put_contents("data/SenatorTmbot.txt","true");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"ربات با موفقیت در دسترس کاربران قرار گرفت✅
|ᵒⁿ|>օռ",
]);
}

elseif ($text == "هویت Off❌" && $from_id == $admin){
file_put_contents("data/modhoviat.txt","off");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"بخش تایید هویت [ کپچا ] خاموش شد🟥",
]);
}

elseif ($text == "هویت On✅" && $from_id == $admin) {
file_put_contents("data/modhoviat.txt","on");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"بخش تایید هویت [ کپچا ] روشن شد🟩",
]);
}

elseif ($text == "روشن کردن قفل چنل🔑" && $from_id == $admin){
file_put_contents("Settings/Lock.json","yes");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"قفل چنل با موفقیت فعال شد🔑",
]);
}

elseif ($text == "خاموش کردن قفل چنل🔒" && $from_id == $admin){
file_put_contents("Settings/Lock.json","no");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"قفل چنل با موفقیت غیر فعال شد🔐",
]);
}

elseif($text == "🎖 ویژه کردن"  && $chat_id == $admin ){
json($from_id,"step","vip-user");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🆔 ایدی عددی شخص را ارسال کنید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"لغو🔌"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($text != "لغو🔌" && $step == "vip-user"){
if(file_exists("data/$text.json")){
json($text,"type","vip");
json($from_id,"step","none");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"✅ با موفقیت ویژه شد .",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$text,
 'text'=>"🌟 از سمت مدیریت شما ویژه شدید.",
 'parse_mode'=>"HTML",
]); 
}else{
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"❌ شخص در ربات وجود ندارد !",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
}

elseif($text == "🚫 لغو ویژه" && $chat_id == $admin ){
json($from_id,"step","frer-user");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🆔 ایدی عددی شخص را ارسال کنید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"لغو🔌"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($text != "لغو🔌" && $step == "frer-user"){
if(file_exists("data/$text.json")){
json($text,"type","free");
json($from_id,"step","none");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"✅ با موفقیت رایگان شد .",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$text,
 'text'=>"😐 حساب شما رایگان شد .",
 'parse_mode'=>"HTML",
]); 
}else{
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"❌ شخص در ربات وجود ندارد !",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
}

elseif($text == "تنظیم متن کانال ما🪑" && $chat_id == $admin ){
json($from_id,"step","set_mychannel");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"متنی که میخای کاربر بعد از لمس دکمه کانال ما |🐙| براش نمایش بدم رو بفرست 🗞",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"لغو🔌"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($text != "لغو🔌" && $step == "set_mychannel"){
file_put_contents("data/my_channel.txt","$text");
json($from_id,"step","none");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"با موفقیت تنظیم شد !!📕
متن کنونی:
$text",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}

elseif($text == "تنظیم متن بنر🛎" && $chat_id == $admin ){
json($from_id,"step","set_givebanner");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"متنی که میخای کاربر بعد از لمس دکمه کانال 🧧دریافت بنر📥 براش نمایش بدم رو بفرست👌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"لغو🔌"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($text != "لغو🔌" && $step == "set_givebanner"){
file_put_contents("data/givebanner.txt","$text");
json($from_id,"step","none");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"با موفقیت تنظیم شد !!📕
متن کنونی:
$text",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}

elseif($text == "تنظیم متن ها📄" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"به بخش تنظیم متن های ربات خوش اومدین😍

در این قسمت میتومید متن های بخش های ربات رو تعقیر بدین👌",
'parse_mode'=>"MarkDown",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"تنظیم متن کانال ما🪑"],['text'=>"تنظیم متن بنر🛎"]],
[['text'=>"لغو🔌"]],
],
'resize_keyboard'=>true,
])
]);
}

elseif($text == "ساخت کد هدیه⛩" && $chat_id == $admin && $text !="لغو🔌" ){
json($from_id,"step","new_code");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"کد هدیه رو وارد کنید🤘=> [💚]",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"لغو🔌"]],
]
])
]);
}
elseif($step == "new_code" && $chat_id == $admin && $text !="لغو🔌" ){
file_put_contents("data/code.txt",$text);
json($from_id,"step","new_code2");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"تعداد سکه رو وارد کنید🤘=> [💚]",
'replu_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"لغو🔌"]]
]
])
]);
}
elseif($step == "new_code2" && $chat_id == $admin && $text !="لغو🔌" ){
file_put_contents("data/sek.txt",$text);
json($from_id,"step","none");
$code = file_get_contents("data/code.txt");
$sek = file_get_contents("data/sek.txt");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"کد هدیه با موفقیت ساخته شد و به کانال ارسال شد😃🥀",
'replu_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"لغو🔌"]]
]
])
]);
bot('SendPhoto', [
'chat_id'=>"@".$channel,
'photo'=>"https://dynamic.brandcrowd.com/asset/logo/ade8c4ec-17d5-4d35-9444-3b552649bd7e/logo?v=4&text=$code",
'caption'=>"کد هدیه جدید ساخته شد🎉
مشاهده کد در تصویر🏞👆
🕰تاریخ: $date
⏰ساعت: $time
🥇تعداد سکه: $sek

🏆راهنمای استفاده: [ کد رو در قسمت پروفایل من سپس در قسمت کد هدیه وارد کنید ] =>> اگر نفر اول باشید شما [ $sek ] سکه دریافت خواهی کرد.🎨

🎭 $channel",
'parse_mode'=>'HTML',
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"ورود به ربات🏖",'url'=>"https://telegram.me/$botid"]],
]
])
]);
}

elseif($text == "/panel" && $chat_id == $admin  ){
json($from_id,"step","none");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"به پنل مدیریت خوش اومدید🥀",
'parse_mode'=>"MarkDown",
'resize_keyboard'=>true,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'ساخت کد هدیه⛩']],
[['text'=>'🎖 ویژه کردن'],['text'=>'🚫 لغو ویژه']],
[['text'=>'روشن کردن قفل چنل🔑']],
[['text'=>'خاموش کردن قفل چنل🔒']],
[['text'=>'ریسیت شخص♻️']],
[['text'=>'آزاد کردن کاربر✅'],['text'=>'مسدود کردن کاربر⛔️']],
[['text'=>'〽️آمار ربات♻️']],
[['text'=>'فوروارد همگانی📰'],['text'=>'📨پیام همگانی📤']],
[['text'=>'خاموش کردن ربات | ᵒᶠᶠ'],['text'=>'روشن کردن ربات | ᵒⁿ✅']],
[['text'=>'هویت On✅'],['text'=>'هویت Off❌']],
[['text'=>'تنظیم متن ها📄']],
[['text'=>'『 بازگشت 』']],
],
])
]);
}
elseif($text == "لغو🔌" ){
json($from_id,"step","none");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"عملیات لغو شد🩸   برای ادامه کار | /start | کنید🦠",
'parse_mode'=>'HTML',
]);
return false;
 }

?>