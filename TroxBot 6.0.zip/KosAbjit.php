<?php

/*
بسم الله الرحمن الرحیم

اپن شده توسط :@Mr_Ho3win

----------------------------
سورس های بیشتر در چنل لورکس تیم 
@LorexTeam 
-----------------------------

*/

ob_start();
$telegram_ip_ranges = [
    ['lower' => '149.154.160.0', 'upper' => '149.154.175.255'], 
    ['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],    
    ];
    $ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
    $ok=false;
    foreach ($telegram_ip_ranges as $telegram_ip_range)
    {
        if(!$ok)
        {
            $lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
            $upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
            if($ip_dec >= $lower_dec and $ip_dec <= $upper_dec)
            {
                $ok=true;
                }
            }
        }
    if(!$ok){
        exit(header("location:https://instagram.com/Hosein1383_sh"));
    }
    $token = "1924875105:AAE2cewS-deV4tq_qn4Fc9ONJ5rNqOdzq2Q"; // توکن
define('API_KEY',"$token");
$Dev = "1560820572"; // ایدی عددی
$channel = "troxBots";  //ایدی چنل
$folder = "https://TroxBot.ir/Ho3win/LorexTeam"; // دامنه و ادرس فایل


//-------------------------------فانکشن ها---------------------------------------------
function bot($method,$datas=[]){
 $url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}else{
return json_decode($res);
}
}
function SendMessage($chat_id, $text){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>$text,
'parse_mode'=>'MarkDown']);
}
function save($filename, $data)
{
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}
function step($step){
    file_put_contents("step.txt",$step);
}
function arz(){
    $get = file_get_contents('https://www.iranjib.ir/showgroup/23/realtime_price/');
    preg_match_all('#<span class="lastprice" dir="ltr">(.*?)</span>#',$get,$costs);
    return ['Gold'=>$costs[1][8],'Dollar'=>$costs[1][49],'Euro'=>$costs[1][53]];
}

function zekr($day){
    switch($day){
        case 'شنبه':
            return "یا رب العالمین";
        break;
        case 'یکشنبه':
            return "یا ذالجلال والاکرام";
        break;
        case 'دوشنبه':
            return "یا قاضی الحاجات";
        break;
        case 'سه شنبه':
            return "یا ارحم الراحمین";
        break;
        case 'چهارشنبه':
            return "یا حی یا قیوم";
        break;
        case 'پنجشنبه':
            return "لا اله الا الله الملک الحق المبین";
        break;
        case 'جمعه':
            return "اللهم صل علی محمد و ال محمد";
        break;
    }
}
function convertInt($integer){
    return str_replace(['۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹', '۰'], [1, 2, 3, 4, 5, 6, 7, 8, 9, 0], $integer);
}
function owner(){
    global $chat_id, $from_id;
    
    $get = bot('getChatMember',[
        'chat_id'=> $chat_id,
        'user_id'=> $from_id
    ])['result']['status'];
    return in_array($get, ['creator', 'administrator']);
}
function rank(){
    global $chat_id, $from_id;
    $rank = bot('getChatMember',[
        'chat_id'=> $chat_id,
        'user_id'=> $from_id
    ])['result']['status'];
    return str_replace(['creator', 'administrator', 'member'], ['سازنده گروه', 'ادمین گروه', 'کاربر معمولی'], $rank);
}


function SendDocument($chat_id, $document, $caption = null){
bot('SendDocument',[
'chat_id'=>$chat_id,
'document'=>$document,
'caption'=>$caption
]);
}
function EditMessageText($chat_id,$message_id,$text,$parse_mode,$disable_web_page_preview,$keyboard){
bot('editMessagetext',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>$text,
'parse_mode'=>$parse_mode,
'disable_web_page_preview'=>$disable_web_page_preview,
'reply_markup'=>$keyboard
]);
 }
function SendPhoto($chat_id, $photo, $caption = null){
bot('SendPhoto',[
'chat_id'=>$chat_id,
'photo'=>$photo,
'caption'=>$caption
]);
}
function sendAction($chat_id, $action){
bot('sendChataction',[
'chat_id'=>$chat_id,
'action'=>$action]);
}

function deleteFolder($path){
if(is_dir($path) === true){
$files = array_diff(scandir($path), array('.', '..'));
foreach ($files as $file)
deleteFolder(realpath($path) . '/' . $file);
return rmdir($path);
}else if (is_file($path) === true)
return unlink($path);
return false;
} 
function Forward($kojashe, $azkoja, $kodommsg){
hadi('forwardmessage',[
'chat_id'=>$kojashe,
'from_chat_id'=>$azkoja,
'message_id'=>$kodommsg
]);
}
function LeaveChat($chat_id){
hadi('LeaveChat',[
'chat_id'=>$chat_id
]);
}
function GetChat($chat_id){
hadi('GetChat',[
'chat_id'=>$chat_id
]);
}


?>
